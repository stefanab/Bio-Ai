package assign3;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

import javax.imageio.ImageIO;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;


public class MOEAMain {

	public class Globals {
		//MutationMethods
		public static final double CHANCE_TO_KEEP_BIGGER = 0.05;
		public static final int START_BORDER_PIXELS = 400;
		//Chromosome
		public static final int NEAREST_NEIGHBORS = 4;
		//MOEA
		public static final int MERGE_UNTIL_NUMBER_OF_SEGMENTS = 10;
		public static final int MAX_SEGMENTS = 5;
		public static final int FIRST = 0; 					//number of chromosomes generated from the segmentation algorithm (rest randomly dist)
		public static final double INITIAL_THRESHOLD = 100	;
		//Main
		public static final int OBJECTIVE_FUNCTIONS = 0; 	//which objectives to optimize. (0 EDGE/CON, 1 EDGE/DEV, 2 CON/DIV, 3 CON/DIV/EDGE)
		public static final double PICK_WORSE_PARENT = 0.8; //chance of picking worse parent in tournament
		public static final int NOT_FEASIBLE_PENALTY = 2;   //fitness penalty for not being feasible (not used)
		static final int ITERATIONS = 100;					//Number of iterations
		static final double MUTATION_CHANCE = 0.4;			// Chance of a mutation to happen 
		static final int POPULATION_SIZE = 50;				// Population size //turn up if converging to quick
		static final double RANDOM_BIAS = 1.2;				//bias used to pick better ranked parents. if > 1 higher chance for better fitness parent /turn up if convergence too slow
		static final int NEXT_GENERATION_SIZE = 25;			// Next generation size (real value is 2x since there are 2 children for each iteration
		static final double CROSSOVER_CHANCE = 0.95;			//pick between two crossovers. higher for higher prob of bcrc
		static final int PRINT = 60;						// how often to print solution 
	}
	
	static final String path = "C:\\Users\\Stefan\\Desktop\\NTNU\\IT3708BioAI\\assign3\\TestImage\\TestImage\\4\\Test Image.jpg";
	
	private static Chromosome generateFirstChromosome(Mat img) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public static void main(String[] args) {
	//load file
	System.loadLibrary( Core.NATIVE_LIBRARY_NAME );
	File input = new File(path);
	BufferedImage img2 = null;
	try {
		img2 = ImageIO.read(input);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//convert to mat
	ImageLoaderAndDisplayer loader = new ImageLoaderAndDisplayer();
	Mat img = loader.bufferedImageToMat(img2);
	Mat mat = new Mat();
	Mat mat2 = new Mat();
	Mat mat3 = new Mat();
	Mat kernel = Imgproc.getStructuringElement(Imgproc.MORPH_CROSS, new Size(6, 6));
	Imgproc.dilate(img, mat2, kernel);
	kernel = Imgproc.getStructuringElement(Imgproc.MORPH_CROSS, new Size(3, 3));
	Imgproc.erode(mat2, mat, kernel);
	Imgproc.filter2D(mat2, mat3, -1, kernel, new Point(-1, -1), 0, 0);
	MOEA mo = new MOEA(img);
	Chromosome first = mo.generateFirstChromosome(img);
	System.out.println("initializing");
	//create first population
	mo.generateFirstPopulation();
	ArrayList<LinkedList<Chromosome>> nextPop = mo.fastNonDominatedSort(mo.population);
	mo.population.clear();
	for (LinkedList<Chromosome> front : nextPop) {
		mo.crowndingDistanceAssignment(front);
		mo.population.addAll(front);
	}
	System.out.println(mo.population.size());
	Random rdm = new Random();
	for (int iterations = 0; iterations < Globals.ITERATIONS; iterations++) {
		System.out.println(iterations);
		LinkedList<Chromosome> offspring = new LinkedList<Chromosome>();
		for (int i = 0; i < Globals.NEXT_GENERATION_SIZE; i++) {
			//select next parents
			LinkedList<Chromosome> parents = mo.randomSelection(mo.population);
			Chromosome x = parents.get(0);
			Chromosome y = parents.get(1);	
			Chromosome child = mo.crossover(x,y);
			if(rdm.nextDouble() < Globals.MUTATION_CHANCE) {
				child = mo.mutate(child, iterations);
			}
			offspring.add(child);
		//create next generation
		}
		mo.population.addAll(offspring);
		ArrayList<LinkedList<Chromosome>> fronts = mo.fastNonDominatedSort(mo.population);
		LinkedList<Chromosome> nextGeneration = new LinkedList<Chromosome>();
		int front = 0;
		while(nextGeneration.size() + fronts.get(front).size() <= Globals.POPULATION_SIZE) {
			mo.crowndingDistanceAssignment(fronts.get(front));
			nextGeneration.addAll(fronts.get(front));
			front++;
				
		}
		fronts.set(front, mo.Sort(fronts.get(front)));
		while(nextGeneration.size() < Globals.POPULATION_SIZE) {
			nextGeneration.add(fronts.get(front).removeFirst());
		}
		mo.population = nextGeneration;
	}
	
	
	//initialize first population
	int count = 0;
	for (LinkedList<Chromosome> linkedList : nextPop) {
		System.out.println(linkedList.size());
	}
	for (Chromosome chromo : nextPop.get(0)) {
		
		loader.displayImageBlackWhite(img, chromo);
		count++;
		if(count > 2){
			break;
		}
	}
	loader.plotParetoFront(nextPop);
	
	
	
	}

	
	
}
