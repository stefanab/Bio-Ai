package assign3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

import org.opencv.core.Mat;

import assign3.MOEAMain.Globals;

public class MutationMethods {

	Mat img;
	
	
	
	
	public MutationMethods(Mat img) {
		this.img = img;
	}
	
	
	/** velger at antall grensepixler og flytter de til et nabosegment
	 * @param chromo
	 * @param iterations
	 * @return
	 */
	public Chromosome borderPixelsMutation(Chromosome chromo, int iterations) {
		Random rdm = new Random();
		int segNr = rdm.nextInt(chromo.segments.size());
		ArrayList<int[]> segm = chromo.segments.get(segNr);
		while(segm.isEmpty()) {
			segNr++;
			if(segNr >= chromo.segments.size()) {
				segNr = 0;
			}
			segm = chromo.segments.get(segNr);
		}
		LinkedList<String> borderPixels = new LinkedList<String>();
		LinkedList<int[]> queue = new LinkedList<int[]>();
		queue.addAll(segm);
		while(!queue.isEmpty()) {
			int[] nextPoint = (int[]) queue.poll();
			
			if (checkEast(nextPoint[0], nextPoint[1]+1)){
				int nr = chromo.imageRep.get(nextPoint[0]).get(nextPoint[1]+1);
				int y = nextPoint[1]+1;
				int x = nextPoint[0];
				if(nr != segNr && !borderPixels.contains(x+","+y)) {
					borderPixels.add(x+","+y);
				}
			} 
			if (checkWest(nextPoint[0], nextPoint[1]-1))  {
				int nr = chromo.imageRep.get(nextPoint[0]).get(nextPoint[1]-1);
				int y = nextPoint[1]-1;
				int x = nextPoint[0];
				if(nr != segNr && !borderPixels.contains(x+","+y)) {
					borderPixels.add(x+","+y);
				}
			}
			if (checkNorth(nextPoint[0]-1, nextPoint[1]))  {
				int nr = chromo.imageRep.get(nextPoint[0]-1).get(nextPoint[1]);
				int y = nextPoint[1];
				int x = nextPoint[0]-1;
				if(nr != segNr && !borderPixels.contains(x+","+y)) {
					borderPixels.add(x+","+y);
				}
			}
			if (checkSouth(nextPoint[0]+1, nextPoint[1]))  {
				int nr = chromo.imageRep.get(nextPoint[0]+1).get(nextPoint[1]);
				int y = nextPoint[1];
				int x = nextPoint[0]+1;
				if(nr != segNr && !borderPixels.contains(x+","+y)) {
					borderPixels.add(x+","+y);
				}
			}
		}
		for (String string : borderPixels) {
			String[] cord = string.split(",");
			int row = Integer.parseInt(cord[0]);
			int col = Integer.parseInt(cord[1]);
			double oldEdge = chromo.singleEdgeValue(row, col);
			int oldSeg = chromo.imageRep.get(row).get(col);
			chromo.imageRep.get(row).set(col, segNr);
			double newEdge = chromo.singleEdgeValue(row, col);
			if( newEdge < oldEdge) {
				ArrayList<int[]> oldSegm = chromo.segments.get(oldSeg);
				int index = 0;
				for (int i = 0; i < oldSegm.size(); i++) {
					int[] pixel = oldSegm.get(i);
					if(pixel[0] == row && pixel[1] == col) {
						index = i;
						chromo.segments.get(segNr).add(pixel);
					}
				}
				oldSegm.remove(index);
			} else {
				chromo.imageRep.get(row).set(col, oldSeg);
			}
		}
		chromo.updateObjectiveValues();
		return chromo;
	}
	
	/** Skal velge det minste segmentet med en viss sannsynlighet som minker jo flere iterasjon som har g�tt. M� passe p� � holde segmenter 
	 * konsistente
	 * @param chromo
	 * @param iterations
	 * @return
	 */
	public Chromosome mergeSegmentsMutation(Chromosome chromo, int iterations) {
		return chromo;
	}
	
	/** Merger to nabosegmenter basert p� hvilken av naboene som er mest like hverandre
	 * @param chromo
	 * @param iterations
	 * @return
	 */
	public Chromosome mergeSegmentsMutationCentroid(Chromosome chromo, int iterations) {
		Random rdm = new Random();
		//pick a segment to merge
		
		int segNr = rdm.nextInt(chromo.segments.size());
		int segNr2 = rdm.nextInt(chromo.segments.size());
		
		ArrayList<int[]> segm = chromo.segments.get(segNr);
		ArrayList<int[]> seg2 = chromo.segments.get(segNr2);
		if(segm.size() > seg2.size()) {
			if(rdm.nextDouble() > Globals.CHANCE_TO_KEEP_BIGGER) {
				segm = seg2;
				segNr = segNr2;
			}
		}
		int tries = 0;
		while(segm.isEmpty() && tries < 5) {
			segNr = rdm.nextInt(chromo.segments.size());
			
			segm = chromo.segments.get(segNr);
			tries++;
		}		
		while(segm.isEmpty()) {
			segNr++;
			if(segNr >= chromo.segments.size()) {
				segNr = 0;
			}
			segm = chromo.segments.get(segNr);
		}
		double[] centroid = chromo.centroidPixel(segm);
		LinkedList<Integer> neighbors = findNeighbors(chromo, segNr);
		int bestSeg = neighbors.poll();
		double[] mostSimilarCentroid = chromo.centroidPixel(chromo.segments.get(bestSeg));
		double distance = euclideanColorDistance(centroid, mostSimilarCentroid);
		while(!neighbors.isEmpty()){
			int nextSeg = neighbors.poll();
			double[] nextCentroid = chromo.centroidPixel(chromo.segments.get(nextSeg));
			double nextDistance = euclideanColorDistance(centroid, nextCentroid);
			if(distance >= nextDistance) {
				mostSimilarCentroid = nextCentroid;
				distance = nextDistance;
				bestSeg = nextSeg;
			}
		}
		//merge the two segments and keep consistency
		ArrayList<int[]> segm2 = chromo.segments.get(bestSeg);
		for (int[] d : segm2) {
			chromo.imageRep.get(d[0]).set(d[1], segNr);
			segm.add(d);
			
		}
		segm2.clear();
		//husk � oppdatere hele chromosomet!
		return chromo;
	}
	private ArrayList<int[]> findSegment(Chromosome chromo) {
		// TODO Auto-generated method stub
		return null;
	}


	private LinkedList<Integer> findNeighbors(Chromosome chromo, int segNr) {
		// TODO Auto-generated method stub
		
		LinkedList<Integer> neighbor = new LinkedList<Integer>();
		Queue<int[]> inSegqueue = new LinkedList<int[]>();
		inSegqueue.addAll(chromo.segments.get(segNr));
		while(!inSegqueue.isEmpty()) {
			int[] nextPoint = (int[]) inSegqueue.poll();
			
			if (checkEast(nextPoint[0], nextPoint[1]+1)){
				int nr = chromo.imageRep.get(nextPoint[0]).get(nextPoint[1]+1);
				if(nr != segNr && !neighbor.contains(nr)) {
					neighbor.add(nr);
				}
			} 
			if (checkWest(nextPoint[0], nextPoint[1]-1))  {
				int nr = chromo.imageRep.get(nextPoint[0]).get(nextPoint[1]-1);
				if(nr != segNr && !neighbor.contains(nr)) {
					neighbor.add(nr);
				}
			}
			if (checkNorth(nextPoint[0]-1, nextPoint[1]))  {
				int nr = chromo.imageRep.get(nextPoint[0]-1).get(nextPoint[1]);
				if(nr != segNr && !neighbor.contains(nr)) {
					neighbor.add(nr);
				}
			}
			if (checkSouth(nextPoint[0]+1, nextPoint[1]))  {
				int nr = chromo.imageRep.get(nextPoint[0]+1).get(nextPoint[1]);
				if(nr != segNr && !neighbor.contains(nr)) {
					neighbor.add(nr);
				}
			}
			
		}
		return neighbor;
	}


	/** Skal velge det st�rste segmentet med en viss sannsynlighet som minker jo flere iterasjon som har g�tt
	 * @param chromo
	 * @param iterations
	 * @return
	 */
	public Chromosome splitSegmentsMutation(Chromosome chromo, int iterations) {
		return chromo;
	}
	
	public boolean checkEast(int row, int col) {
		if(row < 0 || row >= img.height() || col < 0 || col >= img.width()) {
			return false;
		} else {
			return true;
		}
	}
	
	public boolean checkNorth(int row, int col) {
		if(row < 0 || row >= img.height() || col < 0 || col >= img.width()) {
			return false;
		} else {
			return true;
		}
	}
	
	public boolean checkWest(int row, int col) {
		if(row < 0 || row >= img.height() || col < 0 || col >= img.width()) {
			return false;
		} else {
			return true;
		}
	}
	
	public boolean checkSouth(int row, int col) {
		if(row < 0 || row >= img.height() || col < 0 || col >= img.width()) {
			return false;
		} else {
			return true;
		}
	}
	
	private double euclideanColorDistance(double[] pixel1, double[] pixel2) {
		 double red = Math.pow(pixel1[0]-pixel2[0], 2);
		 double green = Math.pow(pixel1[1]-pixel2[1], 2);
		 double blue = Math.pow(pixel1[2]-pixel2[2], 2);
		 return Math.sqrt(red+green+blue);
	 }
	
}
