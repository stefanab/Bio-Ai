package assign3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Stack;

import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import assign3.MOEAMain.Globals;

public class MOEA {

	Mat img;
	LinkedList<Chromosome> population;
	
	
	public MOEA() {
		
	}
	
	public MOEA(Mat img) {
		this.img = img;
		this.population = new LinkedList<Chromosome>();
	}
	
	
	
	public void generateFirstPopulation() {
		for (int i = 0; i < Globals.FIRST; i++) {
			Chromosome first = generateFirstChromosome(this.img);
			this.population.add(first);
			
		}
		for (int i = 0; i < Globals.POPULATION_SIZE-Globals.FIRST; i++) {
			Chromosome randomChromo = generateRandomChromosome();
			ImageLoaderAndDisplayer il = new ImageLoaderAndDisplayer();
			il.displayImageGreenLine(img, randomChromo);
			this.population.add(randomChromo);
		}
	}
	
	private Chromosome generateRandomChromosome() {
		ArrayList<ArrayList<Integer>> chromo = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < img.height(); i++) {
			ArrayList<Integer> nextLine = new ArrayList<Integer>();
			for (int j = 0; j < img.width(); j++) {
				nextLine.add(-1);
			}
			chromo.add(nextLine);
		}
		ArrayList<ArrayList<int[]>> segments = new ArrayList<ArrayList<int[]>>();
		int segmentNumber = 0;
		Random rdm = new Random();
		int assignedPixels = 0;
		int[] startPoint = {0,0};
		Queue<int[]> inSegqueue = new LinkedList<int[]>();
		int dim = img.height()*img.width();
		inSegqueue.add(startPoint);
		while (assignedPixels < dim) {
			ArrayList<int[]> nextSegment = new ArrayList<int[]>();
			int numberOfPixelsInSegment = rdm.nextInt(dim/(rdm.nextInt(30)+200));
			int assignedToSegment = 0;
			while (assignedToSegment < numberOfPixelsInSegment) {
				if(assignedPixels >= dim || inSegqueue.isEmpty()) {
					break;
				}
				int[] nextPoint = (int[]) inSegqueue.poll();
				if(chromo.get(nextPoint[0]).get(nextPoint[1]) == -1) {
					nextSegment.add(nextPoint);
					chromo.get(nextPoint[0]).set(nextPoint[1], segmentNumber);
					assignedPixels++;
					assignedToSegment++;
					
			
				if (checkEast(nextPoint[0], nextPoint[1]+1)){
					int[] point = {nextPoint[0],nextPoint[1]+1};
					inSegqueue.add(point);
				} 
				if (checkWest(nextPoint[0], nextPoint[1]-1))  {
					int[] point = {nextPoint[0],nextPoint[1]-1};
					inSegqueue.add(point);
				}
				if (checkNorth(nextPoint[0]-1, nextPoint[1]))  {
					int[] point = {nextPoint[0]-1,nextPoint[1]};
					inSegqueue.add(point);
				}
				if (checkSouth(nextPoint[0]+1, nextPoint[1]))  {
					int[] point = {nextPoint[0]+1,nextPoint[1]};
					inSegqueue.add(point);
				}
				
				}
			}
			segments.add(nextSegment);
			segmentNumber++;
			int[] nextPoint = findNextUnassignedPixel(chromo);
			inSegqueue.clear();
			inSegqueue.add(nextPoint);
		}
		
		Chromosome newInd = new Chromosome(chromo, segments, img);
		if(segmentNumber > Globals.MAX_SEGMENTS) {
			MutationMethods mm = new MutationMethods(this.img);
			for (int i = 0; i < segmentNumber-Globals.MAX_SEGMENTS; i++) {
				newInd = mm.mergeSegmentsMutationCentroid(newInd, 1);
			}
			newInd = mm.borderPixelsMutation(newInd, 1);
		}
		newInd = recalculateInd(newInd);
		return new Chromosome(newInd.imageRep, newInd.segments, img);
	}
	
	private Chromosome recalculateInd(Chromosome newInd) {
		// TODO Auto-generated method stub
		int Segnumber = 0;
		return newInd;
	}

	public boolean checkEast(int row, int col) {
		if(row < 0 || row >= img.height() || col < 0 || col >= img.width()) {
			return false;
		} else {
			return true;
		}
	}
	
	public boolean checkNorth(int row, int col) {
		if(row < 0 || row >= img.height() || col < 0 || col >= img.width()) {
			return false;
		} else {
			return true;
		}
	}
	
	public boolean checkWest(int row, int col) {
		if(row < 0 || row >= img.height() || col < 0 || col >= img.width()) {
			return false;
		} else {
			return true;
		}
	}
	
	public boolean checkSouth(int row, int col) {
		if(row < 0 || row >= img.height() || col < 0 || col >= img.width()) {
			return false;
		} else {
			return true;
		}
	}

	public Chromosome generateFirstChromosome(Mat img) {
		ArrayList<ArrayList<Integer>> chromo = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < img.height(); i++) {
			ArrayList<Integer> nextLine = new ArrayList<Integer>();
			for (int j = 0; j < img.width(); j++) {
				nextLine.add(-1);
			}
			chromo.add(nextLine);
		}
		ArrayList<ArrayList<int[]>> segments = new ArrayList<ArrayList<int[]>>();
		int segmentNumber = 0;
		int assignedPixels = 1;
		int[] startPoint = {0,0};
		chromo.get(0).set(0, segmentNumber);
		Queue<int[]> inSegqueue = new LinkedList<int[]>();
		inSegqueue.add(startPoint);
		while(assignedPixels < img.height()*img.width()) {
			ArrayList<int[]> nextSegment = new ArrayList<int[]>();
			//push 
			while(!inSegqueue.isEmpty()) {
				int[] nextPoint = (int[]) inSegqueue.poll();
				nextSegment.add(nextPoint);
				if(checkPoint(nextPoint, nextPoint[0]+1,nextPoint[1]) && (chromo.get(nextPoint[0]+1).get(nextPoint[1]) == -1)) {
					chromo.get(nextPoint[0]+1).set(nextPoint[1], segmentNumber);
					assignedPixels++;
					int[] point = {nextPoint[0]+1,nextPoint[1]};
					inSegqueue.add(point);
				}
				if(checkPoint(nextPoint, nextPoint[0]-1,nextPoint[1])&& (chromo.get(nextPoint[0]-1).get(nextPoint[1]) == -1)) {
					chromo.get(nextPoint[0]-1).set(nextPoint[1], segmentNumber);
					assignedPixels++;
					int[] point = {nextPoint[0]-1,nextPoint[1]};
					inSegqueue.add(point);
				}
				if (checkPoint(nextPoint, nextPoint[0],nextPoint[1]+1)&& (chromo.get(nextPoint[0]).get(nextPoint[1]+1) == -1)) {
					chromo.get(nextPoint[0]).set(nextPoint[1]+1, segmentNumber);
					assignedPixels++;
					int[] point = {nextPoint[0],nextPoint[1]+1};
					inSegqueue.add(point);
				}
				if (checkPoint(nextPoint, nextPoint[0],nextPoint[1]-1)&& (chromo.get(nextPoint[0]).get(nextPoint[1]-1) == -1)) {
					chromo.get(nextPoint[0]).set(nextPoint[1]-1, segmentNumber);
					assignedPixels++;
					int[] point = {nextPoint[0],nextPoint[1]-1};
					inSegqueue.add(point);
				}
			}
			//find next unassigned pixel
			segments.add(nextSegment);
			segmentNumber++;
			int[] nextPoint = findNextUnassignedPixel(chromo);
			assignedPixels++;
			if(nextPoint != null) {
				
				chromo.get(nextPoint[0]).set(nextPoint[1], segmentNumber);
			}
			inSegqueue.add(nextPoint);
		}
		return new Chromosome(chromo, segments, img);
	}
	private int[] findNextUnassignedPixel(ArrayList<ArrayList<Integer>> chromo) {
		for (int i = 0; i < chromo.size(); i++) {
			for (int j = 0; j < chromo.get(0).size(); j++) {
				if(chromo.get(i).get(j) == -1) {
					int[] nextPoint = {i,j};
					
					return nextPoint;
				}
			}
		}
		return null;
	}

	private boolean checkPoint(int[] point, int x, int y) {
		if(x < 0 || y < 0 || x >= img.height() || y >= img.width()  ) {
			return false;
		}
		double[] values1 = img.get(point[0], point[1]);
		double[] values2 = img.get(x, y);
		Random rdm = new Random();
		if(euclideanColorDistance(values1, values2) < Globals.INITIAL_THRESHOLD*rdm.nextDouble()) {
			return true;
		} else {
			return false;
		}
	}
	
	private double euclideanColorDistance(double[] pixel1, double[] pixel2) {
		 double red = Math.pow(pixel1[0]-pixel2[0], 2);
		 double green = Math.pow(pixel1[1]-pixel2[1], 2);
		 double blue = Math.pow(pixel1[2]-pixel2[2], 2);
		 return Math.sqrt(red+green+blue);
	 }

	private String computeShortestEdge(Mat img, int i, int j) {
		double[] values = img.get(i, j);
		
		double best = checkNorth(img, i, j-1);
		double next = checkEast(img, i+1, j);
		if(next < best) {
			best = next;
		}
		next = checkSouth(img, i, j+1);
		if(next < best) {
			best = next;
		}
		next = checkWest(img, i-1, j);
		if(next < best) {
			best = next;
		}
		return best + "";
	}

	private double checkWest(Mat img, int i, int j) {
		if((i <= 0 ) || (j <= 0)) {
			return Double.MAX_VALUE;
		} else {
			double[] values = img.get(i, j);
			double[] val2 = img.get(i-1, j);
			double sum = 0;
			for (int k = 0; k < val2.length; k++) {
				sum += Math.pow(values[k]-val2[k], 2);
			}
			return Math.sqrt(sum);
		}
	}

	private double checkSouth(Mat img, int i, int j) {
		// TODO Auto-generated method stub
		if((i >= img.height() ) || (j >= img.width())) {
			return Double.MAX_VALUE;
		} else {
			double[] values = img.get(i, j);
			double[] val2 = img.get(i-1, j);
			double sum = 0;
			for (int k = 0; k < val2.length; k++) {
				sum += Math.pow(values[k]-val2[k], 2);
			}
			return Math.sqrt(sum);
		}
	}

	private double checkEast(Mat img, int i, int j) {
		// TODO Auto-generated method stub
		if((i <= 0 ) || (j >= img.width())) {
			return Double.MAX_VALUE;
		} else {
			double[] values = img.get(i, j);
			double[] val2 = img.get(i-1, j);
			double sum = 0;
			for (int k = 0; k < val2.length; k++) {
				sum += Math.pow(values[k]-val2[k], 2);
			}
			return Math.sqrt(sum);
		}
	}

	private double checkNorth(Mat img, int i, int j) {
		// TODO Auto-generated method stub
		if((i <= 0 ) || (j <= 0)) {
			return Double.MAX_VALUE;
		} else {
			double[] values = img.get(i, j);
			double[] val2 = img.get(i-1, j);
			double sum = 0;
			for (int k = 0; k < val2.length; k++) {
				sum += Math.pow(values[k]-val2[k], 2);
			}
			return Math.sqrt(sum);
		}
	}

	public LinkedList<Chromosome> randomSelection(LinkedList<Chromosome> population) {
		// TODO Auto-generated method stub
		Random rdm = new Random();
		Chromosome candidate1 = population.remove(rdm.nextInt(population.size()));
		Chromosome candidate2 = population.remove(rdm.nextInt(population.size()));
		
		Chromosome candidate3 = population.remove(rdm.nextInt(population.size()));
		Chromosome candidate4 = population.remove(rdm.nextInt(population.size()));
		population.add(candidate1);
		population.add(candidate2);
		population.add(candidate3);
		population.add(candidate4);
		LinkedList<Chromosome> parents = new LinkedList<Chromosome>();
		parents.add(comparisonOperator(candidate1,candidate2));
		parents.add(comparisonOperator(candidate3,candidate4));
		return parents;
	}

	private Chromosome comparisonOperator(Chromosome candidate1, Chromosome candidate2) {
		// TODO Auto-generated method stub
		Random rdm = new Random();
		if(candidate1.rank < candidate2.rank) {
			return candidate1;
		} else if (candidate1.rank > candidate2.rank){
			return candidate2;
		} else {
			if(candidate1.getCrowdingDistance() < candidate2.getCrowdingDistance()) {
				return candidate2;
			} else if(candidate1.getCrowdingDistance() > candidate2.getCrowdingDistance()) {
				return candidate1;
			} else {
				if (rdm.nextDouble() < 0.5) {
					return candidate1;
				}
			}
		}
		return candidate2;
	}

	public ArrayList<LinkedList<Chromosome>> fastNonDominatedSort(LinkedList<Chromosome> population) {
		// TODO Auto-generated method stub
		ArrayList<LinkedList<Chromosome>> fronts = new ArrayList<LinkedList<Chromosome>>();
		LinkedList<Chromosome> front1 = new LinkedList<Chromosome>();
		for (Chromosome chromosome : population) {
			LinkedList<Chromosome> dominates = new LinkedList<Chromosome>();
			int dominatedBy = 0;
			for (Chromosome chromosome2 : population) {
				if (!chromosome2.equals(chromosome)){
					
					int result = checkDomination(chromosome, chromosome2);
					switch (result) {
					//chromosome dominates chromosome2
					case -1:
						dominates.add(chromosome2);
						break;
					case 0:
						
						break;
					case 1:
						dominatedBy++;
						break;
						

					default:
						break;
					}
				}
			}
			if(dominatedBy == 0) {
				chromosome.setRank(0);
				front1.add(chromosome);
			}
			chromosome.dominatedBy = dominatedBy;
			chromosome.dominates = dominates;
		}
			int consideredFront = 0;
			fronts.add(front1);
			while (!fronts.get(consideredFront).isEmpty()) {
				LinkedList<Chromosome> nextFront = new LinkedList<Chromosome>();
				for (Chromosome chromo : fronts.get(consideredFront)) {
					LinkedList<Chromosome> removable = new LinkedList<Chromosome>();
					for (Chromosome chromo2 : chromo.dominates) {
						chromo2.dominatedBy--;
						if(chromo2.dominatedBy == 0) {
							chromo2.setRank(consideredFront+1);
							nextFront.add(chromo2);
							removable.add(chromo2);
						}
					}
					chromo.dominates.removeAll(removable);
				}
				consideredFront++;
				fronts.add(nextFront);
			}
		System.out.println("fronts: " + fronts.size());
		
		fronts.remove(fronts.size()-1);
		return fronts;
	}

	private int checkDomination(Chromosome chromosome, Chromosome chromosome2) {
		// TODO Auto-generated method stub
		boolean adomb = true;
		boolean bdoma = true;
		for (int i = 0; i < chromosome.objectives.size(); i++) {
			if(chromosome.objectives.get(i) <= chromosome2.objectives.get(i)) {
				bdoma = false;
			} else {
				adomb = false;
			}
		}
		if(adomb) {
			return -1;
		} else if (bdoma) {
			return 1;
		}
		return 0;
	}

	public LinkedList<Chromosome> crowndingDistanceAssignment(LinkedList<Chromosome> front) {
		// TODO Auto-generated method stub
		for (Chromosome chromosome : front) {
			chromosome.resetCrowdingDistances();
		}
		for (int i = 0; i < front.get(0).objectives.size(); i++) {
			front = sortOnObjective(front, i);
			front.getFirst().distances.set(i, Double.POSITIVE_INFINITY);
			front.getLast().distances.set(i, Double.POSITIVE_INFINITY);
			double min = front.getFirst().objectives.get(i);
			double max = front.getLast().objectives.get(i);
			for (int j = 1; j < front.size()-1; j++) {
				double prev = front.get(j).distances.get(i);
				front.get(j).distances.set(i, prev + ((front.get(j+1).objectives.get(i) - front.get(j-1).objectives.get(i))) /(max-min));
			}
		}
		return front;
	}

	private LinkedList<Chromosome> sortOnObjective(LinkedList<Chromosome> front, int i) {
		LinkedList<Chromosome> sorted = new LinkedList<Chromosome>();
		sorted.add(front.getFirst());
		for (int j = 1; j < front.size(); j++) {
			Chromosome nextChromo = front.get(j);
			boolean notSorted = true;
			int index = 0;
			while(notSorted) {
				if(index == sorted.size()) {
					sorted.add(nextChromo);
					notSorted = false;
				} else {
					if(nextChromo.objectives.get(i) < sorted.get(index).objectives.get(i)) {
						sorted.add(index, nextChromo);
						notSorted = false;
					}
				}
				index++;
			}
		}
		return sorted;
	}

	/**Create a child chromosome from parents
	 * 
	 * @param x parent1
	 * @param y parent2
	 * @return new child chromosome
	 */
	public Chromosome crossover(Chromosome x, Chromosome y) {
		// TODO Auto-generated method stub
		//initialize crossover
		ArrayList<ArrayList<Integer>> imageRep = new ArrayList<ArrayList<Integer>>();
		ArrayList<ArrayList<String>> unassimageRep = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<int[]>> segments = new ArrayList<ArrayList<int[]>>();
		ArrayList<String> rowsWithUnAssPixels = new ArrayList<String>();
		for (int i = 0; i < img.height(); i++) {
			ArrayList<Integer> nextLine = new ArrayList<Integer>();
			ArrayList<String> nextLineString = new ArrayList<String>();
			rowsWithUnAssPixels.add(i+"");
			for (int j = 0; j < img.width(); j++) {
				nextLine.add(-1);
				nextLineString.add(j + "");
			}
			unassimageRep.add(nextLineString);
			imageRep.add(nextLine);
		}
		
		Random rdm = new Random();
		int segmentNumber = 0;
		int pixelCount = 0;
		//start crossover method
		
		//while not all pixels assigned
				//select an unassigned pixel
				//pick parent 1 or 2
				//initiate a stack and push the top pixel
				//while stack not empty
					//next pixel = stack.pop and set pixel in child rep to segment number remove from unassigned pixels and increment pixel count.
					//for all neighbours of pixel do:
						//if neighbor is unassign in child and neighbor is in same segment in parent
							//push next pixel to stack
		
		while(pixelCount < this.img.height()*this.img.width()) {
			int[] nextunassPixel = selectUnassignPixel(unassimageRep, rowsWithUnAssPixels);
			Chromosome parent = selectRandom(x,y);
			int parentSeg = parent.imageRep.get(nextunassPixel[0]).get(nextunassPixel[1]);
			Queue<int[]> segQueue = new LinkedList<int[]>();
			segQueue.add(nextunassPixel);
			ArrayList<int[]> nextSegment = new ArrayList<int[]>();
			while(!segQueue.isEmpty()) {
				int[] nextPixel = segQueue.poll();
				imageRep.get(nextPixel[0]).set(nextPixel[1], segmentNumber);
				pixelCount++;
				nextSegment.add(nextPixel);
				//add pixel to new segment
				unassimageRep.get(nextPixel[0]).remove(nextPixel[1]+"");
				if(unassimageRep.get(nextPixel[0]).isEmpty()) {
					rowsWithUnAssPixels.remove(nextPixel[0]+"");
				}
				
					
			
				if ((checkEast(nextPixel[0], nextPixel[1]+1)) && (imageRep.get(nextPixel[0]).get(nextPixel[1]+1) == -1) 
						&& (parent.imageRep.get(nextPixel[0]).get(nextPixel[1]+1) == parentSeg)){
					int[] point = {nextPixel[0],nextPixel[1]+1};
					imageRep.get(point[0]).set(point[1], segmentNumber);
					segQueue.add(point);
				} 
				if ((checkWest(nextPixel[0], nextPixel[1]-1)) && (imageRep.get(nextPixel[0]).get(nextPixel[1]-1) == -1) 
						&& (parent.imageRep.get(nextPixel[0]).get(nextPixel[1]-1) == parentSeg)){
					int[] point = {nextPixel[0],nextPixel[1]-1};
					imageRep.get(point[0]).set(point[1], segmentNumber);
					segQueue.add(point);
				}
				if ((checkNorth(nextPixel[0]-1, nextPixel[1])) && (imageRep.get(nextPixel[0]-1).get(nextPixel[1]) == -1) 
				&& (parent.imageRep.get(nextPixel[0]-1).get(nextPixel[1]) == parentSeg)) {
					int[] point = {nextPixel[0]-1,nextPixel[1]};
					imageRep.get(point[0]).set(point[1], segmentNumber);
					segQueue.add(point);
				}
				if ((checkSouth(nextPixel[0]+1, nextPixel[1])) && (imageRep.get(nextPixel[0]+1).get(nextPixel[1]) == -1) 
				&& (parent.imageRep.get(nextPixel[0]+1).get(nextPixel[1]) == parentSeg)) {
					int[] point = {nextPixel[0]+1,nextPixel[1]};
					imageRep.get(point[0]).set(point[1], segmentNumber);
					segQueue.add(point);
				}
				
			}
			segments.add(nextSegment);
			segmentNumber++;
		}
		
		
		
		Chromosome chromo = new Chromosome(imageRep, segments, this.img);
		return chromo;
	}
	
	
	private int[] selectUnassignPixel(ArrayList<ArrayList<String>> unassimageRep,
			ArrayList<String> rowsWithUnAssPixels) {
		Random rdm = new Random();
		int rowIndex = rdm.nextInt(rowsWithUnAssPixels.size());
		int row = Integer.parseInt(rowsWithUnAssPixels.get(rowIndex));
		int colIndex = rdm.nextInt(unassimageRep.get(row).size());
		int col = Integer.parseInt(unassimageRep.get(row).get(colIndex));
		int[] nextPixel = {row, col};
		return nextPixel;
	}

	private Chromosome selectRandom(Chromosome x, Chromosome y) {
		// TODO Auto-generated method stub
		Random rdm = new Random();
		if(rdm.nextBoolean()){
			return x;
		}
		return y;
	}

	private ArrayList<int[]> insertSegment(ArrayList<ArrayList<String>> unassimageRep, ArrayList<ArrayList<Integer>> imageRep, ArrayList<int[]> segment, int segNr) {
		ArrayList<int[]> newSegment = new ArrayList<int[]>();
		for (int[] is : segment) {
			imageRep.get(is[0]).set(is[1], segNr);
			unassimageRep.get(is[0]).remove(is[1]+"");
			int[] newPoint = {is[0],is[1]};
			newSegment.add(newPoint);
		}
		return segment;
	}
	

	/** Sorts this front in descending order of distance (and domination)
	 * @param front
	 */
	public LinkedList<Chromosome> Sort(LinkedList<Chromosome> front) {
		// TODO Auto-generated method stub
		LinkedList<Chromosome> sortedFront = new LinkedList<Chromosome>();
		crowndingDistanceAssignment(front);
		sortedFront.add(front.getFirst());
		for (int j = 1; j < front.size(); j++) {
			Chromosome nextChromo = front.get(j);
			boolean notSorted = true;
			int index = 0;
			while(notSorted) {
				if(index == sortedFront.size()) {
					sortedFront.add(nextChromo);
					notSorted = false;
				} else {
					if(nextChromo.getCrowdingDistance() > sortedFront.get(index).getCrowdingDistance()) {
						sortedFront.add(index, nextChromo);
						notSorted = false;
					}
				}
				index++;
			}
		}
		return sortedFront;
	}

	public Chromosome mutate(Chromosome child, int iterations) {
		// TODO Auto-generated method stub
		Random rdm = new Random();
		MutationMethods mm = new MutationMethods(this.img);
		int mutationOperator = rdm.nextInt(1000);
		child = mm.borderPixelsMutation(child, 1);
		return child;
	}

}
