package assign3;

public class Pixel {

	int xCor;
	int yCor;
	double[] values;
	int number;
	
	
	public Pixel(int xCor, int yCor, double[] values) {
		this.xCor = xCor;
		this.yCor = yCor;
		this.values = values;
	}

	public int getxCor() {
		return xCor;
	}

	public int getyCor() {
		return yCor;
	}

	public double[] getValues() {
		return values;
	}
	
	
}
