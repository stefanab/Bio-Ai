package assign3;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.data.xyz.XYZDataset;
import com.orsoncharts.data.xyz.XYZSeries;
import com.orsoncharts.data.xyz.XYZSeriesCollection;
import com.orsoncharts.graphics3d.Dimension3D;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.plot.XYZPlot;
import com.orsoncharts.renderer.xyz.ScatterXYZRenderer;
import com.orsoncharts.*;

import assign3.MOEAMain.Globals;


public class ImageLoaderAndDisplayer {

	
	
	
	public Mat bufferedImageToMat(BufferedImage bi) {
		  Mat mat = new Mat(bi.getHeight(), bi.getWidth(), CvType.CV_8UC3);
		  byte[] data = ((DataBufferByte) bi.getRaster().getDataBuffer()).getData();
		  mat.put(0, 0, data);
		  return mat;
		}
	
	private BufferedImage Mat2BufferedImage(Mat m) {
	    // Fastest code
	    // output can be assigned either to a BufferedImage or to an Image

	    int type = BufferedImage.TYPE_BYTE_GRAY;
	    if ( m.channels() > 1 ) {
	        type = BufferedImage.TYPE_3BYTE_BGR;
	    }
	    int bufferSize = m.channels()*m.cols()*m.rows();
	    byte [] b = new byte[bufferSize];
	    m.get(0,0,b); // get all the pixels
	    BufferedImage image = new BufferedImage(m.cols(),m.rows(), type);
	    final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
	    System.arraycopy(b, 0, targetPixels, 0, b.length);  
	    return image;
	}
	
	public void displayImage(Mat m) {

	    //BufferedImage img=ImageIO.read(new File("/HelloOpenCV/lena.png"));
		Mat mat2 = new Mat();
		Imgproc.resize(m, mat2, new Size(m.width()*2, m.height()*2));
		BufferedImage img2 = Mat2BufferedImage(mat2);
	    ImageIcon icon=new ImageIcon(img2);
	    JFrame frame=new JFrame();
	    frame.setLayout(new FlowLayout());        
	    frame.setSize(img2.getWidth(null)+100, img2.getHeight(null)+100);     
	    JLabel lbl=new JLabel();
	    lbl.setIcon(icon);
	    frame.add(lbl);
	    frame.setVisible(true);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public Mat displayImageGreenLine(Mat m, Chromosome chromo) {
		Mat x = m.clone();
		for (int i = 0; i < chromo.imageRep.size(); i++) {
			for (int j = 0; j < chromo.imageRep.get(0).size(); j++) {
				int segnr = chromo.imageRep.get(i).get(j);
				if (checkEast(chromo.imageRep, i, j+1, segnr) || checkNorth(chromo.imageRep, i-1, j,segnr) || checkSouth(chromo.imageRep, i+1, j,segnr) || checkWest(chromo.imageRep, i, j-1,segnr)) {
					double[] tester = m.get(i, j);
					tester = change(tester);
					x.put(i, j, tester);
				}
			}
		}
		displayImage(x);
		return x;
	}
	
	public void displayImageBlackWhite(Mat m, Chromosome chromo) {
		Mat green = displayImageGreenLine(m, chromo);
		Mat x = green.clone();
		for (int i = 0; i < m.height(); i++) {
			for (int j = 0; j < m.width(); j++) {
				double[] values = x.get(i, j);
				values = changeBlack(values);
				x.put(i, j, values);
			}
		}
		displayImage(x);
	}
	
	private double[] changeBlack(double[] values) {
		if(values[0] == 0 && values[1] == 255 && values[2] == 0) {
			values[0] = 0;
			values[1] = 0;
			values[2] = 0;
			return values;
		} 
		values[0] = 255;
		values[1] = 255;
		values[2] = 255;
		return values;
	}

	public boolean checkEast(ArrayList<ArrayList<Integer>> m, int row, int col, int segmentNumber) {
		if(row <= 0 || row >= m.size() || col <= 0 || col >= m.get(0).size() ) {
			return true;
		} else {
			if(m.get(row).get(col) != segmentNumber ) {
				return true;
			}
		}
		return false;
	}
	
	public boolean checkNorth(ArrayList<ArrayList<Integer>> m, int row, int col, int segmentNumber) {
		if(row <= 0 || row >= m.size() || col <= 0 || col >= m.get(0).size() ) {
			return true;
		} else {
			if(m.get(row).get(col) != segmentNumber ) {
				return true;
			}
		}
		return false;
	}
	
	public boolean checkWest(ArrayList<ArrayList<Integer>> m, int row, int col,int segmentNumber) {
		if(row <= 0 || row >= m.size() || col <= 0 || col >= m.get(0).size() ) {
			return true;
		} else {
			if(m.get(row).get(col) != segmentNumber ) {
				return true;
			}
		}
		return false;
	}
	
	public boolean checkSouth(ArrayList<ArrayList<Integer>> m, int row, int col,int segmentNumber) {
		if(row <= 0 || row >= m.size() || col <= 0 || col >=m.get(0).size() ) {
			return true;
		} else {
			if(m.get(row).get(col) != segmentNumber ) {
				return true;
			}
		}
		return false;
	}

	private double[] change(double[] tester) {
		tester[0] = 0;
		tester[1] = 255;
		tester[2] = 0;
		return tester;
	}
	

	public Mat convertToGrayscale(Mat img) {
		Mat mat1 = new Mat();
		Imgproc.cvtColor(img, mat1, Imgproc.COLOR_RGB2GRAY);
		return mat1;
	}
	
	public void plotParetoFront(ArrayList<LinkedList<Chromosome>> fronts) {
		
		if(Globals.OBJECTIVE_FUNCTIONS != 3) {
			
		XYDataset serie = createDataset( fronts);
//		XYDataset serie1 = createDatasetD( depots);
		 // create a chart...
		
        JFreeChart chart = ChartFactory.createScatterPlot(
            "Scatter Plot fronts", // chart title
            "X", // x axis label
            "Y", // y axis label
            serie, // data  ***-----PROBLEM------***
            PlotOrientation.VERTICAL,
            true, // include legend
            true, // tooltips
            false // urls
            );

        // create and display a frame...
        XYPlot plot = (XYPlot) chart.getPlot();
        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(false, true);
       renderer.setSeriesLinesVisible(0, false);
       renderer.setSeriesLinesVisible(1, false);
        plot.setRenderer(renderer);
        plot.setBackgroundPaint(Color.white);
        
        ChartFrame frame = new ChartFrame("First", chart);
        frame.pack();
        frame.setSize(1600, 1600);
        frame.setVisible(true);
		} else {
			System.out.println("her");
			XYZDataset serie = createDataset3d( fronts);
			Chart3D chart = Chart3DFactory.createScatterChart("Pareto fronts", "image seg", serie, "X", "Y", "Z");
			XYZPlot plot = (XYZPlot) chart.getPlot();
			
			ScatterXYZRenderer renderer = new ScatterXYZRenderer();
			plot.setRenderer(renderer);
			Chart3DPanel panel = new Chart3DPanel(chart);
			panel.setSize(1600, 1600);
	        panel.setVisible(true);
	        renderer.setSize(.3);
	        plot.setDimensions(new Dimension3D(10, 10, 10));
	        DisplayPanel3D display = new DisplayPanel3D(panel);
	        display.setSize(1600,1600);
	        display.setVisible(true);
	        JFrame frame = new JFrame("3d");
	        frame.getContentPane().add(display);
	        frame.pack();
	        frame.setSize(1600, 1600);
	        frame.setVisible(true);
		}
	}
	
	private XYZDataset createDataset3d(ArrayList<LinkedList<Chromosome>> fronts) {
		ArrayList<XYZSeries> dataFronts = new ArrayList<XYZSeries>();
	      for (int i = 0; i < fronts.size(); i++) {
	    	  LinkedList<Chromosome> currentFront = fronts.get(i);
	    	  final XYZSeries front = new XYZSeries( "front "+i );   
	    	  
	    	  for (int j = 0; j < currentFront.size(); j++) {
	    		  front.add(currentFront.get(j).objectives.get(0),  currentFront.get(j).objectives.get(1), currentFront.get(j).objectives.get(2));
				
	    	  }
	    	  dataFronts.add(front);
		  }      
	      
	      final XYZSeriesCollection dataset = new XYZSeriesCollection( );
	      for (XYZSeries front : dataFronts) {
			dataset.add(front);
		}
	      
	      return dataset;
	}
	
	private XYDataset createDataset(ArrayList<LinkedList<Chromosome>> fronts)
	   {
	    int first = 0;
	    int second = 1;
		
		
	      //create route series
	      ArrayList<XYSeries> dataFronts = new ArrayList<XYSeries>();
	      for (int i = 0; i < fronts.size(); i++) {
	    	  LinkedList<Chromosome> currentFront = fronts.get(i);
	    	  final XYSeries front = new XYSeries( "front "+i,true );          
	    	  for (int j = 0; j < currentFront.size(); j++) {
	    		  front.add(currentFront.get(j).objectives.get(first),  currentFront.get(j).objectives.get(second));
				
	    	  }
	    	  dataFronts.add(front);
		  }      
	      
	      final XYSeriesCollection dataset = new XYSeriesCollection( );          
	      for (XYSeries front : dataFronts) {
			dataset.addSeries(front);
		}
	      
	      return dataset;
	   }
	
}
