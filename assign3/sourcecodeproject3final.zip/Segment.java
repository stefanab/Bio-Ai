package assign3;

import java.util.LinkedList;


public class Segment {

	LinkedList<Pixel> pixels;
	double centroidPixelRed;
	double centroidPixelGreen;
	double centroidPixelBlue;
	
	
	public Segment() {
		this.pixels = new LinkedList<Pixel>();
		this.centroidPixelRed = 0;
		this.centroidPixelGreen = 0;
		this.centroidPixelBlue = 0;
	}
	
	public void addPixel(Pixel pixel) {
		if(pixels.isEmpty()) {
			pixels.add(pixel);
		} else {
			int xCor = pixel.getxCor();
			int consideredPixels = pixels.size();
			int startIndex = 0;
			while(consideredPixels > 1) {
				int correctionIndex = Math.floorMod(consideredPixels, 2);
				consideredPixels = Math.floorDiv(consideredPixels, 2);
				Pixel consideredPixel = pixels.get(consideredPixels+startIndex);
				if (xCor < consideredPixel.getxCor()) {
					
				} else if(xCor > consideredPixel.getxCor()) {
					startIndex += consideredPixels+ correctionIndex;
				} else {
					if (pixel.getyCor() < consideredPixel.getyCor()) {
					} else {
						startIndex += consideredPixels+ correctionIndex;
					}
				}
			}
			if(startIndex == pixels.size()-1) {
				pixels.add(pixel);
			} else {
				if (pixels.get(startIndex).getxCor() > xCor || 
						(pixels.get(startIndex).getxCor() == xCor && pixels.get(startIndex).getyCor() > pixel.getyCor())) {
					pixels.add(startIndex+1, pixel);
				}
				 else {
					pixels.add(startIndex, pixel);
				}
			}
		}
		double[] pixelValues = pixel.values;
		centroidPixelRed += pixelValues[0];
		centroidPixelGreen += pixelValues[1];
		centroidPixelBlue += pixelValues[2];
	}
}
