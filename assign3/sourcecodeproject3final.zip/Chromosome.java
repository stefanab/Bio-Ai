package assign3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

import org.opencv.core.Mat;

import assign3.MOEAMain.Globals;

public class Chromosome {

	ArrayList<ArrayList<Integer>> imageRep;
	int numberOfSegments;
	ArrayList<ArrayList<int[]>> segments;
	double fitnessOverallDeviation;
	double fitnessEdgeValue;
	double fitnessConnectivityMeasure;
	Mat image;
	int rank;
	double distOverallDeviation;
	double distEdgeValue;
	double distConnectivityMeasure;
	ArrayList<Double> objectives;
	ArrayList<Double> distances;
	int dominatedBy;
	LinkedList<Chromosome> dominates;
	
	
	public double getCrowdingDistance() {
		double sum = 0;
		for (Double dist : distances) {
			sum += dist;
		}
		return sum;
	}

	public void resetCrowdingDistances() {
		for (int i = 0; i < distances.size(); i++) {
			distances.set(i, 0.0);
		}
	}
	

	public Chromosome(ArrayList<ArrayList<Integer>> imageRep, ArrayList<ArrayList<int[]>> segments, Mat image) {
		this.image = image;
		this.imageRep = imageRep;
		this.segments = segments;
		this.rank = 1000;
		this.numberOfSegments =0;
		this.fitnessConnectivityMeasure = connectivityMeasure();
		this.fitnessEdgeValue = edgeValue();
		this.fitnessOverallDeviation = overallDeviation(segments);
		ArrayList<Double> objectives = new ArrayList<Double>();
		ArrayList<Double> distances = new ArrayList<Double>();
		switch (Globals.OBJECTIVE_FUNCTIONS) {
		case 0:
			objectives.add(this.fitnessEdgeValue);
			objectives.add(this.fitnessConnectivityMeasure);
			distances.add(this.distEdgeValue);
			distances.add(this.distConnectivityMeasure);
			break;
		case 1:
			objectives.add(this.fitnessEdgeValue);
			objectives.add(this.fitnessOverallDeviation);
			distances.add(this.distEdgeValue);
			distances.add(this.distOverallDeviation);
			break;
		case 2:
			objectives.add(this.fitnessConnectivityMeasure);
			objectives.add(this.fitnessOverallDeviation);
			distances.add(this.distConnectivityMeasure);
			distances.add(this.distOverallDeviation);
			break;
		case 3:
			objectives.add(this.fitnessEdgeValue);
			objectives.add(this.fitnessOverallDeviation);
			objectives.add(this.fitnessConnectivityMeasure);
			distances.add(this.distEdgeValue);
			distances.add(this.distOverallDeviation);
			distances.add(this.distConnectivityMeasure);
			break;

		default:
			objectives.add(this.fitnessEdgeValue);
			objectives.add(this.fitnessOverallDeviation);
			objectives.add(this.fitnessConnectivityMeasure);
			this.distOverallDeviation = 0;
			this.distEdgeValue = 0;
			this.distConnectivityMeasure = 0;
			distances.add(this.distEdgeValue);
			distances.add(this.distOverallDeviation);
			distances.add(this.distConnectivityMeasure);
			break;
		}
		this.objectives = objectives;
		this.distances = distances;
	}

	public int getRank() {
		return rank;
	}
	
	public void setRank(int rank) {
		this.rank = rank;
	}
	
	
	private double connectivityMeasure() {
		double connectivitySum = 0;
		for (int i = 0; i < imageRep.size(); i++) {
			for (int j = 0; j < imageRep.get(0).size(); j++) {
				LinkedList<Double> js = new LinkedList<Double>();
				for (int k = 0; k < Globals.NEAREST_NEIGHBORS; k++) {
					js.add((double) k+1);
				}
				Random rdm = new Random();
				
					connectivitySum += (double) checkEast(i, j+1)/(double)js.remove(rdm.nextInt(js.size()));
					connectivitySum += checkNorth(i-1, j)/js.remove(rdm.nextInt(js.size()));
					connectivitySum += checkSouth(i+1, j)/js.remove(rdm.nextInt(js.size()));
					connectivitySum += checkWest(i, j-1)/js.remove(rdm.nextInt(js.size()));
			}
		}
		return connectivitySum;
	}


	private double edgeValue() {
		double edgeSum = 0;
		for (int i = 0; i < imageRep.size(); i++) {
			for (int j = 0; j < imageRep.get(0).size(); j++) {
				edgeSum += checkEast(i, j+1);
				edgeSum += checkNorth(i-1, j);
				edgeSum += checkSouth(i+1, j);
				edgeSum += checkWest(i, j-1);
			}
		}
		return -edgeSum;
	}
	
	public double singleEdgeValue(int row, int col) {
		double edgeSum = 0;
		double val = checkEast(row, col+1);
		double dir = 0.0;
		if(val != 0) {
			dir++;
			edgeSum += val;
		}
		val = checkNorth(row-1, col);
		if(val != 0) {
			dir++;
			edgeSum += val;
		}
		val = checkSouth(row+1, col);
		if(val != 0) {
			dir++;
			edgeSum += val;
		}
		val = checkWest(row, col-1);
		if(val != 0) {
			dir++;
			edgeSum += val;
		}
		if(dir != 0) {
			return -edgeSum/dir;
			
		}
		return 0;
	}

	public void updateObjectiveValues() {
		this.fitnessConnectivityMeasure = connectivityMeasure();
		this.fitnessEdgeValue = edgeValue();
		this.fitnessOverallDeviation = overallDeviation(this.segments);
		ArrayList<Double> objectives = new ArrayList<Double>();
		ArrayList<Double> distances = new ArrayList<Double>();
		switch (Globals.OBJECTIVE_FUNCTIONS) {
		case 0:
			objectives.add(this.fitnessEdgeValue);
			objectives.add(this.fitnessConnectivityMeasure);
			distances.add(this.distEdgeValue);
			distances.add(this.distConnectivityMeasure);
			break;
		case 1:
			objectives.add(this.fitnessEdgeValue);
			objectives.add(this.fitnessOverallDeviation);
			distances.add(this.distEdgeValue);
			distances.add(this.distOverallDeviation);
			break;
		case 2:
			objectives.add(this.fitnessConnectivityMeasure);
			objectives.add(this.fitnessOverallDeviation);
			distances.add(this.distConnectivityMeasure);
			distances.add(this.distOverallDeviation);
			break;
		case 3:
			objectives.add(this.fitnessEdgeValue);
			objectives.add(this.fitnessOverallDeviation);
			objectives.add(this.fitnessConnectivityMeasure);
			distances.add(this.distEdgeValue);
			distances.add(this.distOverallDeviation);
			distances.add(this.distConnectivityMeasure);
			break;

		default:
			objectives.add(this.fitnessEdgeValue);
			objectives.add(this.fitnessOverallDeviation);
			objectives.add(this.fitnessConnectivityMeasure);
			this.distOverallDeviation = 0;
			this.distEdgeValue = 0;
			this.distConnectivityMeasure = 0;
			distances.add(this.distEdgeValue);
			distances.add(this.distOverallDeviation);
			distances.add(this.distConnectivityMeasure);
			break;
		}
		this.objectives = objectives;
		this.distances = distances;
	}

	private double overallDeviation(ArrayList<ArrayList<int[]>> segments) {
		// TODO Auto-generated method stub
		double sum = 0;
		for (ArrayList<int[]> segment : segments) {
			sum += segmentDeviation(segment);
		}
		return sum;
	}

	public double[] centroidPixel(ArrayList<int[]> segment) {
		double red = 0;
		double green = 0;
		double blue = 0;
		for (int[] is : segment) {
			
			double[] values = image.get(is[0], is[1]);
			red += values[0];
			green += values[1];
			blue += values[2];
		}
		red = red/segment.size();
		green = green/segment.size();
		blue = blue/segment.size();
		double[] avgPixel = {red, green, blue};
		return avgPixel;
	}
	
	private double segmentDeviation(ArrayList<int[]> segment) {
		double red = 0;
		double green = 0;
		double blue = 0;
		for (int[] is : segment) {
			
			double[] values = image.get(is[0], is[1]);
			red += values[0];
			green += values[1];
			blue += values[2];
		}
		red = red/segment.size();
		green = green/segment.size();
		blue = blue/segment.size();
		double[] avgPixel = {red, green, blue};
		double deviation = 0;
		for (int[] is : segment) {
			deviation += euclideanColorDistance(image.get(is[0], is[1]), avgPixel);
		}
		return deviation;
	}
	
	private double euclideanColorDistance(double[] pixel1, double[] pixel2) {
		 double red = Math.pow(pixel1[0]-pixel2[0], 2);
		 double green = Math.pow(pixel1[1]-pixel2[1], 2);
		 double blue = Math.pow(pixel1[2]-pixel2[2], 2);
		 return Math.sqrt(red+green+blue);
	 }
	
	public double checkEast(int row, int col) {
		if(row < 0 || row >= imageRep.size() || col <= 0 || col >= imageRep.get(0).size()) {
			return 0;
		} else {
			return checkEdge(row, col, row, col-1);
		}
	}
	
	public double checkNorth(int row, int col) {
		if(row < 0 || row >= imageRep.size() || col < 0 || col >= imageRep.get(0).size()) {
			return 0;
		} else {
			return checkEdge(row, col,row+1,col);
		}
	}
	
	public double checkWest(int row, int col) {
		if(row < 0 || row >= imageRep.size() || col < 0 || col >= imageRep.get(0).size()) {
			return 0;
		} else {
			return checkEdge(row, col,row,col+1);
		}
	}
	
	public double checkSouth(int row, int col) {
		if(row <= 0 || row >= imageRep.size() || col < 0 || col >= imageRep.get(0).size()) {
			return 0;
		} else {
			return checkEdge(row, col,row-1,col);
		}
	}


	private double checkEdge(int row, int col, int i, int col2) {
		// TODO Auto-generated method stub
		if(imageRep.get(row).get(col) == imageRep.get(i).get(col2)) {
			return 0;
		} else {
			double[] val1 = image.get(row, col);
			double[] val2 = image.get(i, col2);
			return euclideanColorDistance(val1, val2);
		}
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Edge: " + fitnessEdgeValue + " | Con: " + fitnessConnectivityMeasure + " | Dev: " + fitnessOverallDeviation;
	}
}
