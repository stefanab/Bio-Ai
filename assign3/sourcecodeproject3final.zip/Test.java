package assign3;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.CvType;
import org.opencv.core.MatOfByte;
import org.opencv.core.Size;

import org.opencv.imgproc.Imgproc;

public class Test
{
	
	public static Mat bufferedImageToMat(BufferedImage bi) {
		  Mat mat = new Mat(bi.getHeight(), bi.getWidth(), CvType.CV_8UC3);
		  byte[] data = ((DataBufferByte) bi.getRaster().getDataBuffer()).getData();
		  mat.put(0, 0, data);
		  return mat;
		}
	


	 public static BufferedImage Mat2BufferedImage(Mat m) {
		    // Fastest code
		    // output can be assigned either to a BufferedImage or to an Image

		    int type = BufferedImage.TYPE_BYTE_GRAY;
		    if ( m.channels() > 1 ) {
		        type = BufferedImage.TYPE_3BYTE_BGR;
		    }
		    int bufferSize = m.channels()*m.cols()*m.rows();
		    byte [] b = new byte[bufferSize];
		    m.get(0,0,b); // get all the pixels
		    BufferedImage image = new BufferedImage(m.cols(),m.rows(), type);
		    final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
		    System.arraycopy(b, 0, targetPixels, 0, b.length);  
		    return image;
		}
	 
	 public static void displayImage(BufferedImage img2) {

		    //BufferedImage img=ImageIO.read(new File("/HelloOpenCV/lena.png"));
		    ImageIcon icon=new ImageIcon(img2);
		    JFrame frame=new JFrame();
		    frame.setLayout(new FlowLayout());        
		    frame.setSize(img2.getWidth(null)+100, img2.getHeight(null)+100);     
		    JLabel lbl=new JLabel();
		    lbl.setIcon(icon);
		    frame.add(lbl);
		    frame.setVisible(true);
		    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}

	 public static double euclideanColorDistance(double[] pixel1, double[] pixel2) {
		 double red = Math.pow(pixel1[0]-pixel2[0], 2);
		 double green = Math.pow(pixel1[1]-pixel2[1], 2);
		 double blue = Math.pow(pixel1[2]-pixel2[2], 2);
		 return Math.sqrt(red+green+blue);
	 }
	
   public static void main( String[] args )
   {
      System.loadLibrary( Core.NATIVE_LIBRARY_NAME );
      File input = new File("C:\\Users\\Stefan\\Desktop\\NTNU\\IT3708BioAI\\assign3\\TestImage\\TestImage\\1\\TestImage.jpg");
      try {
		BufferedImage img2 = ImageIO.read(input);
		Mat img = bufferedImageToMat(img2);
		Color c = new Color(img2.getRGB(0, 0));
		Mat mat1 = new Mat();
		Imgproc.cvtColor(img,mat1, Imgproc.COLOR_RGB2GRAY);
		displayImage(Mat2BufferedImage(mat1));
		double[] value = img.get(0, 0);
		double[] value1 = img.get(1, 0);
		
		System.out.println(euclideanColorDistance(value, value1));
		for (int i = 0; i < img.height(); i++) {
			for (int j = 0; j < img.width()-1; j++) {
				value = img.get(i, j);
				value1 = img.get(i, j+1);
				System.out.println(euclideanColorDistance(value, value1));
				
			}
		}
		Mat mat2 = new Mat();
		Imgproc.filter2D(img, mat2, -1, Imgproc.getStructuringElement(Imgproc.MORPH_CROSS, new Size(2, 2)), new Point(-1,-1), 0);
		Imgproc.rectangle(img, new Point(5, 5), new Point(100, 100), new Scalar(0, 255, 0));
		Imgproc.resize(img, img, new Size(img.width()*2, img.height()*2));
		double[] tester = img.get(20, 40);
		tester = change(tester);
		img.put(20, 40, tester);
		displayImage(Mat2BufferedImage(img));
		displayImage(Mat2BufferedImage(mat2));
      } catch (IOException e) {
    	  // TODO Auto-generated catch block
    	  e.printStackTrace();
      }	

   }



private static double[] change(double[] tester) {
	tester[0] = 0;
	tester[1] = 255;
	tester[2] = 0;
	return tester;
}
   
}