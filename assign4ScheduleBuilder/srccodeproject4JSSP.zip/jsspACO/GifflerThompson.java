package jsspACO;

import java.util.ArrayList;
import java.util.LinkedList;

import jssp.Operation;

public class GifflerThompson {

	
	int numberOfJobs;
	int numberOfOperations;
	ArrayList<ArrayList<Integer>> jobs;
	ArrayList<ArrayList<Integer>> operationDurations;
	
	
	public GifflerThompson(int numberOfJobs, int numberOfOperations, 
			ArrayList<ArrayList<Integer>> jobs, ArrayList<ArrayList<Integer>> operationDurations) {
		this.numberOfJobs = numberOfJobs;
		this.numberOfOperations = numberOfOperations;
		this.jobs = jobs;
		this.operationDurations = operationDurations;
		
	}
	
	
	/**
	 * @param particle  The particle to calculate the Giffler Thompson algorithm on. The algorithm has to
	 * 					update the fitness value of the particle and should maybe also return the full schedule created.
	 */
	public LinkedList<LinkedList<Operation>> gifflerThompson(LinkedList<LinkedList<Integer>> particlePosition) {
		// index of next operation in job k
		LinkedList<Integer> earliestTimeMachineIIsAvailable = new LinkedList<>();
		LinkedList<Integer> nextOperationIndexOnJobK = new LinkedList<>();
		// the schedule of the particle given as a numberOfmachines*numberofOperations matrix
		LinkedList<LinkedList<Operation>> schedule = new LinkedList<>();
		// the preference list for this particle
		LinkedList<LinkedList<Integer>> preferenceList = particlePosition;
		// finish time of previous operation = earliest starttime for next operation
		LinkedList<Integer> earliestStartTimeOfNextOperation = new LinkedList<>();
		for (int i = 0; i < this.numberOfOperations; i++) {
			earliestTimeMachineIIsAvailable.add(0);
			schedule.add(new LinkedList<Operation>());
			
		}
		for (int i = 0; i < this.numberOfJobs; i++) {
			nextOperationIndexOnJobK.add(0);
			earliestStartTimeOfNextOperation.add(0);
		}
		
		//end initialization
		
		while(!allScheduled(nextOperationIndexOnJobK)) {
			LinkedList<Integer> earliestFinishTimes = new LinkedList<>();
			int earliestIndex = 0;
			int earliestTime = Integer.MAX_VALUE;
			// find the machine with earliest finish time
			for (int i = 0; i < nextOperationIndexOnJobK.size(); i++) {
				int nextOpIndexOnK = nextOperationIndexOnJobK.get(i);
				if(nextOpIndexOnK < this.numberOfOperations) {
					int nextTime = earliestStartTimeOfNextOperation.get(i) + this.operationDurations.get(i)
					.get(nextOpIndexOnK);
					if(nextTime < earliestTime) {
						earliestTime = nextTime;
						earliestIndex = i;
					}
					earliestFinishTimes.add(nextTime);
				} 
				else {
					earliestFinishTimes.add(Integer.MAX_VALUE);
				}
			}
			//////!!!!! update starting times if the next operation for a job is on the same machine as the operation selected this iteration
			
			//find all indices for operations with earlier start time on the machine with earliest finish time
			int machineStar = jobs.get(earliestIndex).get(nextOperationIndexOnJobK.get(earliestIndex));
			LinkedList<Integer> indexOfJobsForPotentialOperations = new LinkedList<>();
			LinkedList<Integer> indexOfJobsWithNextOpOnSameMachine = new LinkedList<>();
			for (int i = 0; i < nextOperationIndexOnJobK.size(); i++) {
				int nextOpIndexOnK = nextOperationIndexOnJobK.get(i);
				if(nextOpIndexOnK < this.numberOfOperations && jobs.get(i).get(nextOpIndexOnK) == machineStar) {
					indexOfJobsWithNextOpOnSameMachine.add(i);
					if(earliestStartTimeOfNextOperation.get(i) < earliestTime ) {
						indexOfJobsForPotentialOperations.add(i);
					}
				}
			}
			for (Integer integer : indexOfJobsForPotentialOperations) {
			}
			// check for priority on the possible operations
			LinkedList<Integer> machinePreferences = preferenceList.get(machineStar);
			int prefered = -1;
			for (Integer preference : machinePreferences) {
				if(indexOfJobsForPotentialOperations.contains(preference)) {
					prefered = preference;
					break;
				}
			}
			
			//add chosen operation to schedule 
			Operation op = new Operation(earliestStartTimeOfNextOperation.get(prefered),
					operationDurations.get(prefered).get(nextOperationIndexOnJobK.get(prefered)), prefered);
			schedule.get(jobs.get(prefered).get(nextOperationIndexOnJobK.get(prefered))).
			add(op);
			
			// update starting time for the next job and for all other jobs which have dependencies on the same machine
			int time = earliestStartTimeOfNextOperation.get(prefered);
			time += operationDurations.get(prefered).get(nextOperationIndexOnJobK.get(prefered));
			earliestTimeMachineIIsAvailable.set(machineStar, time);
			for (Integer job : indexOfJobsWithNextOpOnSameMachine) {
				int startTime = earliestStartTimeOfNextOperation.get(job);
				earliestStartTimeOfNextOperation.set(job, Math.max(time, startTime));
			}
			
			// add next operation to operation set (increment index)
			int prevOpIndex = nextOperationIndexOnJobK.get(prefered) + 1;
			nextOperationIndexOnJobK.set(prefered, prevOpIndex);
			//update earliest start time of new operation (check if the new starttime isnt even higher
			if(prevOpIndex < this.numberOfOperations) {
			earliestStartTimeOfNextOperation.set(prefered, Math.max(earliestStartTimeOfNextOperation.get(prefered), 
					earliestTimeMachineIIsAvailable.get(this.jobs.get(prefered).get(nextOperationIndexOnJobK.get(prefered)))));
			}
		}
	
		return schedule;
	}


	private boolean allScheduled(LinkedList<Integer> nextOperationOnJobK) {
		for (Integer operation : nextOperationOnJobK) {
			if(operation < this.numberOfOperations) {
				return false;
			}
		}
		return true;
	}
	
	public int calculateFitness(LinkedList<LinkedList<Operation>> schedule) {
		int longestRunningMachineTime = 0;
		for (LinkedList<Operation> machine : schedule) {
			int totalTime = 0;
			int prevFinish = 0;
			
			for (Operation operation : machine) {
				totalTime += operation.getStartTime() - prevFinish + operation.getDuration();
				prevFinish = operation.getStartTime() + operation.getDuration();
			}
			if(totalTime > longestRunningMachineTime) {
				longestRunningMachineTime = totalTime;
			}
		}
		return longestRunningMachineTime;
	}
}
