package jsspACO;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

import jssp.GanttSolution;
import jssp.Operation;
import jssp.Solution;
import jsspACO.ACOMain.ACOGlobals;

public class ACO {

	
	
	private int numberOfOperations;
	private int numberOfJobs;
	private ArrayList<ArrayList<Integer>> jobs;
	private ArrayList<ArrayList<Integer>> operationDurations;
	private Solution gBest;
	private ArrayList<LinkedList<LinkedList<Double>>> pathNetwork;
	
	public ACO(ArrayList<ArrayList<Integer>> jobs, ArrayList<ArrayList<Integer>> operationDurations) {
		this.jobs = jobs;
		this.operationDurations = operationDurations;
		this.numberOfOperations = jobs.get(0).size();
		this.numberOfJobs = jobs.size();
		this.gBest = new Solution(null, Integer.MAX_VALUE);
		
	}
	
	
	public GanttSolution ACOMainLoop() {
		System.out.println("initializing...");
		initializeNetwork();
		
		System.out.println("start optimizing...");
		int iterations = 0;
		while(!termination(this.gBest.getFitness(), iterations)) {
			System.out.println("iteration number: " + iterations);
			LinkedList<ACOAnt> iterationAnts = new LinkedList<>();
			for (int i = 0; i < ACOGlobals.NUMBER_OF_ANTS; i++) {
				ACOAnt nextAnt = generateAntSolution();
				applyLocalPheromoneUpdateRule(nextAnt);
				iterationAnts.add(nextAnt);
				
			}
			applyLocalSearch(iterationAnts);
			
			LinkedList<ACOAnt> iBests = findBestSolution(iterationAnts);
			ACOAnt iBest = iBests.getFirst();
			if(iBest.getpBest().getFitness() < this.gBest.getFitness()) {
				this.gBest = iBest.getpBest();
			}
			updateDecayPheromone();
			updateBestPheromone(iBest);
			
			System.out.println("best fitness so far: " + this.gBest.getFitness());
			iterations++;
		}
		
		
		
		
		return new GanttSolution(this.gBest);
	}


	private void updateDecayPheromone() {
		// TODO Auto-generated method stub
		for (int i = 0; i < this.pathNetwork.size(); i++) {
			LinkedList<LinkedList<Double>> machine = this.pathNetwork.get(i);
			for (int j = 0; j < machine.size(); j++) {
				LinkedList<Double> stage = machine.get(j);
				for (int k = 0; k < stage.size(); k++) {
					double val = decayFunction(stage.get(k));
					stage.set(k, val);
				}
			}
		}
	}


	private double decayFunction(Double oldVal) {
		// TODO Auto-generated method stub
		double newVal = oldVal * ACOGlobals.DECAY_VALUE;
		return newVal;
	}


	private void updateBestPheromone(ACOAnt iBest) {
		// TODO Auto-generated method stub
		//IMPLEMENT
		LinkedList<LinkedList<Integer>> position = iBest.getpBest().getPosition();
		for (int i = 0; i < this.pathNetwork.size(); i++) {
			LinkedList<LinkedList<Double>> paths = pathNetwork.get(i);
			LinkedList<Integer> preference = position.get(i);
			for (int j = 0; j < paths.size(); j++) {
				LinkedList<Double> singlePaths = paths.get(j);
				int chosenPath = preference.get(j);
				double pathPheromone = singlePaths.get(chosenPath);
				pathPheromone = updatePheromone(pathPheromone, iBest.getpBest().getFitness());
				singlePaths.set(chosenPath, pathPheromone);
			}
		}
		
	}




	private double updatePheromone(double pathPheromone, int makespan) {
		// TODO Auto-generated method stub
		//IMPLEMENT some update function for the paths
		double newPheromoneValue = pathPheromone + ACOGlobals.PHEROMONE_DECAY * 1/makespan;
		return newPheromoneValue;
	}


	private void applyLocalSearch(LinkedList<ACOAnt> iterationAnts) {
		// TODO Auto-generated method stub
		//IMPLEMENT
	}


	private void applyLocalPheromoneUpdateRule(ACOAnt nextAnt) {
		// TODO Auto-generated method stub
		//IMPLEMENT
	}

	private LinkedList<ACOAnt> findBestSolution(LinkedList<ACOAnt> iterationAnts) {
		LinkedList<ACOAnt> ibests = new LinkedList<>();
		ACOAnt bestAnt = iterationAnts.getFirst();
		for (ACOAnt acoAnt : iterationAnts) {
			if (acoAnt.getpBest().getFitness() < bestAnt.getpBest().getFitness()) {
				bestAnt = acoAnt;
			}
		}
		ibests.add(bestAnt);
		return ibests;
	}

	private ACOAnt generateAntSolution() {
		LinkedList<LinkedList<Integer>> position = new LinkedList<>();
		for (int i = 0; i < this.pathNetwork.size(); i++) {
			LinkedList<LinkedList<Double>> machine = this.pathNetwork.get(i);
			LinkedList<Integer> preferenceOnMachineI = new LinkedList<>();
			LinkedList<Integer> nonVisitedNodes = getFreshNonVisitedList();
			for (int j = 0; j < this.numberOfJobs; j++) {
				int nextPreference = findNextPreference(nonVisitedNodes, machine.get(j));
				preferenceOnMachineI.add(nextPreference);
			}
			position.add(preferenceOnMachineI);
		}
		ACOAnt ant = createAnt(position);
		
		return ant;
	}


	private ACOAnt createAnt(LinkedList<LinkedList<Integer>> position) {
		GifflerThompson gt = new GifflerThompson(this.numberOfJobs, this.numberOfOperations, this.jobs, this.operationDurations);
		LinkedList<LinkedList<Operation>> schedule = gt.gifflerThompson(position);
		int fitness = gt.calculateFitness(schedule);
		Solution solution = new Solution(position, fitness);
		ACOAnt ant = new ACOAnt(solution);
		return ant;
	}


	private int findNextPreference(LinkedList<Integer> nonVisitedNodes, LinkedList<Double> machineStage) {
		double sumOfNonVisited = 0;
		for (int i = 0; i < nonVisitedNodes.size(); i++) {
			sumOfNonVisited += machineStage.get(nonVisitedNodes.get(i));
		}
		LinkedList<Double> probabilities = new LinkedList<>();
		for (int i = 0; i < nonVisitedNodes.size(); i++) {
			int nextNode = nonVisitedNodes.get(i);
			probabilities.add(machineStage.get(nextNode)/sumOfNonVisited);
		}
		int nextIndex = activate(probabilities);
		int nextPreference = nonVisitedNodes.remove(nextIndex);
		return nextPreference;
	}


	private int activate(LinkedList<Double> probabilities) {
		Random rdm = new Random();
		int considered = rdm.nextInt(probabilities.size());
		boolean activated = false;
		while(!activated) {
			if(probabilities.get(considered) > rdm.nextDouble()) {
				activated = true;
			} else {
				considered = rdm.nextInt(probabilities.size());
			}
		}
			
		return considered;
	}


	private LinkedList<Integer> getFreshNonVisitedList() {
		LinkedList<Integer> list = new LinkedList<>();
		for (int i = 0; i < this.numberOfJobs; i++) {
			list.add(i);
		}
		return list;
	}


	private void initializeNetwork() {
		// TODO Auto-generated method stub
		//CONSIDER OF THIS IS THE RIGHT IMPLEMENTATION
		ArrayList<LinkedList<LinkedList<Double>>> network = new ArrayList<>();
		for (int i = 0; i < this.numberOfOperations; i++) {
			LinkedList<LinkedList<Double>> machine = new LinkedList<>();
			for (int j = 0; j < this.numberOfJobs; j++) {
				LinkedList<Double> jobNodes = new LinkedList<>();
				for (int k = 0; k < this.numberOfJobs; k++) {
					jobNodes.add(ACOGlobals.INITIAL_PHEROMONE_VALUE);
				}
				machine.add(jobNodes);
			}
			network.add(machine);
		}
		this.pathNetwork = network;
	}
	
	private boolean termination(int fitness, int iterations) {
		// create a method which says if a sufficient solution has been found. This Can be either iterations or
		// some default value
		return (iterations > ACOGlobals.ITERATIONS || fitness < ACOGlobals.FITNESS);
	}


	public void printValues() {
		// TODO Auto-generated method stub
		for (int i = 0; i < this.pathNetwork.size(); i++) {
			LinkedList<LinkedList<Double>> machine = this.pathNetwork.get(i);
			for (int j = 0; j < machine.size(); j++) {
				LinkedList<Double> stage = machine.get(j);
				String str = "";
				for (int k = 0; k < stage.size(); k++) {
					double val = stage.get(k);
					str += val + " ";
					
				}
				System.out.println(str);
				
			}
			System.out.println();
		}
	}
	
	
	
}
