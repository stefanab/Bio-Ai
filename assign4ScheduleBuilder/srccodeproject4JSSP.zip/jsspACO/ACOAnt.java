package jsspACO;

import java.util.LinkedList;

import jssp.Solution;

public class ACOAnt {

	

	private Solution pBest;
	private int currentFitness;
	private LinkedList<LinkedList<Integer>> position;
	private LinkedList<LinkedList<Double>> tabuList;
	
	
	public ACOAnt(Solution currentSolution, LinkedList<LinkedList<Double>> tabuList) {
		this.pBest = currentSolution;
		this.currentFitness = currentSolution.getFitness();
		this.position = copyPosition(currentSolution.getPosition());
		this.tabuList = tabuList;
		
	}
	
	public ACOAnt(Solution currentSolution) {
		this.pBest = currentSolution;
		this.currentFitness = currentSolution.getFitness();
		this.position = copyPosition(currentSolution.getPosition());
		
	}
	
	public Solution getpBest() {
		return pBest;
	}

	public void setpBest(Solution pBest) {
		this.pBest = pBest;
	}

	public LinkedList<LinkedList<Double>> getTabuList() {
		return tabuList;
	}


	public void setPosition(LinkedList<LinkedList<Integer>> position) {
		this.position = position;
	}


	public LinkedList<LinkedList<Integer>> copyPosition(LinkedList<LinkedList<Integer>> positions) {
		// TODO Auto-generated method stub
		LinkedList<LinkedList<Integer>> cloned = new LinkedList<>();
		for (int i = 0; i < positions.size(); i++) {
			LinkedList<Integer> nextMachine = new LinkedList<>();
			for (Integer preference : positions.get(i)) {
				nextMachine.add(preference);
			}
			cloned.add(nextMachine);
		}
		return cloned;
	}
	
	public LinkedList<LinkedList<Integer>> copyPosition() {
		// TODO Auto-generated method stub
		LinkedList<LinkedList<Integer>> cloned = new LinkedList<>();
		for (int i = 0; i < this.position.size(); i++) {
			LinkedList<Integer> nextMachine = new LinkedList<>();
			for (Integer preference : this.position.get(i)) {
				nextMachine.add(preference);
			}
			cloned.add(nextMachine);
		}
		return cloned;
	}

	
}
