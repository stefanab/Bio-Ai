package jsspACO;

import java.io.IOException;
import java.util.LinkedList;

import org.jfree.ui.RefineryUtilities;

import jssp.FileLoader;
import jssp.GanttSolution;
import jssp.JobInfo;
import jssp.Operation;
import jssp.stackedBarGantt;

public class ACOMain {

	
	public class ACOGlobals {
		
		public static final String ROOT = "C:\\Users\\Stefan\\Desktop\\NTNU\\IT3708BioAI\\assign4ScheduleBuilder\\TestData\\";
		public static final String EXAMPLE = "3.txt";
		public static final int NUMBER_OF_ANTS = 150;
		public static final int NEIGHBORHOOD_SIZE = 14;
		public static final int ABANDONING_THRESHOLD = 7;
		public static final double INERTIA_WEIGHT = 0.7;			//weight to cinsoder how long a job should be tabu. Lower weight gives longer tabu
		public static final double INGORE_TABU = 0.01;
		public static final double INITIAL_PHEROMONE_VALUE = 0.70;
		public static final double PHEROMONE_DECAY = 0.3; //lower value for slower learning
		public static final double DECAY_VALUE = 0.9;	//higher value for longer learning
		public static final int ITERATIONS = 1000;
		
		public static final int FITNESS = 56;
		}
		
	
public ACOMain() {
		
	}
	
	public static void main(String[] args) {
		FileLoader fl = new FileLoader();
		JobInfo jobs = null;
		try {
			System.out.println("loading file...");
			jobs = fl.loadAllJobsFromFile(ACOGlobals.ROOT + ACOGlobals.EXAMPLE, "  ");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Something wrong with loading of file");
			e.printStackTrace();
		}
		
		
		ACO aco = new ACO(jobs.getJobs(), jobs.getOperationDurations());
		GanttSolution solution = aco.ACOMainLoop(); 
		GifflerThompson gt = new GifflerThompson(jobs.getJobs().size(), jobs.getOperationDurations().get(0).size(), 
				jobs.getJobs(), jobs.getOperationDurations());
		LinkedList<LinkedList<Operation>> schedule = gt.gifflerThompson(solution.bestSolution.getPosition());
		solution.printSchedule(schedule);
		System.out.println("Best found solution length: " + gt.calculateFitness(schedule));
		
		solution.printPosition();
//		aco.printValues();
		final stackedBarGantt demo = new stackedBarGantt("Gantt Chart", schedule, solution.bestSolution.getFitness());
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);
	}
	
	
	
	
}
