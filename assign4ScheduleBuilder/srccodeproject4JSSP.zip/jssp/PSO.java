package jssp;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

import jssp.PSOMain.PSOGlobals;

public class PSO {

	
	private int numberOfOperations;
	private int numberOfJobs;
	private ArrayList<ArrayList<Integer>> jobs;
	private ArrayList<ArrayList<Integer>> operationDurations;
	private LinkedList<Particle> population;
	private int populationSize;
	private Solution gBest;
	
	
//	for (ArrayList<Integer> arrayList : operationDurations) {
//		String str = "";
//		for (Integer operation : arrayList) {
//			str += operation + " ";
//		}
//		System.out.println(str);
//	System.out.println();
//	}
	
	public PSO(ArrayList<ArrayList<Integer>> jobs, ArrayList<ArrayList<Integer>> operationDurations, int populationSize) {
		this.jobs = jobs;
		this.operationDurations = operationDurations;
		this.numberOfOperations = jobs.get(0).size();
		
		this.numberOfJobs = jobs.size();
		this.populationSize = populationSize;
		
	}
	
	
	public GanttSolution PSOmainLoop() {
		
		//init population
		System.out.println("initializing population...");
		this.population = initializePopulation(this.populationSize);
		
		
		// start searching space
		int iterations = 0;
		Particle bestParticle = getBestParticle();
		this.gBest = bestParticle.getpBest();
		System.out.println("start optimizing...");
		while(!termination(this.gBest.getFitness(), iterations)){
			System.out.println("iteration " + iterations);
			printSolutionsFitness();
			System.out.println("best solution so far: " + this.gBest.getFitness());
			for (Particle particle : this.population) {
				updateVelocity(particle);
				updatePosition(particle);
			}
			
			for (Particle particle : this.population) {
				LinkedList<LinkedList<Operation>> schedule = gifflerThompson(particle.getPosition());
				int fitness = calculateFitness(schedule);
				particle.setCurrentFitness(fitness);
				if(fitness < particle.getpBest().getFitness()) {
					particle.setpBest(new Solution(particle.getPosition(), fitness));
					LinkedList<LinkedList<Integer>> copiedPos = particle.copyPosition(particle.getPosition());
					particle.setPosition(copiedPos);
				}
//				else if(particle.getpBest().getFitness() == this.gBest.getFitness()) {
//					particle.setPosition(particle.copyPosition(particle.getpBest().getPosition()));
//					particle.setCurrentFitness(particle.getpBest().getFitness());
//				}
			}
			bestParticle = getBestParticle();
			if(bestParticle.getpBest().getFitness() <= this.gBest.getFitness()){
				this.gBest = bestParticle.getpBest();
			}
			iterations++;
		}
		
		return new GanttSolution(this.gBest);
	}
	
	
	private void printSolutionsFitness() {
		// TODO Auto-generated method stub
		int totfit = 0;
		for (Particle particle : this.population) {
			totfit += particle.getCurrentFitness();
//			System.out.println(particle.getCurrentFitness());
//			System.out.println(particle.getpBest().getFitness());
//			System.out.println();
		}
		System.out.println("avg fit: " + totfit/this.populationSize);
	}


	private void updatePosition(Particle particle) {
		// TODO Auto-generated method stub
		//method which updates the particle positions based on swap operator and pbest and gbest
		Random rdm = new Random();
		for (int i = 0; i < this.numberOfOperations; i++) {
			LinkedList<Boolean> velocityMachine = particle.getVelocity().get(i);
			LinkedList<Integer> positionMachine = particle.getPosition().get(i);
			int loc = rdm.nextInt(this.numberOfJobs);
			for (int j = 0; j < this.numberOfJobs; j++) {
				double chance = rdm.nextDouble();
				if(chance <= PSOGlobals.C1) {
					int job = positionMachine.get(loc);
					int locStar = 0;
					for (int k = 0; k < this.numberOfJobs; k++) {
						locStar = particle.getpBest().getPosition().get(i).get(k);
						if(locStar == job) {
							locStar = k;
							break;
						}
					}
					int job2 = positionMachine.get(locStar);
//					System.out.println(job2);
//					System.out.println(job);
//					System.out.println(job2 != job);
					if(!velocityMachine.get(loc) && !velocityMachine.get(locStar) && job2 != job) {
						positionMachine.set(loc, job2);
						positionMachine.set(locStar, job);
						velocityMachine.set(job, true);
//						System.out.println("CHHHHHHHHHHANGED");
					}
				}
				else if(chance <= PSOGlobals.C1+PSOGlobals.C2) {
					int job = positionMachine.get(loc);
					int locStar = 0;
					for (int k = 0; k < this.numberOfJobs; k++) {
						locStar = this.gBest.getPosition().get(i).get(k);
						if(locStar == job) {
							locStar = k;
							break;
						}
					}
					int job2 = positionMachine.get(locStar);
					if(!velocityMachine.get(job) && !velocityMachine.get(job2) && job2 != job) {
						positionMachine.set(loc, job2);
						positionMachine.set(locStar, job);
						velocityMachine.set(job, true);
					}
				}
				loc++;
				if(loc >= this.numberOfJobs) {
					loc = 0; 
				}
			}
			
		}
		int machine = rdm.nextInt(numberOfOperations);
		int loc = rdm.nextInt(numberOfJobs);
		int loc2 = rdm.nextInt(numberOfJobs);
		
		while(loc == loc2) {
			loc2 = rdm.nextInt(numberOfJobs);
		}
		int job = particle.getPosition().get(machine).get(loc);
		int job2 = particle.getPosition().get(machine).get(loc2);
		particle.getPosition().get(machine).set(loc, job2);
		particle.getPosition().get(machine).set(loc2, job);
		particle.getVelocity().get(machine).set(job, false);
		particle.getVelocity().get(machine).set(job2, false);
		
	}


	private void updateVelocity(Particle particle) {
		// TODO Auto-generated method stub
		// method which updates the velocity based on tabu search and inertia weight
		LinkedList<LinkedList<Boolean>> velocity = particle.getVelocity();
		Random rdm = new Random();
		for (LinkedList<Boolean> machine : velocity) {
			
			for (Boolean tabu : machine) {
				if(tabu) {
					
					double chance = rdm.nextDouble();
					if (chance > PSOGlobals.INERTIA_WEIGHT) {
						tabu = false;
					}
				}
			}
		}
		
	}


	private Particle getBestParticle() {
		// TODO Auto-generated method stub
		// iterates over the population and returns the particle with the best fitness value
		Particle bestParticle = null;
		int bestFitness = Integer.MAX_VALUE;
		for (Particle particle : this.population) {
			if(particle.getpBest().getFitness() < bestFitness) {
				bestParticle = particle;
				bestFitness = particle.getpBest().getFitness();
			}
		}
		return bestParticle;
	}


	private boolean termination(int fitness, int iterations) {
		// TODO Auto-generated method stub
		// create a method which says if a sufficient solution has been found. This Can be either iterations or
		// some default value
		return (iterations > PSOGlobals.ITERATIONS || fitness < PSOGlobals.FITNESS);
	}


	public LinkedList<Particle> initializePopulation(int populationSize) {
		LinkedList<Particle> population = new LinkedList<Particle>();
		
		for (int i = 0; i < populationSize; i++) {
			System.out.println("creating individual " + i);
			Particle particle = generateRandomParticle();
			
			population.add(particle);
		}
		
		return population;
	}


	public int calculateFitness(LinkedList<LinkedList<Operation>> schedule) {
		int longestRunningMachineTime = 0;
		for (LinkedList<Operation> machine : schedule) {
			int totalTime = 0;
			int prevFinish = 0;
			
			for (Operation operation : machine) {
				totalTime += operation.getStartTime() - prevFinish + operation.getDuration();
				prevFinish = operation.getStartTime() + operation.getDuration();
			}
			if(totalTime > longestRunningMachineTime) {
				longestRunningMachineTime = totalTime;
			}
		}
		return longestRunningMachineTime;
	}


	/**
	 * @param particle  The particle to calculate the Giffler Thompson algorithm on. The algorithm has to
	 * 					update the fitness value of the particle and should maybe also return the full schedule created.
	 */
	public LinkedList<LinkedList<Operation>> gifflerThompson(LinkedList<LinkedList<Integer>> particlePosition) {
		// index of next operation in job k
		LinkedList<Integer> earliestTimeMachineIIsAvailable = new LinkedList<>();
		LinkedList<Integer> nextOperationIndexOnJobK = new LinkedList<>();
		// the schedule of the particle given as a numberOfmachines*numberofOperations matrix
		LinkedList<LinkedList<Operation>> schedule = new LinkedList<>();
		// the preference list for this particle
		LinkedList<LinkedList<Integer>> preferenceList = particlePosition;
		// finish time of previous operation = earliest starttime for next operation
		LinkedList<Integer> earliestStartTimeOfNextOperation = new LinkedList<>();
		for (int i = 0; i < this.numberOfOperations; i++) {
			earliestTimeMachineIIsAvailable.add(0);
			schedule.add(new LinkedList<Operation>());
			
		}
		for (int i = 0; i < this.numberOfJobs; i++) {
			nextOperationIndexOnJobK.add(0);
			earliestStartTimeOfNextOperation.add(0);
		}
		
		//end initialization
		
		while(!allScheduled(nextOperationIndexOnJobK)) {
			LinkedList<Integer> earliestFinishTimes = new LinkedList<>();
			int earliestIndex = 0;
			int earliestTime = Integer.MAX_VALUE;
			// find the machine with earliest finish time
			for (int i = 0; i < nextOperationIndexOnJobK.size(); i++) {
				int nextOpIndexOnK = nextOperationIndexOnJobK.get(i);
				if(nextOpIndexOnK < this.numberOfOperations) {
					int nextTime = earliestStartTimeOfNextOperation.get(i) + this.operationDurations.get(i)
					.get(nextOpIndexOnK);
					if(nextTime < earliestTime) {
						earliestTime = nextTime;
						earliestIndex = i;
					}
					earliestFinishTimes.add(nextTime);
				} 
				else {
					earliestFinishTimes.add(Integer.MAX_VALUE);
				}
			}
			//////!!!!! update starting times if the next operation for a job is on the same machine as the operation selected this iteration
			
			//find all indices for operations with earlier start time on the machine with earliest finish time
			int machineStar = jobs.get(earliestIndex).get(nextOperationIndexOnJobK.get(earliestIndex));
			LinkedList<Integer> indexOfJobsForPotentialOperations = new LinkedList<>();
			LinkedList<Integer> indexOfJobsWithNextOpOnSameMachine = new LinkedList<>();
			for (int i = 0; i < nextOperationIndexOnJobK.size(); i++) {
				int nextOpIndexOnK = nextOperationIndexOnJobK.get(i);
				if(nextOpIndexOnK < this.numberOfOperations && jobs.get(i).get(nextOpIndexOnK) == machineStar) {
					indexOfJobsWithNextOpOnSameMachine.add(i);
					if(earliestStartTimeOfNextOperation.get(i) < earliestTime ) {
						indexOfJobsForPotentialOperations.add(i);
					}
				}
			}
			for (Integer integer : indexOfJobsForPotentialOperations) {
			}
			// check for priority on the possible operations
			LinkedList<Integer> machinePreferences = preferenceList.get(machineStar);
			int prefered = -1;
			for (Integer preference : machinePreferences) {
				if(indexOfJobsForPotentialOperations.contains(preference)) {
					prefered = preference;
					break;
				}
			}
			
			//add chosen operation to schedule 
			Operation op = new Operation(earliestStartTimeOfNextOperation.get(prefered),
					operationDurations.get(prefered).get(nextOperationIndexOnJobK.get(prefered)), prefered);
			schedule.get(jobs.get(prefered).get(nextOperationIndexOnJobK.get(prefered))).
			add(op);
			
			// update starting time for the next job and for all other jobs which have dependencies on the same machine
			int time = earliestStartTimeOfNextOperation.get(prefered);
			time += operationDurations.get(prefered).get(nextOperationIndexOnJobK.get(prefered));
			earliestTimeMachineIIsAvailable.set(machineStar, time);
			for (Integer job : indexOfJobsWithNextOpOnSameMachine) {
				int startTime = earliestStartTimeOfNextOperation.get(job);
				earliestStartTimeOfNextOperation.set(job, Math.max(time, startTime));
			}
			
			// add next operation to operation set (increment index)
			int prevOpIndex = nextOperationIndexOnJobK.get(prefered) + 1;
			nextOperationIndexOnJobK.set(prefered, prevOpIndex);
			//update earliest start time of new operation (check if the new starttime isnt even higher
			if(prevOpIndex < this.numberOfOperations) {
			earliestStartTimeOfNextOperation.set(prefered, Math.max(earliestStartTimeOfNextOperation.get(prefered), 
					earliestTimeMachineIIsAvailable.get(this.jobs.get(prefered).get(nextOperationIndexOnJobK.get(prefered)))));
			}
		}
	
		return schedule;
	}


	private boolean allScheduled(LinkedList<Integer> nextOperationOnJobK) {
		for (Integer operation : nextOperationOnJobK) {
			if(operation < this.numberOfOperations) {
				return false;
			}
		}
		return true;
	}


	private Particle generateRandomParticle() {
		// generates a new particle with a random priority list and random velocity
		LinkedList<LinkedList<Boolean>> velocities = createRandomVelocities();
		LinkedList<LinkedList<Integer>> positions = createRandomPositions();
		for (LinkedList<Integer> linkedList : positions) {
			String str = "";
			for (Integer integer : linkedList) {
				str += " " + integer;
			}
			System.out.println(str);
		}
		System.out.println();
		LinkedList<LinkedList<Operation>> schedule = gifflerThompson(positions);
		int fitness = calculateFitness(schedule);
		Solution particleSolution = new Solution(positions,fitness);
		return new Particle(particleSolution, velocities);
	}


	private LinkedList<LinkedList<Integer>> createRandomPositions() {
		Random rdm = new Random();
		LinkedList<LinkedList<Integer>> positions = new LinkedList<>();
		for (int i = 0; i < this.numberOfOperations; i++) {
			LinkedList<Integer> nextJobPositions = new LinkedList<>();
			LinkedList<Integer> unused = new LinkedList<>();
			for (int j = 0; j < this.numberOfJobs; j++) {
				unused.add(j);
			}
			for (int j = 0; j < this.numberOfJobs; j++) {
				nextJobPositions.add(unused.remove(rdm.nextInt(unused.size())));
			}
			positions.add(nextJobPositions);
		}
		return positions;
	}


	private LinkedList<LinkedList<Boolean>> createRandomVelocities() {
		Random rdm = new Random();
		LinkedList<LinkedList<Boolean>> velocities = new LinkedList<>();
		for (int i = 0; i < this.numberOfOperations; i++) {
			LinkedList<Boolean> nextJobVolocities = new LinkedList<>();
			for (int j = 0; j < this.numberOfJobs; j++) {
				nextJobVolocities.add(false);
			}
			velocities.add(nextJobVolocities);
		}
		return velocities;
	}
	
	
	
}
