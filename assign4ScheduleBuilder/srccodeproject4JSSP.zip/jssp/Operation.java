package jssp;

public class Operation {

	private int startTime;
	private int duration;
	private int job;
	
	public Operation(int startTime, int duration, int job) {
		this.startTime = startTime;
		this.duration = duration;
		this.job = job;
	}

	public int getStartTime() {
		return startTime;
	}

	public int getDuration() {
		return duration;
	}

	public int getJob() {
		return job;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "J: " + job + " | St: " + startTime + " | D: " + duration;
	}
	
}
