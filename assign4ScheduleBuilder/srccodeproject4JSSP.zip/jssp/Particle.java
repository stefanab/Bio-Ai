package jssp;

import java.util.ArrayList;
import java.util.LinkedList;

public class Particle {

	
	private Solution pBest;
	private int currentFitness;
	private LinkedList<LinkedList<Integer>> position;
	private LinkedList<LinkedList<Boolean>> velocity;
	
	
	public Particle(Solution currentSolution, LinkedList<LinkedList<Boolean>> velocity) {
		this.pBest = currentSolution;
		this.currentFitness = currentSolution.getFitness();
		this.position = copyPosition(currentSolution.getPosition());
		this.velocity = velocity;
		
	}


	public void setPosition(LinkedList<LinkedList<Integer>> position) {
		this.position = position;
	}


	public LinkedList<LinkedList<Integer>> copyPosition(LinkedList<LinkedList<Integer>> positions) {
		// TODO Auto-generated method stub
		LinkedList<LinkedList<Integer>> cloned = new LinkedList<>();
		for (int i = 0; i < positions.size(); i++) {
			LinkedList<Integer> nextMachine = new LinkedList<>();
			for (Integer preference : positions.get(i)) {
				nextMachine.add(preference);
			}
			cloned.add(nextMachine);
		}
		return cloned;
	}





	public void setCurrentFitness(int currentFitness) {
		this.currentFitness = currentFitness;
	}





	public int getCurrentFitness() {
		return currentFitness;
	}





	public LinkedList<LinkedList<Integer>> getPosition() {
		return position;
	}





	public LinkedList<LinkedList<Boolean>> getVelocity() {
		return velocity;
	}





	public Solution getpBest() {
		return pBest;
	}


	public void setpBest(Solution pBest) {
		this.pBest = pBest;
	}


	public void updateVelocity() {
		// TODO Auto-generated method stub
		//method which updates the velocity based on a tabu search approach 
	}


	public void updatePosition() {
		// TODO Auto-generated method stub
		//implement the particle movement based on swap operator
	}


	public float getFitness() {
		// TODO Auto-generated method stub
		// implement a method which returns the fitness (length of schedule) by decoding the position with help
		//from the Giffler Thompson algorithm
		return 0;
	}





	public void saveCurrentPositionAsBest(int fitness) {
		// TODO Auto-generated method stub
		this.pBest = new Solution(position, fitness);
	}
	
	
	
	
	
}
