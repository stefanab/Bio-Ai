package jssp;

import java.util.LinkedList;

public class Solution {

	
	private LinkedList<LinkedList<Integer>> position;
	private int fitness;
	
	public Solution(LinkedList<LinkedList<Integer>> position, int fitness) {
		this.fitness = fitness;
		this.position = position;
	}

	public LinkedList<LinkedList<Integer>> getPosition() {
		return position;
	}

	public int getFitness() {
		return fitness;
	}
	
	public void setFitness(int fitness) {
		this.fitness = fitness;
	}
	
}
