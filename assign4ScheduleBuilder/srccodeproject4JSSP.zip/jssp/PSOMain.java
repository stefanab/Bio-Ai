package jssp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

import org.jfree.ui.RefineryUtilities;

public class PSOMain {

	public class PSOGlobals {
		
	public static final String ROOT = "C:\\Users\\Stefan\\Desktop\\NTNU\\IT3708BioAI\\assign4ScheduleBuilder\\TestData\\";
	public static final String EXAMPLE = "3.txt";
	public static final int POPULATION_SIZE = 200;
	public static final double INERTIA_WEIGHT = 0.9;			//weight to cinsoder how long a job should be tabu. HIgher weight gives longer tabu
	public static final double C1 = 0.7;
	public static final double C2 = 0.7;
	public static final int ITERATIONS = 1000;
	public static final int FITNESS = 1190;
	}
	
	public PSOMain() {
		
	}
	
	public static void main(String[] args) {
		FileLoader fl = new FileLoader();
		JobInfo jobs = null;
		try {
			System.out.println("loading file...");
			jobs = fl.loadAllJobsFromFile(PSOGlobals.ROOT + PSOGlobals.EXAMPLE, "  ");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Something wrong with loading of file");
			e.printStackTrace();
		}
		
		
		PSO pso = new PSO(jobs.getJobs(), jobs.getOperationDurations(), PSOGlobals.POPULATION_SIZE);
		GanttSolution solution = pso.PSOmainLoop(); 
		LinkedList<LinkedList<Operation>> schedule = pso.gifflerThompson(solution.bestSolution.getPosition());
		solution.printSchedule(schedule);
		System.out.println("Best found solution length: " + pso.calculateFitness(schedule));
		solution.printConstraints(jobs.getJobs());
		solution.printPosition();
		final stackedBarGantt demo = new stackedBarGantt("Gantt Chart", schedule, solution.bestSolution.getFitness());
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);
	}
	
}
