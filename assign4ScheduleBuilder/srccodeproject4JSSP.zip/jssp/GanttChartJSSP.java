package jssp;

import java.awt.Color;
import java.awt.Paint;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.IntervalCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DefaultDrawingSupplier;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.GanttRenderer;
import org.jfree.chart.urls.StandardCategoryURLGenerator;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.TaskSeries;
import org.jfree.data.gantt.Task;
import org.jfree.data.gantt.TaskSeriesCollection;
import org.jfree.data.time.SimpleTimePeriod;
import org.jfree.ui.ApplicationFrame;

public class GanttChartJSSP extends ApplicationFrame {
	
	LinkedList<LinkedList<Operation>> schedule;
	int fitness;
	
	  public class MyGanttRenderer extends GanttRenderer {

	        public MyGanttRenderer() {
	            super();
	        }

	        public Paint getItemPaint(int row, int column) {
	        	if( column == 0) {
	        		return Color.black;
	        	}
	            return DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE[column];
	        }
	    }
	
	public GanttChartJSSP(final String title, LinkedList<LinkedList<Operation>> schedule, int fitness) {
		 super(title);

	        final IntervalCategoryDataset dataset = createDataset(schedule);

	        // create the chart...
	        final JFreeChart chart = ChartFactory.createGanttChart(
	            "JSSP Gantt Chart with fitness " + fitness,  // chart title
	            "Machine",              // domain axis label
	            "Date",              // range axis label
	            dataset,             // data
	            true,                // include legend
	            true,                // tooltips
	            true                // urls
	        );
	        final CategoryPlot plot = (CategoryPlot) chart.getPlot();
	  //      plot.getDomainAxis().setMaxCategoryLabelWidthRatio(10.0f);
	        plot.setRenderer(new MyGanttRenderer());
	        

	        // add the chart to a panel...
	        final ChartPanel chartPanel = new ChartPanel(chart);
	        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
	        setContentPane(chartPanel);

    }
	
//	private JFreeChart createChart(String title, 
//            String categoryAxisLabel,
//            String dateAxisLabel, 
//            IntervalCategoryDataset dataset, 
//            boolean legend,            
//            boolean tooltips,     
//            boolean urls) {
//		   CategoryAxis categoryAxis = new CategoryAxis(categoryAxisLabel);
//	        ValueAxis dateAxis = new NumberAxis(dateAxisLabel);//important,change axis from data to value
//
//	        CategoryItemRenderer renderer = new GanttRenderer();
//	        if (tooltips) {
//	            renderer.setBaseToolTipGenerator(
//	                    (CategoryToolTipGenerator) new IntervalCategoryToolTipGenerator(
//	                            "{1}Schedule Time: {3}ms - {4}ms", NumberFormat .getNumberInstance()));
//	            }
//	        if (urls) {
//	                    renderer.setBaseItemURLGenerator(
//	                    new StandardCategoryURLGenerator());
//	            }
//	        CategoryPlot plot = new CategoryPlot(dataset, categoryAxis, dateAxis, 
//	                    renderer);
//	        plot.setOrientation(PlotOrientation.HORIZONTAL);
//	        JFreeChart chart = new JFreeChart(title, JFreeChart.DEFAULT_TITLE_FONT,
//	        plot, legend);
//
//	        return chart;
//          
//    }
	
	private static Date dateStart(Operation operation) {
        final Calendar calendar = Calendar.getInstance();
        calendar.set(2017, Calendar.MAY, 1);
        System.out.println(calendar.getTime());
        
        calendar.add(Calendar.DATE, operation.getStartTime());
        System.out.println(calendar.getTime());
        final Date result = calendar.getTime();
        return result;

    }
	
	private static Date dateEnd(Operation operation) {
        final Calendar calendar = Calendar.getInstance();
        calendar.set(2017, Calendar.MAY, 1);
        calendar.add(Calendar.DATE, operation.getStartTime() + operation.getDuration());
        final Date result = calendar.getTime();
        return result;

    }
	
	 public static IntervalCategoryDataset createDataset(LinkedList<LinkedList<Operation>> schedule) {

	        final TaskSeries s1 = new TaskSeries("Scheduled");
	        for (int i = 0; i < schedule.size(); i++) {
				LinkedList<Operation> machine = schedule.get(i);
				Task nextMachine = new Task("Machine " + i,dateStart(machine.getFirst()), dateEnd(machine.getLast()));
				for (int j = 0; j < machine.size(); j++) {
					Operation op = machine.get(j);
					Task t = new Task("job " + op.getJob(), dateStart(op), dateEnd(op));
					nextMachine.addSubtask(t);
					
				}
				System.out.println(nextMachine.getSubtaskCount());
				s1.add(nextMachine);
	        }

	        final TaskSeriesCollection collection = new TaskSeriesCollection();
	        collection.add(s1);

	        return collection;
	    }

}
