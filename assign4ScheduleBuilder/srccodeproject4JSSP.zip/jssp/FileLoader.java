package jssp;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class FileLoader {

	
	public FileLoader() {
		
	}
	
	
	/**
	 * @param path 		String where the file to read from is located
	 * @return	JobInfo a job object containing the jobs and their operational constraints aswell as a
	 * 			array with the durations of the corresponding operation
	 * @throws IOException
	 */
	public JobInfo loadAllJobsFromFile(String path, String splitCondition) throws IOException {
		ArrayList<ArrayList<Integer>> jobs = new ArrayList<>();
		BufferedReader br = new BufferedReader(new FileReader(path));
		ArrayList<ArrayList<Integer>> operationDurations = new ArrayList<>();
		//throw away first line
		if(br.ready()) {
			br.readLine();
		}
		//read all jobs lines
		while(br.ready()) {
			String[] line = br.readLine().split(splitCondition);
			
		
			ArrayList<Integer> nextJob = new ArrayList<>();
			ArrayList<Integer> nextJobDurations = new ArrayList<>();
			for (int i = 0; i < line.length; i+=2) {
				nextJob.add(Integer.parseInt(line[i].trim()));
				nextJobDurations.add(Integer.parseInt(line[i+1].trim()));
			}
			jobs.add(nextJob);
			operationDurations.add(nextJobDurations);
		}
		
		br.close();
		return new JobInfo(operationDurations, jobs);
	}
	
	
}
