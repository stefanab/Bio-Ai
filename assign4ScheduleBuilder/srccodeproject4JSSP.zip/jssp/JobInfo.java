package jssp;

import java.util.ArrayList;

public class JobInfo {
	
	private ArrayList<ArrayList<Integer>> operationDurations;
	private ArrayList<ArrayList<Integer>> jobs;
	
	public JobInfo(ArrayList<ArrayList<Integer>> operationDurations, ArrayList<ArrayList<Integer>> jobs) {
		this.jobs = jobs;
		this.operationDurations = operationDurations;
	}

	public ArrayList<ArrayList<Integer>> getOperationDurations() {
		return operationDurations;
	}

	public ArrayList<ArrayList<Integer>> getJobs() {
		return jobs;
	}
	
	
	
	
	
	
}
