package jssp;

import java.util.ArrayList;
import java.util.LinkedList;

public class GanttSolution {

	
	public Solution bestSolution;
	
	
	public GanttSolution(Solution bestParticle) {
		this.bestSolution = bestParticle;
	}
	
	public GanttSolution() {
		
	}
	
	public void printSchedule(LinkedList<LinkedList<Operation>> schedule) {
		for (LinkedList<Operation> machine : schedule) {
			String thisMachine = "";
			
			int previousFinishTime = 0;
			for (Operation operation : machine) {
				int idle = operation.getStartTime() - previousFinishTime;
				for (int i = 0; i < idle; i++) {
					thisMachine += "- ";
				}
				int runningTime = operation.getDuration();
				for (int i = 0; i < runningTime; i++) {
					thisMachine += operation.getJob() + " ";
				}
				previousFinishTime += idle + runningTime;
			}
			System.out.println(thisMachine);
		}
		System.out.println();
	}
	
	public void printPosition() {
		for (LinkedList<Integer> linkedList : bestSolution.getPosition()) {
			String str = "";
			for (Integer integer : linkedList) {
				str += " " + integer;
			}
			System.out.println(str);
		}
		System.out.println();
	}
	
	public void printConstraints(ArrayList<ArrayList<Integer>> jobs) {
		for (ArrayList<Integer> linkedList : jobs) {
			String str = "";
			for (Integer integer : linkedList) {
				int num = integer + 1;
				str += " " + num;
			}
			System.out.println(str);
		}
		System.out.println();
	}
	
}
