package jssp;

import java.awt.Color;
import java.awt.Dimension;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.concurrent.TimeUnit;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.SymbolAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYBarPainter;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.data.xy.XYIntervalSeries;
import org.jfree.data.xy.XYIntervalSeriesCollection;
import org.jfree.ui.ApplicationFrame;

public class stackedBarGantt extends ApplicationFrame{

private static final String NODATA_SERIES   = "NODATA";
private static final String STANDBY_SERIES  = "STANDBY";
private static final String HEATING_SERIES  = "HEATING";
private static final String HOLDING_SERIES  = "HOLDING";
private static final String COOLING_SERIES  = "COOLING";
private static final String LOWERING_SERIES = "LOWERING";

ArrayList<Operation> testData = null;
String[] catArray;

JFreeChart chart;
DateAxis dateAxis;

Date chartStartDate;
Date chartEndDate;

LinkedList<LinkedList<Operation>> schedule;
int fitness;

public stackedBarGantt(String title, LinkedList<LinkedList<Operation>> schedule, int fitness) {
    super(title);
    // set up some test data
    this.schedule = schedule;
    this.fitness = fitness;
    initData();
    chartStartDate  = new Date(1477461600000L);
    chartEndDate = new Date(1477497600000L);
    chart = createIntervalStackedChart();
    ChartPanel chartPanel = new ChartPanel(chart);
    chartPanel.setPreferredSize(new Dimension(600, 450));
    setContentPane(chartPanel);
}



private void initData() {
    testData = new ArrayList<>();
    for (int i = 0; i < schedule.size(); i++) {
		LinkedList<Operation> machine = schedule.get(i);
    	for (int j = 0; j < machine.size(); j++) {
			testData.addAll(machine);
		}
	}
    
    ArrayList<String> list = new ArrayList<>();
	for (int i = 0; i < schedule.size(); i++) {
		int num = i +1;
		list.add("Machine "+ num );
	}

    catArray = new String[list.size()];
    catArray = list.toArray(catArray);
}


private JFreeChart createIntervalStackedChart() {
    XYIntervalSeriesCollection dataset = createXYIntervalDataset();
    XYBarRenderer xyRend = new XYBarRenderer();
    xyRend.setShadowVisible(false);
    xyRend.setUseYInterval(true);
    xyRend.setBarPainter(new StandardXYBarPainter());
    xyRend.setSeriesPaint(0, Color.GRAY);
    xyRend.setSeriesPaint(1, Color.BLACK.brighter());
    xyRend.setSeriesPaint(3, Color.RED.brighter());
    xyRend.setSeriesPaint(4, Color.RED.darker());
    xyRend.setSeriesPaint(5, Color.YELLOW.brighter());
    xyRend.setSeriesPaint(6, Color.CYAN);
    xyRend.setSeriesPaint(7, Color.CYAN.darker());
    xyRend.setSeriesPaint(8, Color.ORANGE);
    xyRend.setSeriesPaint(9, Color.ORANGE.darker());
    xyRend.setSeriesPaint(10, Color.MAGENTA.brighter());
    xyRend.setSeriesPaint(11, Color.MAGENTA.darker());
    xyRend.setSeriesPaint(12, Color.YELLOW.darker());
    xyRend.setSeriesPaint(13, Color.PINK);
    xyRend.setSeriesPaint(14, Color.WHITE);
    xyRend.setSeriesPaint(15, Color.LIGHT_GRAY); 
    xyRend.setSeriesPaint(16, Color.DARK_GRAY);
    xyRend.setSeriesPaint(17, Color.BLUE.darker());	
    xyRend.setSeriesPaint(18, Color.BLUE.brighter());
    xyRend.setSeriesPaint(19, Color.GREEN.brighter());
    xyRend.setSeriesPaint(2, Color.GREEN.darker());
//    xyRend.setSeriesPaint(12, Color.ORANGE);
//    xyRend.setSeriesPaint(13, Color.CYAN);
//    xyRend.setSeriesPaint(14, Color.GREEN);
//    xyRend.setSeriesPaint(15, Color.ORANGE);
//    xyRend.setSeriesPaint(16, Color.CYAN);
//    xyRend.setSeriesPaint(17, Color.GREEN);
//    xyRend.setSeriesPaint(18, Color.ORANGE);
//    xyRend.setSeriesPaint(19, Color.CYAN);
//    xyRend.setSeriesPaint(20, Color.GREEN);
//    xyRend.setSeriesPaint(21, Color.ORANGE);


    
    dateAxis = new DateAxis();
    dateAxis.setVerticalTickLabels(true);
    dateAxis.setVisible(false);
    dateAxis.setDateFormatOverride(new SimpleDateFormat("dd.MM.yy"));
    XYPlot plot = new XYPlot(dataset, new SymbolAxis("", catArray), dateAxis, xyRend);
    plot.setOrientation(PlotOrientation.HORIZONTAL);
    plot.setBackgroundPaint(Color.LIGHT_GRAY);
    return new JFreeChart("Machine Schedule with fitness " + this.fitness, plot);
}

private XYIntervalSeriesCollection createXYIntervalDataset() {
    XYIntervalSeriesCollection dataset = new XYIntervalSeriesCollection();

    int statesCount = this.schedule.get(0).size();
    String str = "";
    for (int i = 0; i < statesCount; i++) {
		str += i + " ";
	}
    String[] states = str.split(" ");

    XYIntervalSeries[] series = new XYIntervalSeries[statesCount];
    for (int i = 0; i < statesCount; i++) {
        series[i] = new XYIntervalSeries(states[i]);
        dataset.addSeries(series[i]);
    }

    for (int i = 0; i < schedule.size(); i++) {
        LinkedList<Operation> machine = schedule.get(i);
        for (int j = 0; j < machine.size(); j++) {
			Operation op = machine.get(j);
        	int machNo = i;
        	int state = op.getJob();
        	int eventStart = op.getStartTime();
        	int eventEnd = op.getStartTime() + op.getDuration();

        long duration = TimeUnit.DAYS.convert(eventEnd - eventStart, TimeUnit.DAYS);
        series[state].add(machNo, machNo - 0.2, machNo + 0.2, eventStart, eventStart, eventStart + duration);
        }
    }

    return dataset;
}

}