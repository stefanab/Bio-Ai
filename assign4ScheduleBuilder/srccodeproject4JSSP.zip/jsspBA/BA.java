package jsspBA;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

import jssp.GanttSolution;
import jssp.Operation;
import jssp.Particle;
import jssp.Solution;
import jsspBA.BAMain.BAGlobals;

public class BA {


	private int numberOfOperations;
	private int numberOfJobs;
	private ArrayList<ArrayList<Integer>> jobs;
	private ArrayList<ArrayList<Integer>> operationDurations;
	private LinkedList<BAParticle> population;
	private Solution gBest;
	private LinkedList<FlowerPatch> flowerPatches;
	
	public BA(ArrayList<ArrayList<Integer>> jobs, ArrayList<ArrayList<Integer>> operationDurations) {
		this.jobs = jobs;
		this.operationDurations = operationDurations;
		this.numberOfOperations = jobs.get(0).size();
		this.numberOfJobs = jobs.size();
		
	}
	
	private boolean termination(int fitness, int iterations) {
		// create a method which says if a sufficient solution has been found. This Can be either iterations or
		// some default value
		return (iterations > BAGlobals.ITERATIONS || fitness < BAGlobals.FITNESS);
	}
	
public GanttSolution BAmainLoop() {
		
		//init population
		System.out.println("initializing population...");
		LinkedList<BAParticle> possibleStartingPatches = initializeScouts(BAGlobals.TOTAL_BEES);
		BAParticle bestParticle = possibleStartingPatches.getFirst();
		this.gBest = new Solution(bestParticle.copyPosition(bestParticle.getPosition()), bestParticle.getCurrentFitness());
		// find best sites
		int iterations = 0;
		LinkedList<FlowerPatch> flowerPatches = new LinkedList<>();
		
		for (int i = 0; i < BAGlobals.BEST_SITES; i++) {
			FlowerPatch flowerPatch = initializeFlowerPatch(possibleStartingPatches.get(i), i);
			flowerPatches.addLast(flowerPatch);
			System.out.println("init best in patch : " + flowerPatch.getBestSolutionFitness());
		}
		System.out.println("number of sites: " + flowerPatches.size());
		System.out.println("start optimizing...");
		while(!termination(this.gBest.getFitness(), iterations)){
			LinkedList<FlowerPatch> newSortedPatches = new LinkedList<>(); 
			int numberOfAbandoned = 0;
			System.out.println("iteration " + iterations);
//			printSolutionsFitness();
			System.out.println("best solution so far: " + this.gBest.getFitness());
			for (FlowerPatch flowerPatch : flowerPatches) {
				localSearch2(flowerPatch);
				boolean abandon = siteAbandonment(flowerPatch);
				if(!abandon) {
					int index = newSortedPatches.size()-1;
					if(newSortedPatches.isEmpty()) {
						newSortedPatches.add(flowerPatch);
					} else {
						while(index >= 0 && flowerPatch.getBestSolutionFitness() < newSortedPatches.get(index).getBestSolutionFitness()) {
							index--;
						}
						if(index == newSortedPatches.size()-1) {
							newSortedPatches.addLast(flowerPatch);
						}
						else if(index > -1) {
							newSortedPatches.add(index+1, flowerPatch);
						} else {
							newSortedPatches.addFirst(flowerPatch);
						}
						
					}
				} else {
					numberOfAbandoned++;
//					System.out.println("abandoned");
				}
//				neighborhoodShrinking(flowerPatch);
			}
			
			//find number of abandoned patches
			
			//scout for the number of scout bees + number of abandoned patches
			LinkedList<BAParticle> scoutedPatches = initializeScouts(BAGlobals.SCOUT_BEES + numberOfAbandoned);
			//update the patches so that the elite patches are found 
			flowerPatches = updateFlowerPatches(newSortedPatches, scoutedPatches);
			
			//find best solution so far
			
	
			bestParticle = flowerPatches.getFirst().getBestSolution();
			if(bestParticle.getpBest().getFitness() < this.gBest.getFitness()) {
				this.gBest = new Solution(bestParticle.getpBest().getPosition(), bestParticle.getpBest().getFitness());
				
			}
			flowerPatches.getFirst().setTimesSinceBetterSolutionWasFound(0);
			flowerPatches.getFirst().setNeighborhoodSize(this.numberOfJobs);
			iterations++;
		}
		
		return new GanttSolution(this.gBest);
	}

	private LinkedList<FlowerPatch> updateFlowerPatches(LinkedList<FlowerPatch> newSortedPatches,
		LinkedList<BAParticle> scoutedPatches) {
	// TODO Auto-generated method stub	
//		System.out.println("updating");
//		System.out.println(scoutedPatches.size());
//		System.out.println(newSortedPatches.size());
		LinkedList<FlowerPatch> updatedFlowerPatches = new LinkedList<>();
		int nextIndex = 0;
		while(updatedFlowerPatches.size() < BAGlobals.BEST_SITES) {
			BAParticle scout = scoutedPatches.getFirst();
			
			if(!newSortedPatches.isEmpty()) {
				BAParticle patch = newSortedPatches.getFirst().getBestSolution();
				
				if(patch.getpBest().getFitness() <= scout.getCurrentFitness()) {
					FlowerPatch newPatch = newSortedPatches.removeFirst();
//					newPatch.setTabuList(createRandomVelocities());
					updatedFlowerPatches.add(newPatch);
//					System.out.println("best in patch " + nextIndex + ": " + patch.getpBest().getFitness());
			} else {
				updatedFlowerPatches.add(new FlowerPatch(scout, createRandomVelocities(), nextIndex < BAGlobals.ELITE_SITES));
				scoutedPatches.removeFirst();
//				System.out.println("best in scout " + nextIndex + ": " + scout.getCurrentFitness());
			}
			} else {
				updatedFlowerPatches.add(new FlowerPatch(scout, createRandomVelocities(), nextIndex < BAGlobals.ELITE_SITES));
				scoutedPatches.removeFirst();
//				System.out.println("best in scout " + nextIndex + ": " + scout.getCurrentFitness());
			}
			nextIndex++;
		}
	return updatedFlowerPatches;
}

	private boolean siteAbandonment(FlowerPatch flowerPatch) {
	// TODO Auto-generated method stub
		if(flowerPatch.getTimesSinceBetterSolutionWasFound() > BAGlobals.ABANDONING_THRESHOLD) {
			return true;
		}
		return false;
	}

	private void localSearch(FlowerPatch flowerPatch) {
		// TODO Auto-generated method stub
		//method which updates the particle positions based on swap operator and pbest and gbest
			Random rdm = new Random();
			Boolean betterFound = false;
			BAParticle bestBeeSoFar = flowerPatch.getBestSolution();
			int numberOfBees = BAGlobals.FORAGER_BEES_FOR_NON_ELITE;
			if(flowerPatch.getElite()) {
				numberOfBees = BAGlobals.FORAGER_BEES_FOR_ELITE_SITES;
			}
			for (int beeNr = 0; beeNr < numberOfBees; beeNr++) {
				BAParticle bee = recruitBeeToFlowerPatch(flowerPatch);
				for (int i = 0; i < this.numberOfOperations; i++) {
//					int i = rdm.nextInt(this.numberOfOperations);
					LinkedList<Double> velocityMachine = flowerPatch.getTabuList().get(i);
					LinkedList<Double> velocityMachineBee = bee.getTabuList().get(i);
					LinkedList<Integer> positionMachine = bee.getPosition().get(i);
					int loc = rdm.nextInt(this.numberOfJobs);
					int loc2 = rdm.nextInt(numberOfJobs);
					while(loc == loc2) {
						loc2 = rdm.nextInt(numberOfJobs);
					}
					double chance = rdm.nextDouble();
					if(velocityMachine.get(loc) < BAGlobals.INERTIA_WEIGHT && velocityMachine.get(loc2) < BAGlobals.INERTIA_WEIGHT && !(chance < BAGlobals.INGORE_TABU)) {
						
						int job = positionMachine.get(loc);
						int job2 = positionMachine.get(loc2);
						positionMachine.set(loc, job2);
						positionMachine.set(loc2, job);
						velocityMachine.set(job, 1.0);
						velocityMachine.set(job2, 1.0);
						velocityMachineBee.set(job, 1.0);
						velocityMachineBee.set(job2, 1.0);
	//					System.out.println("CHACHAHCHACHAHCHANGED");
					}
				}
				for (int n = 0; n < flowerPatch.getNeighborhoodSize(); n++) {
					int k = rdm.nextInt(this.numberOfOperations);
					LinkedList<Double>  velocityMachine = bee.getTabuList().get(k);
					LinkedList<Integer> positionMachine = bee.getPosition().get(k);
						int loc = rdm.nextInt(this.numberOfJobs);
						int loc2 = rdm.nextInt(numberOfJobs);
						while(loc == loc2) {
							loc2 = rdm.nextInt(numberOfJobs);
						}
						double chance = rdm.nextDouble();
						if(velocityMachine.get(loc) < BAGlobals.BEE_INERTIA_WEIGHT && velocityMachine.get(loc2) < BAGlobals.BEE_INERTIA_WEIGHT && !(chance < BAGlobals.INGORE_TABU)) {
							
							int job = positionMachine.get(loc);
							int job2 = positionMachine.get(loc2);
							positionMachine.set(loc, job2);
							positionMachine.set(loc2, job);
							velocityMachine.set(job, 1.0);
							velocityMachine.set(job2, 1.0);
//							System.out.println("nooo");
		//					System.out.println("CHACHAHCHACHAHCHANGED");
						} else {
//							System.out.println("tabuuu");
						}
					LinkedList<LinkedList<Operation>> schedule = gifflerThompson(bee.getPosition());
					int fitness = calculateFitness(schedule);
					if(fitness < bestBeeSoFar.getpBest().getFitness()) {
						bestBeeSoFar = bee;
						bee.setpBest(new Solution(bee.copyPosition(), fitness));
						betterFound = true;
					} 
					updateVelocity(bee.getTabuList(), BAGlobals.BEE_INERTIA_WEIGHT);
				}
				updateVelocity(flowerPatch.getTabuList(), BAGlobals.INERTIA_WEIGHT);
			}
			int time = flowerPatch.getTimesSinceBetterSolutionWasFound() + 1;
			int nSize = flowerPatch.getNeighborhoodSize() -1;
			flowerPatch.setNeighborhoodSize(nSize);
			flowerPatch.setTimesSinceBetterSolutionWasFound(time);
			if(betterFound) {
				flowerPatch.setTimesSinceBetterSolutionWasFound(0);
				flowerPatch.setNeighborhoodSize(BAGlobals.NEIGHBORHOOD_SIZE);
			}

			flowerPatch.setBestSolution(bestBeeSoFar);
	}
	
	private void localSearch2(FlowerPatch flowerPatch) {
		// TODO Auto-generated method stub
		//method which updates the particle positions based on swap operator and pbest and gbest
			Random rdm = new Random();
			BAParticle bestBeeSoFar = flowerPatch.getBestSolution();
			int numberOfBees = 3;
			if(flowerPatch.getElite()) {
				numberOfBees = 1;
			}
			boolean betterFoundTotal = false;
			int OrgN = flowerPatch.getNeighborhoodSize()-1;
			for (int i = 0; i < this.numberOfOperations; i++) {
				Boolean betterFound = false;
				BAParticle bee = recruitBeeToFlowerPatch(flowerPatch);
//					
					LinkedList<Integer> positionMachine = bee.getPosition().get(i);
					int numbOfInsets = 1;
//					for (int j = 0; j < numberOfBees; j++) {
						
						for (int beeNr = 0; beeNr < (int)this.numberOfJobs/numberOfBees; beeNr++) {
							int loc = rdm.nextInt(this.numberOfJobs-numbOfInsets)+numbOfInsets;
								int job = positionMachine.remove(loc);
								positionMachine.addFirst(job);
			//					System.out.println("CHACHAHCHACHAHCHANGED");
							LinkedList<LinkedList<Operation>> schedule = gifflerThompson(bee.getPosition());
							int fitness = calculateFitness(schedule);
							if(fitness < bestBeeSoFar.getpBest().getFitness()) {
								bestBeeSoFar = bee;
								bee.setpBest(new Solution(bee.copyPosition(), fitness));
								betterFound = true;
							} 
//						}
					}
						int nSize = flowerPatch.getNeighborhoodSize() -1;
						flowerPatch.setNeighborhoodSize(nSize);
						if(betterFound) {
							flowerPatch.setNeighborhoodSize(this.numberOfJobs);
							flowerPatch.setBestSolution(bestBeeSoFar);
							betterFoundTotal = true;
							i = 0;
						}
				}
			int time = flowerPatch.getTimesSinceBetterSolutionWasFound() + 1;
			flowerPatch.setTimesSinceBetterSolutionWasFound(time);
			flowerPatch.setNeighborhoodSize(OrgN);
			if(betterFoundTotal) {
				flowerPatch.setTimesSinceBetterSolutionWasFound(0);
				flowerPatch.setNeighborhoodSize(this.numberOfJobs);
			}
	}
	
	private void updateVelocity(LinkedList<LinkedList<Double>> velocity, double weight) {
		// TODO Auto-generated method stub
		// method which updates the velocity based on tabu search and inertia weight
		Random rdm = new Random();
		for (LinkedList<Double> machine : velocity) {
			
			for (Double tabu : machine) {
					tabu -= (rdm.nextDouble()/10);
					
			}
		}
		
	}

	private BAParticle recruitBeeToFlowerPatch(FlowerPatch flowerPatch) {
	// TODO Auto-generated method stub
		//legger til nye bier med samme posisjon som den beste bien. DIsse vil senere gjennomg� tabu s�k slik at de sprer
		//seg fra midten av matkilden
				LinkedList<LinkedList<Integer>> position = flowerPatch.getBestSolution().copyPosition();
				BAParticle bee = new BAParticle(new Solution(position, flowerPatch.getBestSolutionFitness()), createRandomVelocities());
				return bee;
	}

	private FlowerPatch initializeFlowerPatch(BAParticle baParticle, int i) {
		LinkedList<LinkedList<Double>> patchTabuList = createRandomVelocities();
		FlowerPatch flowerPatch = new FlowerPatch(baParticle, patchTabuList, i < BAGlobals.ELITE_SITES);
		
	return flowerPatch;
	}

	/**
	 * @param particle  The particle to calculate the Giffler Thompson algorithm on. The algorithm has to
	 * 					update the fitness value of the particle and should maybe also return the full schedule created.
	 */
	public LinkedList<LinkedList<Operation>> gifflerThompson(LinkedList<LinkedList<Integer>> particlePosition) {
		// index of next operation in job k
		LinkedList<Integer> earliestTimeMachineIIsAvailable = new LinkedList<>();
		LinkedList<Integer> nextOperationIndexOnJobK = new LinkedList<>();
		// the schedule of the particle given as a numberOfmachines*numberofOperations matrix
		LinkedList<LinkedList<Operation>> schedule = new LinkedList<>();
		// the preference list for this particle
		LinkedList<LinkedList<Integer>> preferenceList = particlePosition;
		// finish time of previous operation = earliest starttime for next operation
		LinkedList<Integer> earliestStartTimeOfNextOperation = new LinkedList<>();
		for (int i = 0; i < this.numberOfOperations; i++) {
			earliestTimeMachineIIsAvailable.add(0);
			schedule.add(new LinkedList<Operation>());
			
		}
		for (int i = 0; i < this.numberOfJobs; i++) {
			nextOperationIndexOnJobK.add(0);
			earliestStartTimeOfNextOperation.add(0);
		}
		
		//end initialization
		
		while(!allScheduled(nextOperationIndexOnJobK)) {
			LinkedList<Integer> earliestFinishTimes = new LinkedList<>();
			int earliestIndex = 0;
			int earliestTime = Integer.MAX_VALUE;
			// find the machine with earliest finish time
			for (int i = 0; i < nextOperationIndexOnJobK.size(); i++) {
				int nextOpIndexOnK = nextOperationIndexOnJobK.get(i);
				if(nextOpIndexOnK < this.numberOfOperations) {
					int nextTime = earliestStartTimeOfNextOperation.get(i) + this.operationDurations.get(i)
					.get(nextOpIndexOnK);
					if(nextTime < earliestTime) {
						earliestTime = nextTime;
						earliestIndex = i;
					}
					earliestFinishTimes.add(nextTime);
				} 
				else {
					earliestFinishTimes.add(Integer.MAX_VALUE);
				}
			}
			//////!!!!! update starting times if the next operation for a job is on the same machine as the operation selected this iteration
			
			//find all indices for operations with earlier start time on the machine with earliest finish time
			int machineStar = jobs.get(earliestIndex).get(nextOperationIndexOnJobK.get(earliestIndex));
			LinkedList<Integer> indexOfJobsForPotentialOperations = new LinkedList<>();
			LinkedList<Integer> indexOfJobsWithNextOpOnSameMachine = new LinkedList<>();
			for (int i = 0; i < nextOperationIndexOnJobK.size(); i++) {
				int nextOpIndexOnK = nextOperationIndexOnJobK.get(i);
				if(nextOpIndexOnK < this.numberOfOperations && jobs.get(i).get(nextOpIndexOnK) == machineStar) {
					indexOfJobsWithNextOpOnSameMachine.add(i);
					if(earliestStartTimeOfNextOperation.get(i) < earliestTime ) {
						indexOfJobsForPotentialOperations.add(i);
					}
				}
			}
			for (Integer integer : indexOfJobsForPotentialOperations) {
			}
			// check for priority on the possible operations
			LinkedList<Integer> machinePreferences = preferenceList.get(machineStar);
			int prefered = -1;
			for (Integer preference : machinePreferences) {
				if(indexOfJobsForPotentialOperations.contains(preference)) {
					prefered = preference;
					break;
				}
			}
			
			//add chosen operation to schedule 
			Operation op = new Operation(earliestStartTimeOfNextOperation.get(prefered),
					operationDurations.get(prefered).get(nextOperationIndexOnJobK.get(prefered)), prefered);
			schedule.get(jobs.get(prefered).get(nextOperationIndexOnJobK.get(prefered))).
			add(op);
			
			// update starting time for the next job and for all other jobs which have dependencies on the same machine
			int time = earliestStartTimeOfNextOperation.get(prefered);
			time += operationDurations.get(prefered).get(nextOperationIndexOnJobK.get(prefered));
			earliestTimeMachineIIsAvailable.set(machineStar, time);
			for (Integer job : indexOfJobsWithNextOpOnSameMachine) {
				int startTime = earliestStartTimeOfNextOperation.get(job);
				earliestStartTimeOfNextOperation.set(job, Math.max(time, startTime));
			}
			
			// add next operation to operation set (increment index)
			int prevOpIndex = nextOperationIndexOnJobK.get(prefered) + 1;
			nextOperationIndexOnJobK.set(prefered, prevOpIndex);
			//update earliest start time of new operation (check if the new starttime isnt even higher
			if(prevOpIndex < this.numberOfOperations) {
			earliestStartTimeOfNextOperation.set(prefered, Math.max(earliestStartTimeOfNextOperation.get(prefered), 
					earliestTimeMachineIIsAvailable.get(this.jobs.get(prefered).get(nextOperationIndexOnJobK.get(prefered)))));
			}
		}
	
		return schedule;
	}
	
	private boolean allScheduled(LinkedList<Integer> nextOperationOnJobK) {
		for (Integer operation : nextOperationOnJobK) {
			if(operation < this.numberOfOperations) {
				return false;
			}
		}
		return true;
	}

	private BAParticle getBestParticle() {
		// iterates over the population and returns the particle with the best fitness value
		BAParticle bestParticle = null;
		int bestFitness = Integer.MAX_VALUE;
		for (BAParticle particle : this.population) {
			if(particle.getpBest().getFitness() < bestFitness) {
				bestParticle = particle;
				bestFitness = particle.getpBest().getFitness();
			}
		}
		return bestParticle;
	}
	
	public int calculateFitness(LinkedList<LinkedList<Operation>> schedule) {
		int longestRunningMachineTime = 0;
		for (LinkedList<Operation> machine : schedule) {
			int totalTime = 0;
			int prevFinish = 0;
			
			for (Operation operation : machine) {
				totalTime += operation.getStartTime() - prevFinish + operation.getDuration();
				prevFinish = operation.getStartTime() + operation.getDuration();
			}
			if(totalTime > longestRunningMachineTime) {
				longestRunningMachineTime = totalTime;
			}
		}
		return longestRunningMachineTime;
	}
	
	public LinkedList<BAParticle> initializeScouts(int numberOfScouts) {
		LinkedList<BAParticle> population = new LinkedList<>();
		
		for (int i = 0; i < numberOfScouts; i++) {
//			System.out.println("creating individual " + i);
			BAParticle particle = generateRandomParticle();
			int index = 0;
			while(index < population.size() && particle.getCurrentFitness() > population.get(index).getCurrentFitness()) {
				index++;
			}
			//mulig man m� sjekke for end of list condition
			population.add(index, particle);
		}
		
		return population;
	}
	
	private BAParticle generateRandomParticle() {
		// generates a new particle with a random priority list and random velocity
		LinkedList<LinkedList<Integer>> positions = createRandomPositions();
//		for (LinkedList<Integer> linkedList : positions) {
//			String str = "";
//			for (Integer integer : linkedList) {
//				str += " " + integer;
//			}
//			System.out.println(str);
//		}
//		System.out.println();
		LinkedList<LinkedList<Operation>> schedule = gifflerThompson(positions);
		int fitness = calculateFitness(schedule);
		Solution particleSolution = new Solution(positions,fitness);
		return new BAParticle(particleSolution, createRandomVelocities());
	}


	private LinkedList<LinkedList<Integer>> createRandomPositions() {
		Random rdm = new Random();
		LinkedList<LinkedList<Integer>> positions = new LinkedList<>();
		for (int i = 0; i < this.numberOfOperations; i++) {
			LinkedList<Integer> nextJobPositions = new LinkedList<>();
			LinkedList<Integer> unused = new LinkedList<>();
			for (int j = 0; j < this.numberOfJobs; j++) {
				unused.add(j);
			}
			for (int j = 0; j < this.numberOfJobs; j++) {
				nextJobPositions.add(unused.remove(rdm.nextInt(unused.size())));
			}
			positions.add(nextJobPositions);
		}
		return positions;
	}
	
	private LinkedList<LinkedList<Double>> createRandomVelocities() {
		Random rdm = new Random();
		LinkedList<LinkedList<Double>> velocities = new LinkedList<>();
		for (int i = 0; i < this.numberOfOperations; i++) {
			LinkedList<Double> nextJobVolocities = new LinkedList<>();
			for (int j = 0; j < this.numberOfJobs; j++) {
				nextJobVolocities.add(0.0);
			}
			velocities.add(nextJobVolocities);
		}
		return velocities;
	}
	
//	private void printSolutionsFitness() {
//		int totfit = 0;
//		for (Particle particle : this.population) {
//			totfit += particle.getCurrentFitness();
////			System.out.println(particle.getCurrentFitness());
////			System.out.println(particle.getpBest().getFitness());
////			System.out.println();
//		}
//		System.out.println("avg fit: " + totfit/this.populationSize);
//	}
}
