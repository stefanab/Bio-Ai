package jsspBA;

import java.util.LinkedList;

import jssp.Solution;
import jsspBA.BAMain.BAGlobals;

public class FlowerPatch {

	private BAParticle bestSolution;
	private int bestSolutionFitness;
	private LinkedList<BAParticle> bees;
	private int timesSinceBetterSolutionWasFound;
	private LinkedList<LinkedList<Double>> tabuList;
	private Boolean elite;
	private int neighborhoodSize;
	
	
	
	public void setTabuList(LinkedList<LinkedList<Double>> tabuList) {
		this.tabuList = tabuList;
	}


	public int getNeighborhoodSize() {
		return neighborhoodSize;
	}


	public void setNeighborhoodSize(int neighborhoodSize) {
		this.neighborhoodSize = neighborhoodSize;
	}


	public FlowerPatch(BAParticle bestSolution, LinkedList<LinkedList<Double>> tabuList, Boolean elite) {
		this.timesSinceBetterSolutionWasFound = 0;
		this.bestSolution = bestSolution;
		this.bestSolutionFitness = bestSolution.getCurrentFitness();
		this.bees = new LinkedList<>();
		this.tabuList = tabuList;
		bees.add(bestSolution);
		this.elite = elite;
		this.neighborhoodSize = BAGlobals.NEIGHBORHOOD_SIZE;
	}
	
	
	public void setBestSolution(BAParticle bestSolution) {
		this.bestSolution = bestSolution;
		this.bestSolutionFitness = bestSolution.getpBest().getFitness();
		}


	public void setTimesSinceBetterSolutionWasFound(int timesSinceBetterSolutionWasFound) {
		this.timesSinceBetterSolutionWasFound = timesSinceBetterSolutionWasFound;
	}


	public void addBee(BAParticle bee) {
		int index = 0;
		while(index < bees.size() && bee.getCurrentFitness() > bees.get(index).getCurrentFitness()) {
			index++;
		}
		bees.add(index, bee);
	}
	
	public BAParticle getBestSolution() {
		return bestSolution;
	}

	public int getBestSolutionFitness() {
		return bestSolutionFitness;
	}

	public LinkedList<BAParticle> getBees() {
		return bees;
	}

	public int getTimesSinceBetterSolutionWasFound() {
		return timesSinceBetterSolutionWasFound;
	}

	public LinkedList<LinkedList<Double>> getTabuList() {
		return tabuList;
	}

	public Boolean getElite() {
		return elite;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return getBestSolutionFitness() + "";
	}
	
	
}
