package assign2MDVRP;

/**
 * @author Stefan
 * Classwhich stores and transfers information on a single route
 */
public class SingleRouteInfo {

	private final double cost;
	private final double duration;
	private final double load;
	
	public SingleRouteInfo(double cost, double duration, double load) {
		this.cost = cost;
		this.duration = duration;
		this.load = load;
	}

	public double getCost() {
		return cost;
	}

	public double getDuration() {
		return duration;
	}

	public double getLoad() {
		return load;
	}
	
}
