package assign2MDVRP;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import assign2MDVRP.mdvrpmain.Globals;


public class MutationMethods {

	private final LinkedList<Depot> depots;
	private final LinkedList<Customer> customers;
	
	public MutationMethods(LinkedList<Customer> customers, LinkedList<Depot> depots) {
		this.customers = customers;
		this.depots = depots;
	}
	
	/**
	 * @param chromosome 	mdvrpChromosome to mutate
	 * @param rs			RouteScheduler used to calculate route values
	 * @return				mdvrpChromosome mutated chromosome where a random swath is reversed in one of the depots
	 */
	public mdvrpChromosome reverseOperator(mdvrpChromosome chromosome, RouteScheduler rs) {
		Random rdm = new Random();
		int depotnumber = rdm.nextInt(chromosome.getDepots().size());
		//compare the two depots and retain the same customers if they are the same in the position. Else insert the first unused customer from 
		//second depot route
		LinkedList<String> customers = chromosome.getDepots().get(depotnumber);
		int allele1 = rdm.nextInt(customers.size());
		int allele2 = rdm.nextInt(customers.size());
		if (allele2 < allele1) {
			int holder = allele1;
			allele1 = allele2;
			allele2 = holder;
		}
		List<String> reversedList = new LinkedList<String>();
		List<String> sublist = customers.subList(allele1, allele2);
		for (String string : sublist) {
			reversedList.add(string);
		}
		for (int i = allele1; i < allele2; i++) {
			customers.set(allele1, reversedList.remove(reversedList.size()-1));
		}
		RouteInfo ri = rs.scheduleRoutes(customers, depotnumber);
		chromosome.setDepotCost(ri.totalDepotCost, depotnumber);
		chromosome.setDepotRoutePartition(ri.routePartition, depotnumber);
		chromosome.setSingleDepot(customers, depotnumber);
		return chromosome;
	}
	
	public mdvrpChromosome switchOperator(mdvrpChromosome chromosome, RouteScheduler rs) {
		Random rdm = new Random();
		//select random depot
		int depotnumber = rdm.nextInt(chromosome.getDepots().size());
		LinkedList<String> customers = chromosome.getDepots().get(depotnumber);
		//select random customer
		String customer = customers.remove(rdm.nextInt(customers.size()));
		customers.add(rdm.nextInt(customers.size()), customer);
		RouteInfo ri = rs.scheduleRoutes(customers, depotnumber);
		chromosome.setDepotCost(ri.totalDepotCost, depotnumber);
		chromosome.setDepotRoutePartition(ri.routePartition, depotnumber);
		return chromosome;
	}
	
	public mdvrpChromosome switchWithInsertionBiasOperator(mdvrpChromosome chromosome, RouteScheduler rs) {
		Random rdm = new Random();
		//select random depot
		int depotnumber = rdm.nextInt(chromosome.getDepots().size());
		LinkedList<String> customers = chromosome.getDepots().get(depotnumber);
		//select random customer
		String customer = customers.remove(rdm.nextInt(customers.size()));
		double bestDepotFitness = Double.MAX_VALUE;
		int bestInsertion = 0;
		for (int i = 0; i < customers.size(); i++) {
			customers.add(i, customer);
			RouteInfo ri = rs.scheduleRoutes(customers, depotnumber);
			chromosome.setDepotCost(ri.totalDepotCost, depotnumber);
			chromosome.setDepotRoutePartition(ri.routePartition, depotnumber);
			if(ri.totalDepotCost < bestDepotFitness) {
				bestDepotFitness = ri.totalDepotCost;
				bestInsertion = i;
			}
			customers.remove(customer);
		}
		customers.add(bestInsertion, customer);
		RouteInfo ri = rs.scheduleRoutes(customers, depotnumber);
		chromosome.setDepotCost(ri.totalDepotCost, depotnumber);
		chromosome.setDepotRoutePartition(ri.routePartition, depotnumber);
		return chromosome;
	}
	
	/**
	 * Shifts a single customer to another depot
	 * 
	 * @param chromosome 	mdvrpChromosome to mutate
	 * @param rs			RouteScheduler used for calculating route values
	 * @return				mdvrpChromosome where one customer is moved from a depot to another
	 */
	public mdvrpChromosome interDepotOperator(mdvrpChromosome chromosome, RouteScheduler rs) {
		//Initiate internal variables
		LinkedList<Integer> worstDepots = new LinkedList<Integer>();
		LinkedList<Double> depotLeftoverLoads = new LinkedList<Double>();
		double maxLoad = depots.get(0).getMaxAllowedVehicleLoad();
		//Add first route load
		double lastRouteLoad = chromosome.getCurrentLoad().get(0) % maxLoad;
		depotLeftoverLoads.add(lastRouteLoad);
		worstDepots.add(0);
		//Compute rest of depots
		for (int i = 1; i < chromosome.getCurrentLoad().size(); i++) {
			//ith depot value
			lastRouteLoad = chromosome.getCurrentLoad().get(i) % maxLoad;	
			int index = 0;
			//Sort depot value
			while(lastRouteLoad > depotLeftoverLoads.get(index)) {
				index++;
				//end of list
				if(!(index < depotLeftoverLoads.size())) {
				break;
				}
			}
			//check if we are at the end of the list
			if (!(index < depotLeftoverLoads.size())) {
				//insert at the end
				worstDepots.add(i);
				depotLeftoverLoads.add(lastRouteLoad);
			} else { // insert at index
				worstDepots.add(index, i);
				depotLeftoverLoads.add(index, lastRouteLoad);
			}
		}
		//start the switch procedure
		//consider each depot, starting with the one with the worst route load partition
		for (int i = 0; i < worstDepots.size(); i++) {
			int consideredDepot = worstDepots.get(i);
			//if more fail than fails maybe not possible to switch any customer from this depot
			int fails = 0;
			while(fails < Globals.FAILS_BEFORE_GIVE_UP_DEPOT) {
				//get next  switchable customer
				Customer switchableCustomer = this.depots.get(consideredDepot).getCloseToSeveralCustomer();
				//check if the customer hasnt been switched earlier
				if (chromosome.getDepots().get(consideredDepot).contains(switchableCustomer.getCustomerNumber()))  {
					//try to move customer to one of its closest depots
					for (int j = 0; j < switchableCustomer.getClosestDepots().size(); j++) {
						//dont switch to the one it tries to switch from
						int switchDepot = switchableCustomer.getClosestDepots().get(j);
						if(switchDepot != consideredDepot) {
							//check if load constraint not violated
							if (trySwitch(switchableCustomer, switchDepot, chromosome)) {
								//remove from previous depot 
								chromosome.getDepots().get(consideredDepot).remove(switchableCustomer.getCustomerNumber());
								//update depot load
								double load = chromosome.currentLoad.get(consideredDepot);
								load -= switchableCustomer.getServiceDemand();
								chromosome.currentLoad.set(consideredDepot, load);
								//add customer to next depot
								//update depot load
								load = chromosome.currentLoad.get(switchDepot);
								load += switchableCustomer.getServiceDemand();
								chromosome.currentLoad.set(switchDepot, load);
								//find best insertion place for the customer
								double bestDepotFitness = Double.MAX_VALUE;
								int bestInsertion = 0;
								LinkedList<String> customers = chromosome.getDepots().get(switchDepot);
								for (int insert = 0; insert < customers.size(); insert++) {
									customers.add(insert, switchableCustomer.getCustomerNumber());
									RouteInfo ri = rs.scheduleRoutes(customers, switchDepot);
									chromosome.setDepotCost(ri.totalDepotCost, switchDepot);
									chromosome.setDepotRoutePartition(ri.routePartition, switchDepot);
									if(chromosome.getFitness() < bestDepotFitness) {
										bestDepotFitness = chromosome.getFitness();
										bestInsertion = i;
									}
									customers.remove(switchableCustomer.getCustomerNumber());
								}
								customers.add(bestInsertion, switchableCustomer.getCustomerNumber());
								//end
								RouteInfo ri = rs.scheduleRoutes(chromosome.getDepots().get(consideredDepot), consideredDepot);
								chromosome.setDepotCost(ri.totalDepotCost, consideredDepot);
								chromosome.setDepotRoutePartition(ri.routePartition, consideredDepot);
								ri = rs.scheduleRoutes(chromosome.getDepots().get(switchDepot), switchDepot);
								chromosome.setDepotCost(ri.totalDepotCost, switchDepot);
								chromosome.setDepotRoutePartition(ri.routePartition, switchDepot);
								return chromosome;
							}
						}
					}
				}
				fails++;
			}
		}
		
		return chromosome;
		
	}
	
	/**
	 * Shifts a single customer to another depot
	 * 
	 * @param chromosome 	mdvrpChromosome to mutate
	 * @param rs			RouteScheduler used for calculating route values
	 * @return				mdvrpChromosome where one customer is moved from a depot to another
	 */
	public mdvrpChromosome interRandomDepotOperator(mdvrpChromosome chromosome, RouteScheduler rs) {
		Random rdm = new Random();
		//select random depot
		LinkedList<Integer> depots = new LinkedList<Integer>();
		for (int i = 0; i < chromosome.getDepots().size(); i++) {
			depots.add(i);
		}
		//start the switch procedure
		//consider each depot, starting with the one with the worst route load partition
		for (int i = 0; i < chromosome.getDepots().size(); i++) {
			int depot = rdm.nextInt(depots.size());
			depot = depots.remove(depot);
			
			//if more fail than fails maybe not possible to switch any customer from this depot
			int fails = 0;
			while(fails < Globals.FAILS_BEFORE_GIVE_UP_DEPOT) {
				//get next  switchable customer
				Customer switchableCustomer = this.depots.get(depot).getCloseToSeveralCustomer();
				//check if the customer hasnt been switched earlier
				if (chromosome.getDepots().get(depot).contains(switchableCustomer.getCustomerNumber()))  {
					//try to move customer to one of its closest depots
					for (int j = 0; j < switchableCustomer.getClosestDepots().size(); j++) {
						//dont switch to the one it tries to switch from
						int switchDepot = switchableCustomer.getClosestDepots().get(j);
						if(switchDepot != depot) {
							//check if load constraint not violated
							if (trySwitch(switchableCustomer, switchDepot, chromosome)) {
								//remove from previous depot 
								chromosome.getDepots().get(depot).remove(switchableCustomer.getCustomerNumber());
								//update depot load
								double load = chromosome.currentLoad.get(depot);
								load -= switchableCustomer.getServiceDemand();
								chromosome.currentLoad.set(depot, load);
								//add customer to next depot
								//update depot load
								load = chromosome.currentLoad.get(switchDepot);
								load += switchableCustomer.getServiceDemand();
								chromosome.currentLoad.set(switchDepot, load);
								//insert customer in random place
								int place = rdm.nextInt(chromosome.getDepots().get(switchDepot).size());
								chromosome.getDepots().get(switchDepot).add(place, switchableCustomer.getCustomerNumber());
								//end
								//update both depots
								RouteInfo ri = rs.scheduleRoutes(chromosome.getDepots().get(depot), depot);
								chromosome.setDepotCost(ri.totalDepotCost, depot);
								chromosome.setDepotRoutePartition(ri.routePartition, depot);
								ri = rs.scheduleRoutes(chromosome.getDepots().get(switchDepot), switchDepot);
								chromosome.setDepotCost(ri.totalDepotCost, switchDepot);
								chromosome.setDepotRoutePartition(ri.routePartition, switchDepot);
								return chromosome;
							}
						}
					}
				}
				fails++;
			}
		}
		
		return chromosome;
		
	}
	
	public boolean trySwitch(Customer customer, int depot, mdvrpChromosome chromo) {
		return (customer.getServiceDemand() + chromo.getCurrentLoad().get(depot) <= this.depots.get(depot).getMaxTotalLoad()); 
	}
}
