package assign2MDVRP;

import java.util.LinkedList;
import java.util.List;

import assign2MDVRP.mdvrpmain.Globals;


public class Customer implements mapPoint {

	
	
	private final double xCoordinate;
	private final double yCoordinate;
	private final String customerNumber;
	private final double serviceDuration;
	private final double serviceDemand;
	private boolean closeToSeveralDepots;
	private LinkedList<Integer> closestDepots;
	
	public Customer(String customerNr, double xcor, double ycor, double serviceDuration, double serviceDemand) {
		this.xCoordinate = xcor;
		this.yCoordinate = ycor;
		this.customerNumber = customerNr;
		this.serviceDuration = serviceDuration;
		this.serviceDemand = serviceDemand;
		this.closeToSeveralDepots = false;
		closestDepots = new LinkedList<Integer>();
		
	}
	
	public void setClosestDepots(LinkedList<Integer> closestDepots, List<Double> distances,  double sum) {
		this.closestDepots.add(closestDepots.getFirst());
		int i = 1;
		while ( ((distances.get(0)/sum) / (distances.get(i)/sum))> (Globals.CLOSE_RATE+0.05*(i-1))) {
			setCloseToSeveralDepots(true);
			this.closestDepots.add(closestDepots.get(i));
			i++;
			if (i >= distances.size()){
				break;
			}
		}
		
		
	}
	
	public LinkedList<Integer> getClosestDepots() {
		return closestDepots;
	}

	public boolean isCloseToSeveralDepots() {
		return closeToSeveralDepots;
	}

	public void setCloseToSeveralDepots(boolean closeToSeveralDepots) {
		this.closeToSeveralDepots = closeToSeveralDepots;
	}

	public double getXCor() {
		return xCoordinate;
	}



	public double getYCor() {
		return yCoordinate;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public double getServiceDuration() {
		return serviceDuration;
	}

	public double getServiceDemand() {
		return serviceDemand;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Customer: " + customerNumber;
	}
	
}
