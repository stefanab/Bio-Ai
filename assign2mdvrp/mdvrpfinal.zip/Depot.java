package assign2MDVRP;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;



public class Depot implements mapPoint {

	private final String depotNumber;
	private final double maxAllowedVehicleLoad;
	private final double maxNumberOfVehicles;
	private final double maxDurationOfRoute;
	private final double xcor;
	private final double ycor;
	private final double maxTotalLoad;
	private double currentDepotLoad;
	private LinkedList<Customer> customers;
	private LinkedList<Customer> closeToSeveralCustomers = new LinkedList<Customer>();
	private LinkedList<String> customerRep;
	private LinkedList<Integer> routePartition;
	
	public Depot(String depotNumber, double xcor, double ycor, double maxDurationOfRoute, double maxAllowedVehicleLoad, double maxNumberOfVehicles)  {
		this.depotNumber = depotNumber;
		this.maxAllowedVehicleLoad = maxAllowedVehicleLoad;
		this.customers = new LinkedList<Customer>();
		this.maxNumberOfVehicles = maxNumberOfVehicles;
		if ( maxDurationOfRoute == 0) {
			this.maxDurationOfRoute = Double.MAX_VALUE;
		} else {
			this.maxDurationOfRoute = maxDurationOfRoute;
		}
		this.xcor = xcor;
		this.ycor = ycor;
		this.maxTotalLoad = maxAllowedVehicleLoad * maxNumberOfVehicles;
		this.currentDepotLoad = 0;
		customerRep = new LinkedList<String>();
		routePartition = new LinkedList<Integer>();
	}
	
	public boolean addCustomer(Customer customer) {
		
			setCurrentDepotLoad(customer.getServiceDemand());
			this.customers.add(customer);
			if(customer.isCloseToSeveralDepots()) {
				this.closeToSeveralCustomers.add(customer);
			}
			return true;
	}
	
	public void setCurrentDepotLoad(double load) {
		currentDepotLoad += load;
	}
	
	public Customer getCloseToSeveralCustomer() {
		Random rdm = new Random();
		if(!closeToSeveralCustomers.isEmpty()) {
			int cust = rdm.nextInt(this.closeToSeveralCustomers.size());
			return closeToSeveralCustomers.get(cust);
		}
		System.out.println("no close to several customer but still too high load");
		return null;
	}
	
	public void removeCustomer(Customer customer) {
		setCurrentDepotLoad(-customer.getServiceDemand());
		customers.remove(customer);
	}
	
	
	
	public double getCurrentDepotLoad() {
		return currentDepotLoad;
	}

	@Override
	public double getXCor() {
		return xcor;
	}

	@Override
	public double getYCor() {
		return ycor;
	}

	public String getDepotNumber() {
		return depotNumber;
	}

	
	public double getMaxTotalLoad() {
		return maxTotalLoad;
	}

	public LinkedList<Customer> getCustomers() {
		return customers;
	}

	public double getMaxAllowedVehicleLoad() {
		return maxAllowedVehicleLoad;
	}
	

	public double getMaxNumberOfVehicles() {
		return maxNumberOfVehicles;
	}

	public double getMaxDurationOfRoute() {
		return maxDurationOfRoute;
	}

	
	public LinkedList<String> getCustomerRep() {
		return customerRep;
	}

	public void setCustomerRep(LinkedList<String> customerRep) {
		this.customerRep = customerRep;
	}

	public LinkedList<Integer> getRoutePartition() {
		return routePartition;
	}

	public void setRoutePartition(LinkedList<Integer> routePartition) {
		this.routePartition = routePartition;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Depot: " + depotNumber;
	}
}
