package assign2MDVRP;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * @author Stefan
 *  class which transfers the improved info in the depot routes
 */
public class ImprovedRouteInfo {

	private LinkedList<Integer> partition;
	private ArrayList<Double> routeCosts;
	
	/**
	 * @param partition 	, the partiton into routes of the customers in the depot
	 * @param routeCosts 	, the costs of each route in the depot
	 */
	public ImprovedRouteInfo(LinkedList<Integer> partition, ArrayList<Double> routeCosts) {
		this.partition = partition;
		this.routeCosts = routeCosts;
	}

	public LinkedList<Integer> getPartition() {
		return partition;
	}

	public ArrayList<Double> getRouteCosts() {
		return routeCosts;
	}
	
	
}
