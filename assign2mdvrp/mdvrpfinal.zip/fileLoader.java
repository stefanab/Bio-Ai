package assign2MDVRP;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class fileLoader {

	
	public fileLoader() {
		
	}
	
	public mdvrpmain loadFile(String fileLoc) {
			LinkedList<Depot> depots = new LinkedList<Depot>();
			LinkedList<Customer> customers = new LinkedList<Customer>();
			try {
				BufferedReader br = new BufferedReader(new FileReader(fileLoc));
				try {
					if(br.ready()){
						String firstLine = br.readLine();
						String[] firstLineSplit = firstLine.split(" ");
						int maxNumberOfVehicles = Integer.parseInt(firstLineSplit[0]);
						int totalNumberOfCustomers = Integer.parseInt(firstLineSplit[1]);
						int totalNumberOfDepots = Integer.parseInt(firstLineSplit[2]);
						ArrayList<ArrayList<Double>> halfDepots = new ArrayList<ArrayList<Double>>();
						for (int i = 0; i < totalNumberOfDepots; i++) {
							String line = br.readLine();
							String[] lineSplit = line.split(" ");
							
							ArrayList<Double> thisDepot = new ArrayList<Double>();
							thisDepot.add(Double.parseDouble(lineSplit[0]));
							thisDepot.add(Double.parseDouble(lineSplit[1]));
							halfDepots.add(thisDepot);
						}
						for (int i = 0; i < totalNumberOfCustomers; i++) {
							String line = br.readLine();
							String[] lineSplit = line.split(" ");
							
							
							ArrayList<String> finalString = new ArrayList<String>();
							for (String string : lineSplit) {
								if(!string.equals("")) {
									finalString.add(string);
								}
							}
							int custNR = Integer.parseInt(finalString.get(0)) - 1;
							
							customers.add(new Customer((custNR + ""), Double.parseDouble(finalString.get(1)), Double.parseDouble(finalString.get(2)),
									Double.parseDouble(finalString.get(3)), Double.parseDouble(finalString.get(4))));
							
						}
						for (int i = 0; i < totalNumberOfDepots; i++) {
							String line = br.readLine();
							String[] lineSplit = line.split(" ");
							ArrayList<String> finalString = new ArrayList<String>();
							for (String string : lineSplit) {
								if(!string.equals("")) {
									finalString.add(string);
								}
							}
							depots.add(new Depot(i + "", Double.parseDouble(finalString.get(1)), Double.parseDouble(finalString.get(2)), 
									halfDepots.get(i).get(0), halfDepots.get(i).get(1), maxNumberOfVehicles ));
							
						}
						
					}
				
				
				br.close();
			} catch (IOException f) {
				// TODO Auto-generated catch block
				System.out.println("not ready");
				f.printStackTrace();
			}
			
			} catch (FileNotFoundException e) {
				System.out.println("file not found in this directory");
				e.printStackTrace();
			}
			return new mdvrpmain(customers, depots);
		
	}
	
}
