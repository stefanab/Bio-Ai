package assign2MDVRP;

public interface mapPoint {

	public double getXCor();
	
	public double getYCor();
	
}
