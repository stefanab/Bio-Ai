package assign2MDVRP;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;





/**
 * @author Stefan
 *
 */

public class mdvrpmain {

	public class Globals {
		//MutationMethods
		static final int FAILS_BEFORE_GIVE_UP_DEPOT = 2; //number of fails to insert randomly chosen customer into a depot
		//Customer
		public static final double CLOSE_RATE = 0.850; //rate two depot distances need to exceed to be close to multiple depots
		//mdvrpChromosome
		static final int ROUTE_PENALTY = 200; //fitness penalty for a route
		//mdvrpMain
		public static final double PICK_WORSE_PARENT = 0.8; //chance of picking worse parent in tournament
		public static final int NOT_FEASIBLE_PENALTY = 2;   //fitness penalty for not being feasible (not used)
		static final int ITERATIONS = 4000;					//Number of iterations
		static final double MUTATION_CHANCE = 0.4;			// Chance of a mutation to happen 
		static final int POPULATION_SIZE = 400;				// Population size //turn up if converging to quick
		static final double RANDOM_BIAS = 1.3;				//bias used to pick better ranked parents. if > 1 higher chance for better fitness parent /turn up if convergence too slow
		static final int INTER_DEPOT_MUTATION = 10;			//(not used)
		static final double ADDITIONAL_CHANCE = 1;			// Additional chance to accept a parent (not used)
		static final int NEXT_GENERATION_SIZE = 10;			// Next generation size (real value is 2x since there are 2 children for each iteration
		static final double CROSSOVER_CHANCE = 0.6;			//pick between two crossovers. higher for higher prob of bcrc
		static final double INSERT_METHOD = 0.8;			//chose insert method in BcRC. lower for higher prob of ingoring feasability
	}
	private static String mapnr = "13";
	private static String fileLoc = "C:/Users/Stefan/Desktop/NTNU/IT3708 Bio AI/Data/Data Files/p" + mapnr;
	private final LinkedList<Depot> depots;
	private final LinkedList<Customer> customers;
	private final LinkedList<String> isCloseList = new LinkedList<String>();
	private LinkedList<mdvrpChromosome> population = new LinkedList<mdvrpChromosome>();
	
	public mdvrpmain(LinkedList<Customer> customers2, LinkedList<Depot> depots2) {
		this.depots = depots2;
		this.customers = customers2;
		
	}
	
	public mdvrpChromosome cloneChromosome(mdvrpChromosome chromosome) {
		//initate new lists for cloning
		ArrayList<LinkedList<String>> depots = new ArrayList<LinkedList<String>>();
		ArrayList<LinkedList<Integer>> depotRoutePartitions = new ArrayList<LinkedList<Integer>>();
		ArrayList<Double> currentLoad = new ArrayList<Double>();;
		//clone customers from depot
		for (int i = 0; i < chromosome.depots.size(); i++) {
			LinkedList<String> nextDepot = chromosome.getDepots().get(i);
			LinkedList<String> newNextDepot = new LinkedList<String>();
			for (int j = 0; j < nextDepot.size(); j++) {
				newNextDepot.add(nextDepot.get(j));
			}
			//add cloned depot
			depots.add(newNextDepot);
			//clone route partitions
			LinkedList<Integer> nextPartition = chromosome.getDepotRoutePartitions().get(i);
			LinkedList<Integer> newNextPartition = new LinkedList<Integer> ();
			for (int j = 0; j < nextPartition.size(); j++) {
				newNextPartition.add(nextPartition.get(j));
			}
			depotRoutePartitions.add(newNextPartition);
			currentLoad.add(chromosome.getCurrentLoad().get(i));
		}
		mdvrpChromosome clonedChromosome = new mdvrpChromosome(depots, currentLoad);
		clonedChromosome.setCost(chromosome.getCost());
		clonedChromosome.setDepotRoutePartitions(depotRoutePartitions);
		clonedChromosome.setAllDepotCosts((ArrayList<Double>) chromosome.depotCosts.clone());
		return clonedChromosome;
	}
	
	
	public mdvrpChromosome bestRCossoverChild(mdvrpChromosome child, mdvrpChromosome x, mdvrpChromosome y, int depotnumber, int yRouteToInsert, RouteScheduler rs) {
		//clone chosen depot
		
		LinkedList<String> crossoverDepot1 = (LinkedList<String>) x.getDepots().get(depotnumber).clone();
		LinkedList<Integer> partitions1 = (LinkedList<Integer>) x.getDepotRoutePartitions().get(depotnumber).clone();
		List<String> crossoverDepot2route = new LinkedList<String>();
		//get depot2 and partitions for easier code
		LinkedList<String> depot2 = y.getDepots().get(depotnumber);
		LinkedList<Integer> partitions2 = (LinkedList<Integer>) y.getDepotRoutePartitions().get(depotnumber);
		//set the chosen route to crossoverdepot2route
		if(yRouteToInsert == 0) {
			crossoverDepot2route = depot2.subList(0, partitions2.getFirst());
		} else {
			crossoverDepot2route = depot2.subList(partitions2.get(yRouteToInsert-1)
									, partitions2.get(yRouteToInsert));
		}
		List<String> realCrossoverdepot2route = new LinkedList<String>();
		//check if any customers in the selected route doesnt exist in the x depot. these customers must be clsoe to several depots
		for (String customer : crossoverDepot2route) {
			if(!this.customers.get(Integer.parseInt(customer)).isCloseToSeveralDepots()){
				realCrossoverdepot2route.add(customer);
				
			} else {
				if(crossoverDepot1.contains(customer)) {
					realCrossoverdepot2route.add(customer);
				
				}
			}
		}
		//remove all customers in crossoverDepot and update partition 
		for (int i = 0; i < realCrossoverdepot2route.size(); i++) {
			int index = 0;
			for (int j = 0; j < crossoverDepot1.size(); j++) {
				//hvis vi finner posisjon, m� vi dekrementere alle route partition indeksene med og etter j
				if(crossoverDepot1.get(j).equals(realCrossoverdepot2route.get(i))) {
					//lagre indeksen til kunden som skal fjernes
					index = j;
					//dekrenter alle indekser etter
					for (int j2 = 0; j2 < partitions1.size(); j2++) {
						int nextpartition1 = partitions1.get(j2); 
						if(nextpartition1 >= j) {
							nextpartition1--;
								partitions1.set(j2, nextpartition1);
						}
					}
					break;
				}
				
			}
			crossoverDepot1.remove(index);
		}
		//all customers removed means all partitions will be 0 and the list will be empty
		if(crossoverDepot1.isEmpty()) {
			crossoverDepot1.add(realCrossoverdepot2route.remove(0));
			int part = partitions1.getLast() + 1;
			partitions1.set(partitions1.getLast(), part);
		}
		Depot depotRep = this.depots.get(depotnumber);
		
		while(!partitions1.isEmpty() && partitions1.getFirst()<= 0) {
			partitions1.removeFirst();
		}
		//start crossover procedure. Check best location of each customer and feasibility.
		//for each customer in selected route
		Random rdm = new Random();
		for (int i = 0; i < realCrossoverdepot2route.size(); i++) {
			//current depot costs
			ArrayList<Double> depotRouteCosts = rs.calculateAllRouteCosts(crossoverDepot1, partitions1, depotnumber);
			String customer = realCrossoverdepot2route.get(i);
			int thisRouteStart = 0;
			int routeNumber = 0;
			int thisRouteEnd = partitions1.get(0);
			int bestFeasibleLocation = crossoverDepot1.size();
			int bestLocation = 0;
			int bestRouteNumber = 0;
			int bestFeasibleRouteNumber = 0;
			double bestCost = Double.MAX_VALUE;
			double bestFeasibleCost = Double.MAX_VALUE;
			//try all places in the list, j
			for (int j = 1; j < crossoverDepot1.size(); j++) {
				j--;
				if(j >= thisRouteEnd) {
					routeNumber++;
					thisRouteStart = thisRouteEnd;
					thisRouteEnd = partitions1.get(routeNumber);
				}
				//retrieve list of customers in this route
				List<String> consideredRoute1 = crossoverDepot1.subList(thisRouteStart, thisRouteEnd);
				LinkedList<String> consideredRoute = createLinkedList(consideredRoute1);
				
				//insert customer at each location, k, in route
				for (int k = 0; k < consideredRoute.size(); k++) {
					consideredRoute.add(k, customer);
					RouteInfo ri = rs.scheduleRoutes( consideredRoute, depotnumber);
					//calculate total cost of new depot
					double totCost = 0;
					for (int l = 0; l < depotRouteCosts.size(); l++) {
						if(l == routeNumber) {
							totCost += ri.totalDepotCost;
						} else {
							totCost += depotRouteCosts.get(l);
						}
					}
					//give route penalty for solutions with more routes
					totCost+=Globals.ROUTE_PENALTY*ri.routePartition.size();
					if (totCost < bestCost) {
						bestCost = totCost;
						bestLocation = thisRouteStart+k;
						bestRouteNumber = routeNumber;
					}
					//if partition is greater than 1 it means the route was broken and solutoin unfeasible
					if(!(ri.routePartition.size() > 1)) {
						if (totCost < bestFeasibleCost) {
							bestFeasibleCost = totCost;
							bestFeasibleLocation = thisRouteStart+k;
							bestFeasibleRouteNumber = routeNumber;
						}
					}
					consideredRoute.remove(k);
				}
				j = thisRouteEnd;
			}
			//add customer to best location and update partition and customer list
			double insertMethod = rdm.nextDouble();
			//try feasible or insert at back
			if(insertMethod <= Globals.INSERT_METHOD) {
				if(bestFeasibleCost < Double.MAX_VALUE) {
					crossoverDepot1.add(bestFeasibleLocation, customer);
					for (int j = 0; j < partitions1.size(); j++) {
						if(j >= bestFeasibleRouteNumber) {
							int part = partitions1.get(j) + 1;
							partitions1.set(j, part);
						}
					}
				} else {
					crossoverDepot1.addLast(customer);
					partitions1.addLast(crossoverDepot1.size());
				}
						
			} else {
				//if the best solution is still feasible insert in normal way
				if(bestFeasibleLocation == bestLocation) {
					if(bestFeasibleCost < Double.MAX_VALUE) {
						crossoverDepot1.add(bestFeasibleLocation, customer);
						for (int j = 0; j < partitions1.size(); j++) {
							if(j >= bestFeasibleRouteNumber) {
								int part = partitions1.get(j) + 1;
								partitions1.set(j, part);
							}
						}
					}
				//else it means the route will break. 	
				} else {
					
				int startIndex = 0;
				List<String> consideredRoute;
				LinkedList<String> newconsideredRoute;
				if(bestRouteNumber == 0) {
					consideredRoute =  crossoverDepot1.subList(startIndex, partitions1.get(bestRouteNumber));
				} else {
					startIndex = partitions1.get(bestRouteNumber-1);
					consideredRoute =  crossoverDepot1.subList(startIndex, partitions1.get(bestRouteNumber));
				}
				//recalculate the route partitions for this insertion
				consideredRoute.add(bestLocation - startIndex, customer);
				newconsideredRoute = createLinkedList(consideredRoute);
				RouteInfo ri = rs.scheduleRoutes(newconsideredRoute, depotnumber);
					//increment later routes after added customer
					for (int j = 0; j < partitions1.size(); j++) {
						if(j >= bestRouteNumber) {
							int part = partitions1.get(j) + 1;
							partitions1.set(j, part);
						}
					}
					if(ri.routePartition.size() > 1) {
						
						ri.routePartition.removeLast();
					}
					//add new routes
					for (int j = 0; j < ri.routePartition.size(); j++) {
						int nextPartition = ri.routePartition.getLast();
						nextPartition += startIndex;
						partitions1.add(bestRouteNumber, nextPartition);
						
					}
				}
			}
		}
		
		child.setDepotRoutePartition(partitions1, depotnumber);
		child.setSingleDepot(crossoverDepot1, depotnumber);
		ArrayList<Double> costs = rs.calculateAllRouteCosts(crossoverDepot1, partitions1, depotnumber);
		double sum = 0;
		for (int i = 0; i < costs.size(); i++) {
			sum+= costs.get(i);
		}
		child.setDepotCost(sum, depotnumber);
		return child;
	}
	
	public LinkedList<String> createLinkedList(List<String> list) {
		LinkedList<String> consideredRoute = new LinkedList<String>();
		for (String string : list) {
			consideredRoute.add(string);
		}
		return consideredRoute;
	}

	
	public LinkedList<String> makeCrossoverChild(mdvrpChromosome x,mdvrpChromosome y, int depotnumber, RouteScheduler rs) {
		Random rdm = new Random();
		Depot crossoverDepot = this.depots.get(depotnumber);
		LinkedList<String> crossoverDepot1 = (LinkedList<String>) x.getDepots().get(depotnumber).clone();
		LinkedList<String> crossoverDepot2 = new LinkedList<String>();
		for (String customer : y.getDepots().get(depotnumber)) {
			if(this.customers.get(Integer.parseInt(customer)).isCloseToSeveralDepots()) {
				if(!crossoverDepot1.contains(customer)) {
					
				} else {
					crossoverDepot2.add(customer);
				}
			} else {
				crossoverDepot2.add(customer);
			}
		}
		//check if there exists customers in depot 1 which does not exist in depot 2. This means that the customers are close to several depots.
		LinkedList<Integer> uniqueCustomersPosition = new LinkedList<Integer>();
		if(crossoverDepot1.size() > crossoverDepot2.size()) {
			for (int i = 0; i < crossoverDepot1.size(); i++) {
				//check if customer in pos i may have been moved from depot 2
				if(this.customers.get(Integer.parseInt(crossoverDepot1.get(i))).isCloseToSeveralDepots()) {
					if(!crossoverDepot2.contains(crossoverDepot1.get(i))){
						uniqueCustomersPosition.add(i);
					}
				}
			}
		}
		//add size of depot to avoid no element found exception
		uniqueCustomersPosition.add(crossoverDepot1.size());
		//compare the two depots and retain the same customers if they are the same in the position. Else insert the first unused customer from 
		//second depot route
		int allele1 = rdm.nextInt(crossoverDepot1.size());
		int allele2 = rdm.nextInt(crossoverDepot1.size());
		if (allele2 < allele1) {
			int holder = allele1;
			allele1 = allele2;
			allele2 = holder;
		}
		//remove number between the alleles
		List<String> sublist = crossoverDepot1.subList(allele1, allele2);
		for (String customer : sublist) {
			crossoverDepot2.remove(customer);
		}
		//remove from before the allele unless its unique
		for (int i = 0; i < allele1; i++) {
			if (i != uniqueCustomersPosition.getFirst()) {
				crossoverDepot1.set(i, crossoverDepot2.removeFirst());
			} else {
				uniqueCustomersPosition.removeFirst();
			}
		}
		for (int i = allele1; i < allele2; i++) {
			if(i == uniqueCustomersPosition.getFirst()) {
				uniqueCustomersPosition.removeFirst();
			}
		}
		for (int i = allele2; i < crossoverDepot1.size(); i++) {
			if (i != uniqueCustomersPosition.getFirst()) {
				crossoverDepot1.set(i, crossoverDepot2.removeFirst());
			} else {
				uniqueCustomersPosition.removeFirst();
			}
		}
		
		double randomchoice = rdm.nextDouble();
		if(randomchoice < .01) {
			for (int kl = 0; kl< crossoverDepot1.size()/4; kl++) {
				
			//Find best insertion place for the first customer of depot into the best place (store best fitness place and best cost place)
			int bestFitnessIndex = 0;
			double bestFitness = Double.MAX_VALUE;
			int bestCostIndex = 0;
			double bestCost = Double.MAX_VALUE;
			int customerChoice = rdm.nextInt(crossoverDepot1.size());
			String customer = crossoverDepot1.remove(customerChoice);
			for (int i = 0; i < crossoverDepot1.size(); i++) {
				crossoverDepot1.add(i, customer);
				RouteInfo ri = rs.scheduleRoutes(crossoverDepot1, depotnumber);
				
				if(ri.totalDepotCost < bestCost) {
					bestCost = ri.totalDepotCost;
					bestCostIndex = i;
				}
				if(ri.totalDepotCost + ri.routePartition.size()*Globals.ROUTE_PENALTY < bestFitness) {
					bestFitness = ri.totalDepotCost + ri.routePartition.size()*Globals.ROUTE_PENALTY;
					bestFitnessIndex = i;
				}
				crossoverDepot1.remove(customer);
			}
			//Insert customer at a better place with a chance
			
				//pick to prefer depot cost or total fitness
				double random = rdm.nextDouble();
				if (random < .5) {
					crossoverDepot1.add(bestCostIndex, customer);
//					System.out.println("Cost moto " + bestCostIndex);
				} else {
					crossoverDepot1.add(bestFitnessIndex, customer);
//					System.out.println("Fit moto " + bestFitnessIndex);
				}
			
		}
	
		}	
		return crossoverDepot1;
	}
	/**
	 * Creates a child board from x and y using the Order1 crossover. The child will have exactly one queen in each row and exactly one queen in
	 * each column
	 * 
	 * @param x		ArrayList<Integer> board of parent x
	 * @param y		ArrayList<Integer> board of parent y
	 * @return		ArrayList<Integer> board of child. A crossover from x and y
	 */
	private ArrayList<mdvrpChromosome> reproduce(mdvrpChromosome x,mdvrpChromosome y, RouteScheduler rs) {
		Random rdm = new Random();
		ArrayList<mdvrpChromosome> children = new ArrayList<mdvrpChromosome>();
		//clone parents to children
		mdvrpChromosome firstChild = cloneChromosome(x);
		mdvrpChromosome secondChild = cloneChromosome(y);
		//find depot to perform crossover on
		int depotnumber = rdm.nextInt(this.depots.size());
		if(rdm.nextDouble() < Globals.CROSSOVER_CHANCE) {
			int yRouteToInsert = 0;
				if((y.getDepotRoutePartitions().get(depotnumber).size()<= 1)) {
				
				} else {
					yRouteToInsert = rdm.nextInt(y.getDepotRoutePartitions().get(depotnumber).size());
				}
			
			firstChild = bestRCossoverChild(firstChild, x, y, depotnumber, yRouteToInsert, rs);
			if((x.getDepotRoutePartitions().get(depotnumber).size()<= 1)) {
				yRouteToInsert = 0;
			} else {
				yRouteToInsert = rdm.nextInt(x.getDepotRoutePartitions().get(depotnumber).size());
			}
			
			secondChild = bestRCossoverChild(secondChild, y, x, depotnumber, yRouteToInsert, rs);
			
		} else {
			
		for (int i = 0; i < this.depots.size(); i++) {
			depotnumber = i;
		//create the first crossover depot for child 1
		LinkedList<String> crossoverDepot1 = makeCrossoverChild(x, y, depotnumber, rs);
		RouteInfo ri = rs.scheduleRoutes(crossoverDepot1, depotnumber);
		firstChild.setSingleDepot(crossoverDepot1, depotnumber);
		firstChild.setDepotCost(ri.totalDepotCost, depotnumber);
		firstChild.setDepotRoutePartition(ri.routePartition, depotnumber);
		//create crossover depot for child 2
		depotnumber = rdm.nextInt(this.depots.size());
		LinkedList<String> crossoverDepot2 = makeCrossoverChild(y, x, depotnumber, rs);
		RouteInfo ri2 = rs.scheduleRoutes(crossoverDepot2, depotnumber);
		secondChild.setSingleDepot(crossoverDepot2, depotnumber);
		secondChild.setDepotCost(ri2.totalDepotCost, depotnumber);
		secondChild.setDepotRoutePartition(ri2.routePartition, depotnumber);
		}
		}
		
		children.add(firstChild);
		children.add(secondChild);
		return children;
	}
	
	public mdvrpChromosome mutate(mdvrpChromosome chromosome, RouteScheduler rs) {
		Random rdm = new Random();
		MutationMethods mm = new MutationMethods(this.customers, this.depots);
		int mutationOperator = rdm.nextInt(1000);
		if (mutationOperator < 399) {
			chromosome = mm.reverseOperator(chromosome, rs);
		} else if (mutationOperator >=399 && mutationOperator < 908) {
			chromosome = mm.switchOperator(chromosome, rs);
		} else if (mutationOperator >= 908 && mutationOperator < 990) {
			chromosome = mm.switchWithInsertionBiasOperator(chromosome, rs);
		} else if (mutationOperator >= 990 && mutationOperator < 999) {
			chromosome = mm.interRandomDepotOperator(chromosome, rs);
		}else {
			chromosome = mm.interDepotOperator(chromosome, rs);
		}
		return chromosome;
	}
	
	public LinkedList<mdvrpChromosome> getPopulation() {
		return population;
	}
	
	/**
	 * Selects a random Solution from population. Higher probability for solutions with good fitness to be chosen 
	 * 
	 * @param population 	LinkedList<SOlution> population to chose from
	 * @return				Solution a solution from population
	 */
	private ArrayList<mdvrpChromosome> randomSelection(LinkedList<mdvrpChromosome> population) {
		Random rdm = new Random();
		ArrayList<mdvrpChromosome> parents = new ArrayList<mdvrpChromosome>();
		//select first parent with bias towards better solution
			double selectD = Math.pow(population.size(), Globals.RANDOM_BIAS);
//			System.out.println(selectD);
			selectD = rdm.nextInt((int) selectD);
//			System.out.println("sel d " + selectD);
//			System.out.println("sel d invers " + (int)Math.pow(selectD, 1/RANDOM_BIAS));
			int select = (int)Math.pow(selectD, 1/Globals.RANDOM_BIAS);
			
			mdvrpChromosome consideredParent = population.get(select);
			select = rdm.nextInt((int) Math.pow(population.size(), Globals.RANDOM_BIAS));
			selectD = Math.pow(population.size(), Globals.RANDOM_BIAS);
			selectD = rdm.nextInt((int) selectD);
			select = (int)Math.pow(selectD, 1/Globals.RANDOM_BIAS);
			mdvrpChromosome consideredParent2 =  population.get(select);
			mdvrpChromosome best;
			mdvrpChromosome second;
			if (consideredParent.getFitness() < consideredParent2.getFitness()) {
				best = consideredParent;
				second = consideredParent2;
			} else {
				best = consideredParent2;
				second = consideredParent;
			}
			
			if(rdm.nextDouble() > Globals.PICK_WORSE_PARENT) {
				best = second;
			}
		parents.add(best);
		//select second parent with bias towards being different from the first parent and a descent solution	
		mdvrpChromosome secondParent1 = population.get(rdm.nextInt(population.size()));	
		mdvrpChromosome secondParent2 = population.get(rdm.nextInt(population.size()));	
		ArrayList<mdvrpChromosome> seconds = new ArrayList<mdvrpChromosome>();
		seconds.add(secondParent1);
		seconds.add(secondParent2);
		int mostDifferentSencond = 0;
		double difference = -1.0;
		for (int i = 0; i < seconds.size(); i++) {
			double thisdif = 0;
			for (int j = 0; j < best.getDepotCosts().size(); j++) {
				thisdif += Math.abs(best.getDepotCosts().get(j)-seconds.get(i).getDepotCosts().get(j));
			}
			if(thisdif > difference) {
				difference = thisdif;
				mostDifferentSencond = i;
			}
		}
		parents.add(seconds.get(mostDifferentSencond));
		return parents;
	}


	public void mapCustomers() {
		//Start grouping procedure. Measure distance to each depot for all customers
				for (Customer customer : customers) {
					LinkedList<Double> distancesToDepots = new LinkedList<Double>();
					LinkedList<Integer> sortedDepot = new LinkedList<Integer>();
					Depot closest = null;
					double sum = 0;
					for (Depot depot : depots) {
						double dist = euclideanDistance(customer, depot);
						sum += dist;
						if(sortedDepot.isEmpty()) {
							sortedDepot.add(Integer.parseInt(depot.getDepotNumber()));
							distancesToDepots.add(dist);
						} else {
							int i = 0;
							while ((i < distancesToDepots.size()) && (dist > distancesToDepots.get(i))) {
								i++;
								}
							if (i == distancesToDepots.size()) {
								distancesToDepots.addLast(dist);
								sortedDepot.addLast(Integer.parseInt(depot.getDepotNumber()));
							} else {
								sortedDepot.add(i, Integer.parseInt(depot.getDepotNumber()));
								distancesToDepots.add(i, dist);
							}
						}
					}
					customer.setClosestDepots(sortedDepot, distancesToDepots, sum);
					if (customer.isCloseToSeveralDepots()) {
						isCloseList.add(customer.getCustomerNumber());
					}
					int i = 0;
					//Create chromosomes by Adding customers to closest depots without breaking constraints.
					depots.get((customer.getClosestDepots().get(i))).addCustomer(customer);
					for (int j = 0; j < depots.size(); j++) {
						while(depots.get(j).getCurrentDepotLoad() > depots.get(j).getMaxTotalLoad()) {
							System.out.println("too manycustomers");
							Customer customerToMove = depots.get(j).getCloseToSeveralCustomer();
							for (int k = 0; k < customerToMove.getClosestDepots().size(); k++) {
								Depot depot = depots.get(customerToMove.getClosestDepots().get(k));
								if(depot != depots.get(j) && 
								(depot.getCurrentDepotLoad() + customerToMove.getServiceDemand() <= depot.getMaxTotalLoad())){
									depot.addCustomer(customerToMove);
									depots.get(j).removeCustomer(customerToMove);
									break;
								}
							}
						}
					}
				}
	}
	
	/**
	 * Generates the first default chromosome based on the gready allocation of the mapcustomers method
	 * 
	 * @return 
	 */
	public mdvrpChromosome generateFirstChromosome() {
		//create and initiate new lists for the chromosome
		ArrayList<Double> loads = new ArrayList<Double>();
		ArrayList<LinkedList<String>> depotRep = new ArrayList<LinkedList<String>>();
		for (int i = 0; i < this.depots.size(); i++) {
			loads.add(0.0);
			depotRep.add(new LinkedList<String>());
			for (Customer customer : this.depots.get(i).getCustomers()) {
					depotRep.get(i).add(customer.getCustomerNumber());
			}
			loads.set(i, this.depots.get(i).getCurrentDepotLoad());
		}
		//create unfinished chromosome
		return new mdvrpChromosome(depotRep, loads);
	}
	
	/**
	 * Creates the first population based on the default chromosome. 
	 * 
	 * @param rs 	routescheduler with the customers and depots from the given problem
	 */
	public void generateFirstPopulation(RouteScheduler rs) {
		//first chromosome skeleton
		mdvrpChromosome defaultChromosome = generateFirstChromosome();
		//create random permutations of th efirst chromosome
		for (int i = 0; i < Globals.POPULATION_SIZE; i++) {
			ArrayList<Double> loads = new ArrayList<Double>();
			ArrayList<LinkedList<String>> depotRep = new ArrayList<LinkedList<String>>();
			//create next depot
			for (int j = 0; j < defaultChromosome.getDepots().size(); j++) {
				LinkedList<String> list = defaultChromosome.getDepots().get(j);
				LinkedList<String> newList = new LinkedList<String>();
				for (int k = 0; k < list.size(); k++) {
					newList.add(list.get(k));
				}
				LinkedList<String> nextDepotPermutation = new LinkedList<String>();
				Random rdm = new Random();
				//add next customer to depot
				for (int k = 0; k < defaultChromosome.getDepots().get(j).size(); k++) {
					int nextPlace = rdm.nextInt(newList.size());
					String nextCustomer = newList.get(nextPlace);
					nextDepotPermutation.add(nextCustomer);
					newList.remove(nextPlace);
					
				}
				depotRep.add(nextDepotPermutation);
				loads.add(defaultChromosome.currentLoad.get(j));
			}
			//create next unfinished depot
			mdvrpChromosome newChromo = new mdvrpChromosome(depotRep, loads);
			//add all costs and partitions of the chromosome
			double totCost = 0;
			ArrayList<LinkedList<Integer>> partitions = new ArrayList<LinkedList<Integer>>();
			for (int j = 0; j < newChromo.getDepots().size(); j++) {
				RouteInfo ri = rs.scheduleRoutes(newChromo.getDepots().get(j), j);
				totCost += ri.totalDepotCost;
				newChromo.setDepotCost(ri.totalDepotCost,j);
				partitions.add(ri.routePartition);
			
			}
			newChromo.setCost(totCost);
			newChromo.setDepotRoutePartitions(partitions);
			this.population = addToPopulation(newChromo, this.population);
			
		}
	}
	
	/**
	 * Adds an instance of Board to the given population. The population is sorted by value. Best value instances are at the end of the list, worst
	 * value instances at the beginning. The returned list will have ha size which is 1 greater than the size of the input list.
	 * 
	 * @param chromosome				SOlution, instance to be added to population
	 * @param population		LinkedList<solution> population which to add solution
	 * @return					LinkedList<SOlution> updated population with the Solution added in its correct position
	 */
	public LinkedList<mdvrpChromosome> addToPopulation(mdvrpChromosome chromosome , LinkedList<mdvrpChromosome> population) {
		// An empty list can not be compared
		double newIndividualValue = chromosome.getFitness();
		if (population.isEmpty()) {
			population.add(chromosome);
		} else {
			int consideredPopulation = population.size();
			int startIndex = 0;
			while(consideredPopulation > 1) {
				int correctionIndex = Math.floorMod(consideredPopulation, 2);
				consideredPopulation = Math.floorDiv(consideredPopulation, 2);
				mdvrpChromosome consideredChromosome = population.get(consideredPopulation+startIndex);
				if (newIndividualValue > consideredChromosome.getFitness()) {
					
				} else {
					startIndex += consideredPopulation+ correctionIndex;
				}
			}
			if (population.get(startIndex).getFitness() < newIndividualValue) {
				population.add(startIndex, chromosome);
			} else {
				if(startIndex == population.size()-1) {
					population.add(chromosome);
				} else {
					population.add(startIndex+1, chromosome);
				}
			}
		}
		return population;
		
	}
	
	public static void main(String[] args) {
		//TODO main start
		mdvrpmain mdvrp = new fileLoader().loadFile(fileLoc);
		mdvrp.mapCustomers();
//		plot(mdvrp.customers, mdvrp.depots);
		RouteScheduler rs = new RouteScheduler(mdvrp.customers, mdvrp.depots);
		mdvrp.generateFirstPopulation(rs);
		mdvrpChromosome bestMemeber = mdvrp.population.getLast();
		for (int i = 0; i < bestMemeber.getDepots().size(); i++) {
			mdvrp.depots.get(i).setCustomerRep(bestMemeber.getDepots().get(i));
			mdvrp.depots.get(i).setRoutePartition(bestMemeber.getDepotRoutePartitions().get(i));
		}
		System.out.println(bestMemeber.cost);
		printPopulation(mdvrp.population);
		//Start genetic algorithm process with crossover, mutations aetc
		//start genetic algorithm
		int k = 0;
		int stillSame = 0;
				for (int iterations = 0; iterations < Globals.ITERATIONS; iterations++) {
					if(stillSame > 50) {
						break;
					}
					if(iterations == k*50){
						System.out.println(iterations);
						System.out.println("worst " + mdvrp.getPopulation().getFirst().getCost());
						System.out.println("best " + mdvrp.getPopulation().getLast().getCost());
						k++;
					}
					//create next generation
					LinkedList<mdvrpChromosome> offspring = new LinkedList<mdvrpChromosome>();
					for (int i = 0; i < Globals.NEXT_GENERATION_SIZE; i++) {
						//select next parents
						ArrayList<mdvrpChromosome> parents = mdvrp.randomSelection(mdvrp.population);
						mdvrpChromosome x = parents.get(0);
						mdvrpChromosome y = parents.get(1);
						mdvrp.getPopulation().remove(x);
						mdvrp.getPopulation().remove(y);
						
						if(x.equals(y)) {
							System.out.println("still same");
							stillSame++;
							
						}
//						//reproduce
						ArrayList<mdvrpChromosome> twoChildren = mdvrp.reproduce(x,y,rs);
						double extraMutation = mdvrp.getPopulation().getLast().getFitness()/mdvrp.getPopulation().getFirst().getFitness(); 
						for (int j = 0; j < twoChildren.size(); j++) {
							double mutation = Math.random();
							if(mutation < Globals.MUTATION_CHANCE ) {
								twoChildren.set(j, mdvrp.mutate(twoChildren.get(j), rs));
							}
							
						}
//						
//						
//						//child 1 based mostly on parent 1 and same for child 2. Add the best of the two for each
						for (int j = 1; j < parents.size(); j++) {
							if(parents.get(j).getFitness() < twoChildren.get(j).getFitness()) {
								mdvrp.addToPopulation(parents.get(j), mdvrp.getPopulation());
							} else {
								mdvrp.addToPopulation(twoChildren.get(j), mdvrp.getPopulation());
							}
						}
						if(mdvrp.getPopulation().getLast().getCost()/mdvrp.getPopulation().getFirst().getCost() < 0.97) {
							
						mdvrp.addToPopulation(x, mdvrp.population);
						mdvrp.addToPopulation(twoChildren.get(0), mdvrp.getPopulation());
						mdvrp.getPopulation().removeFirst();
						offspring.addAll(twoChildren);
						} else {
							if(x.getFitness() < twoChildren.get(0).getFitness()) {
								mdvrp.addToPopulation(x, mdvrp.population);
							} else {
								mdvrp.addToPopulation(twoChildren.get(0), mdvrp.getPopulation());
								
							}
						}
						
					
					} // end next children
					
//					//add next generation to main population
//					for (mdvrpChromosome child : offspring) {
//						mdvrp.population = mdvrp.addToPopulation(child, mdvrp.population);
////						mdvrp.populationValue += child.getCost();
//					}
					
//					//remove weakest individuals 
//					for (int i = 0; i < Globals.NEXT_GENERATION_SIZE; i++) {
//						mdvrpChromosome remove = mdvrp.population.pollFirst();
//						remove = mdvrp.population.pollFirst();
////						mdvrp.populationValue -= remove.getCost();
//					}
				}
		
				bestMemeber = mdvrp.population.getLast();
				for (int i = 0; i < bestMemeber.getDepots().size(); i++) {
					mdvrp.depots.get(i).setCustomerRep(bestMemeber.getDepots().get(i));
					mdvrp.depots.get(i).setRoutePartition(bestMemeber.getDepotRoutePartitions().get(i));
				}
				plot(mdvrp.customers, mdvrp.depots);
		
		
//		System.out.println(bestMemeber.getDepots());
		for (LinkedList<Integer> partition : bestMemeber.depotRoutePartitions) {
			System.out.println(partition);
		}
		System.out.println(bestMemeber.cost);
		printPopulation(mdvrp.getPopulation());
		printSolution(bestMemeber, rs);
	}
	
	private static void printSolution(mdvrpChromosome solution, RouteScheduler rs) {
		ArrayList<String> stringSolution = new ArrayList<String>();
		stringSolution.add(null);
		System.out.println(solution.cost);
		double cost = 0;
		for (int depot = 0; depot < solution.getDepots().size(); depot++) {
			int index = 0;
			LinkedList<String> customers = solution.getDepots().get(depot);
			
			for (int i = 0; i < solution.getDepotRoutePartitions().get(depot).size(); i++) {
				List<String> routeCustomers = customers.subList(index, solution.getDepotRoutePartitions().get(depot).get(i));
				SingleRouteInfo sri = rs.calculateRouteCostLoadDuration(routeCustomers, depot);
				index = solution.getDepotRoutePartitions().get(depot).get(i);
				cost += sri.getCost();
				System.out.print((depot+1) + " " + (i+1));
				System.out.format(" %7.2f", sri.getDuration());
				System.out.format(" %7.2f", sri.getLoad());
				System.out.print("  0");
				for (String string : routeCustomers) {
					int custom = 1;
					custom += Integer.parseInt(string);
					System.out.print(" " + custom);
				}
				System.out.println(" " + 0);
			}
		}
	}
	
	
	
	private static void printPopulation(LinkedList<mdvrpChromosome> population) {
		for (mdvrpChromosome chromo : population) {
			System.out.println(chromo);
		}
	}
	
	private static void plot(LinkedList<Customer> customers, LinkedList<Depot> depots) {
		XYDataset serie = createDataset( customers, depots);
//		XYDataset serie1 = createDatasetD( depots);
		 // create a chart...
		
        JFreeChart chart = ChartFactory.createScatterPlot(
            "Scatter Plot " + mapnr, // chart title
            "X", // x axis label
            "Y", // y axis label
            serie, // data  ***-----PROBLEM------***
            PlotOrientation.VERTICAL,
            true, // include legend
            true, // tooltips
            false // urls
            );

        // create and display a frame...
        XYPlot plot = (XYPlot) chart.getPlot();
        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(true, true);
       renderer.setSeriesLinesVisible(0, false);
       renderer.setSeriesLinesVisible(1, false);
        plot.setRenderer(renderer);
        plot.setBackgroundPaint(Color.white);
        
        ChartFrame frame = new ChartFrame("First", chart);
        frame.pack();
        frame.setSize(1600, 1600);
        frame.setVisible(true);
	}
	
	private static XYDataset createDataset(LinkedList<Customer> custome, LinkedList<Depot> deps )
	   {
	      final XYSeries depos = new XYSeries( "dep", false );          
	      for (int i = 0; i < deps.size(); i++) {
			depos.add(deps.get(i).getXCor(), deps.get(i).getYCor());
		  }      
	      final XYSeries customers= new XYSeries( "cust",false);     
	      for (int i = 0; i < custome.size(); i++) {
			
	      customers.add( custome.get(i).getXCor() , custome.get(i).getYCor() );          
	                
	              
	      }
	      //create route series
	      ArrayList<XYSeries> routes = new ArrayList<XYSeries>();
	      for (int i = 0; i < deps.size(); i++) {
	    	  Depot currentDepot = deps.get(i);
	    	  int index = 0;
	    	  for (int j = 0; j < currentDepot.getRoutePartition().size(); j++) {
	    		  final XYSeries route = new XYSeries( "rout"+i+ "."+j, false );          
	    		  route.add(currentDepot.getXCor(), currentDepot.getYCor());
				for (int j2 = index; j2 < currentDepot.getRoutePartition().get(j); j2++) {
					Customer cust = custome.get(Integer.parseInt(currentDepot.getCustomerRep().get(j2)));
					route.add(cust.getXCor(),cust.getYCor());
				}
				index = currentDepot.getRoutePartition().get(j);
				route.add(currentDepot.getXCor(), currentDepot.getYCor());	
				routes.add(route);
			}
		  }      
	      
	      final XYSeriesCollection dataset = new XYSeriesCollection( );          
	      dataset.addSeries( depos );          
	      dataset.addSeries( customers );   
	      for (XYSeries route : routes) {
			dataset.addSeries(route);
		}
	      
	      return dataset;
	   }
	
	public double euclideanDistance(mapPoint from, mapPoint to) {
		double xDistance = to.getXCor() - from.getXCor();
		double yDistance = to.getYCor() - from.getYCor();
		xDistance = Math.pow(xDistance, 2);
		yDistance = Math.pow(yDistance, 2);
		
		return (double) Math.sqrt(xDistance + yDistance);
	}
	
}
