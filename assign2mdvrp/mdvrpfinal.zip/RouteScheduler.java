package assign2MDVRP;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class RouteScheduler {

	
	LinkedList<Customer> customers;
	LinkedList<Depot> depots;
	
	public RouteScheduler(LinkedList<Customer> customers, LinkedList<Depot> depots) {
		this.customers = customers;
		this.depots = depots;
	}
	
	/**
	 * Returns the depot route partition and the total route costs for this depot
	 * 
	 * @param depot list of customers belonging to this depot
	 * @param depNr depot corresponding to the list
	 * @return
	 */
	public RouteInfo scheduleRoutes(LinkedList<String> depot, int depNr) {
		//initiate variables
		double totalCost = 0;
		LinkedList<Integer> partition = new LinkedList<Integer>();
		ArrayList<Double> routeCosts = new ArrayList<Double>();
		//assign each customer to a route
		for (int i = 0; i < depot.size(); i++) {
			//initiate route variables
			double routeCost = 0;
			double routeLoad = 0;
			double routeDuration = 0;
			//each route starts at the depot
			mapPoint prevPlace = depots.get(depNr);
			//get next customer
			Customer customer = customers.get(Integer.parseInt(depot.get(i)));
			//check if custoemr can be added without breaking constraints
			while (canAddCustomer(prevPlace, customer, routeLoad, routeCost, routeDuration, depots.get(depNr))) {
				//update route variables
				double dist = euclideanDistance(prevPlace, customer);
				prevPlace = customer;
				routeCost += dist;
				routeLoad += customer.getServiceDemand();
				routeDuration += dist + customer.getServiceDuration();
				i++;
				if(!(i < depot.size())) {
					break;
				}
				customer = customers.get(Integer.parseInt(depot.get(i)));
			}
			//each route ends at the depot
			double distanceToDepot = euclideanDistance(prevPlace, depots.get(depNr));
			routeCost += distanceToDepot;
			//add route end and this route cost
			partition.add(i);
			routeCosts.add(routeCost);
			//decrement customer since the for loop will increment
			i--;
			
		}
		//check if there are several routes, in which case the route partition can be altered
		if (partition.size() >1) {
//			System.out.println(depot);
			ImprovedRouteInfo iri = improvePartition(partition, routeCosts, depot, depNr);
			partition = iri.getPartition();
//			System.out.println(depot);
			routeCosts = iri.getRouteCosts();
		}
		for (Double cost : routeCosts) {
			totalCost += cost;
		}
		return new RouteInfo(totalCost,partition);
	}
	
	/**
	 * Method which tries to improve the previous partition for the whole depot. Should test whether adding the last customer from the previous route to being
	 * the first customer in the next is feasible and gives a better combined value for both routes. If so the new partition should be kept
	 * 
	 * @param prevPartition 	LinkedList<Integer> previous partition of the depot. with index(0) specifying the last customer index(exclusive) of the route
	 * @param routeCosts		ArrayList<Double> route cost of the previously partitioned routes. index(0) is the cost of the first route. Size equals size of prevPartition
	 * @param customers			LinkedList<String> all customers assigned to the considered depot. Size equals the last index of prevPartition
	 * @param depotNr			int the depotNumber of the considered depot
	 * @return					ImprovedRouteInfo with the new partition and the costs for each route
	 */
	public ImprovedRouteInfo improvePartition(LinkedList<Integer> prevPartition, ArrayList<Double> routeCosts, LinkedList<String> customers, int depotNr) {
		Depot depot = depots.get(depotNr);
		//next route starts at
		int routeStartIndex = 0;
		//calculate for all routes before the last
		for (int i = 0; i < prevPartition.size()-1; i++) {
			//try new partition of route i
			int newPartition = prevPartition.get(i)-1;
			//get single route info on the new possible routes
			SingleRouteInfo sri1 = calculateRouteCostLoadDuration(customers.subList(routeStartIndex, newPartition), depotNr);
			SingleRouteInfo sri2 = calculateRouteCostLoadDuration(customers.subList(newPartition, prevPartition.get(i+1)), depotNr);
			//check if route 2 is feasible (route 1 will due to triangle ineq. always be feasible if the previous route was feasible)
			if(sri2.getDuration() <= depot.getMaxDurationOfRoute() && sri2.getLoad() <= depot.getMaxAllowedVehicleLoad()) {
				//check if new combined cost of the two routes is smaller than previously
				double newCombinedCost = sri1.getCost() + sri2.getCost();
				if (newCombinedCost < routeCosts.get(i) + routeCosts.get(i+1)) {
					//set the partition for route i one smaller then before
					prevPartition.set(i, newPartition);
					//update new route costs
					routeCosts.set(i, sri1.getCost());
					routeCosts.set(i+1, sri2.getCost());
				}
			}
			//set the route start index to the next route end
			routeStartIndex = prevPartition.get(i);
			
		}
		
		//Create new route where last element moved to front of list
		List<String> firstRoute = new LinkedList<String>();
		firstRoute.add(customers.getLast());
		firstRoute.addAll(customers.subList(0, prevPartition.get(0)));
		SingleRouteInfo sri1 = calculateRouteCostLoadDuration(customers.subList(routeStartIndex, customers.size()-1), depotNr);
		SingleRouteInfo sri2 = calculateRouteCostLoadDuration(firstRoute, depotNr);
		if(sri2.getDuration() <= depot.getMaxDurationOfRoute() && sri2.getLoad() <= depot.getMaxAllowedVehicleLoad()) {
			double newCombinedCost = sri1.getCost() + sri2.getCost();
			if (newCombinedCost < routeCosts.get(routeCosts.size()-1) + routeCosts.get(0)) {
				String lastCustomer = customers.removeLast();
				customers.addFirst(lastCustomer);
				routeCosts.set(routeCosts.size()-1, sri1.getCost());
				routeCosts.set(0, sri2.getCost());
//				System.out.println("changed");
				for (int i = 0; i < prevPartition.size()-1; i++) {
					int partition = prevPartition.get(i);
					prevPartition.set(i, partition+1);
				}
			}
		}
		return new ImprovedRouteInfo(prevPartition, routeCosts);
	}
	
	
	
	public SingleRouteInfo calculateRouteCostLoadDuration(List<String> customers, int depotNr) {
		double load = 0;
		double duration = 0;
		double cost = 0;
		Depot depot = this.depots.get(depotNr);
		if(!customers.isEmpty()) {
			
			Customer customer= this.customers.get(Integer.parseInt(customers.get(0)));
			double dist = euclideanDistance(depot, customer);
			cost += dist;
			duration += dist + customer.getServiceDuration();
			load += customer.getServiceDemand();
			
			for (int i = 1; i < customers.size(); i++) {
				Customer nextCustomer = this.customers.get(Integer.parseInt(customers.get(i)));
				dist = euclideanDistance(customer, nextCustomer);
				duration += dist + nextCustomer.getServiceDuration();
				load += nextCustomer.getServiceDemand();
				cost += dist;
				customer = nextCustomer;
			}
			dist = euclideanDistance(customer, depot);
			duration += dist;
			cost += dist;
			return new SingleRouteInfo(cost, duration, load);
		}
		return new SingleRouteInfo(Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE);
	}
	
	public ArrayList<Double> calculateAllRouteCosts(LinkedList<String> depot, LinkedList<Integer> partition, int depotNr) {
		int routeStartIndex = 0;
		ArrayList<Double> routeCosts = new ArrayList<Double>();
		//calculate for all routes before the last
		for (int i = 0; i < partition.size(); i++) {
			//get single route info on the new possible routes
			SingleRouteInfo sri = calculateRouteCostLoadDuration(depot.subList(routeStartIndex, partition.get(i)), depotNr);
			routeStartIndex = partition.get(i);
			routeCosts.add(sri.getCost());
		}
		return routeCosts;
	}
	
	public boolean canAddCustomer(mapPoint prevPlace, Customer customer, double prevRouteLoad, double prevRouteCost, double prevRouteDuration, Depot depot) {
		
			if((prevRouteLoad + customer.getServiceDemand() <= depot.getMaxAllowedVehicleLoad()) && 
			(euclideanDistance(prevPlace, customer) + customer.getServiceDuration() + prevRouteDuration + euclideanDistance(customer, depot) <= depot.getMaxDurationOfRoute())) {
				return true;
			} else {
				return false;
			}
	}
	
	public double euclideanDistance(mapPoint from, mapPoint to) {
		double xDistance = to.getXCor() - from.getXCor();
		double yDistance = to.getYCor() - from.getYCor();
		xDistance = Math.pow(xDistance, 2);
		yDistance = Math.pow(yDistance, 2);
		
		return (double) Math.sqrt(xDistance + yDistance);
	}
	
}
