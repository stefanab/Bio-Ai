package assign2MDVRP;

import java.util.ArrayList;
import java.util.LinkedList;

import assign2MDVRP.mdvrpmain.Globals;

public class mdvrpChromosome {

	ArrayList<LinkedList<String>> depots;
	ArrayList<LinkedList<Integer>> depotRoutePartitions;
	ArrayList<Double> currentLoad;
	ArrayList<Double> depotCosts;
	double cost;
	
	public mdvrpChromosome(ArrayList<LinkedList<String>> depots, ArrayList<Double> currentLoad) {
		this.depots = depots;
		this.currentLoad = currentLoad;
		this.depotRoutePartitions = new ArrayList<LinkedList<Integer>>();
		this.depotCosts = new ArrayList<Double>();
		for (int i = 0; i < depots.size(); i++) {
			depotCosts.add(0.0);
		}
		this.cost = 0;
	}

	public ArrayList<LinkedList<String>> getDepots() {
		return depots;
	}

	public void setDepots(ArrayList<LinkedList<String>> depots) {
		this.depots = depots;
	}
	
	/**
	 * Sets the depot customers for depotNr to customers
	 * @param customers		customers to be set
	 * @param depotNr		depotNr to set customers for
	 */
	public void setSingleDepot(LinkedList<String> customers, int depotNr) {
		this.depots.set(depotNr, customers);
	}
	
	public void setDepotRoutePartition(LinkedList<Integer> partition, int depot) {
		this.depotRoutePartitions.set(depot, partition);
	}

	public double getFitness() {
		double totFitness = 0;
		for (Double cost : depotCosts) {
			totFitness += cost;
		}
		for (LinkedList<Integer> routes : depotRoutePartitions) {
			totFitness += routes.size() * Globals.ROUTE_PENALTY;
		}
		return totFitness;
	}
	
	public double getCost() {
		double totCost = 0;
		for (Double double1 : depotCosts) {
			totCost += double1;
		}
		return totCost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}
	
	public void setDepotCost(double cost, int depot) {
		double prevCost = depotCosts.get(depot);
		this.cost -= prevCost;
		this.depotCosts.set(depot, cost);
		this.cost += cost;
	}

	public void setAllDepotCosts(ArrayList<Double> costs) {
		this.depotCosts = costs;
		double totCost = 0;
		for (Double cost : costs) {
			totCost += cost;
		}
		this.cost = totCost;
	}
	
	public ArrayList<LinkedList<Integer>> getDepotRoutePartitions() {
		return depotRoutePartitions;
	}

	public void setDepotRoutePartitions(ArrayList<LinkedList<Integer>> depotRoutePartitions) {
		this.depotRoutePartitions = depotRoutePartitions;
	}

	public ArrayList<Double> getCurrentLoad() {
		return currentLoad;
	}
	
	
	public ArrayList<Double> getDepotCosts() {
		return depotCosts;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Fitness " + getFitness();
	}
	
}
