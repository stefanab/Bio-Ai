package assign2MDVRP;

import java.util.ArrayList;
import java.util.LinkedList;

public class RouteInfo {

	
	double totalDepotCost;
	LinkedList<Integer> routePartition;
	
	
	public RouteInfo(double totalDepotCost, LinkedList<Integer> routePartition) {
		this.totalDepotCost = totalDepotCost;
		this.routePartition = routePartition;
	}
	
	
	public void phase1(mdvrpChromosome chromosome) {
		
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Dep cost: " + totalDepotCost;
	}
}
