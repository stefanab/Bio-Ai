package assign1NN;

import java.util.ArrayList;
import java.util.Random;

public class FlatlandModel {

	static int TRAINING_ROUND_SIZE = 100;
	static int TRANING_ROUNDS = 1000;
	static double LEARNING_RATE = 0.01;
	
	ArrayList<ArrayList<String>> foodTiles = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> poisonTiles = new ArrayList<ArrayList<String>>();
	FlatlandController fc;
	
	int hitCount = 0;
	int totalScore;
	int agentCol;
	int agentRow;
	int agentOrientation;
	int points;
	int foodCount;
	int poisonCount;
	int moves;
	String moveOrder;
	boolean end = false;
	
	public FlatlandModel(FlatlandController fc) {
		this.fc = fc;
		this.points = 0;
		this.foodCount =0;
		this.poisonCount=0;
		this.moves = 0;
		this.totalScore = 0;
		moveOrder = "";
	}
	
	public FlatlandModel() {
		// TODO Auto-generated constructor stub
		this.fc = fc;
		this.points = 0;
		this.foodCount =0;
		this.poisonCount=0;
		this.moves = 0;
		this.totalScore = 0;
		moveOrder = "";
		
	}

	public int setPoints(int row, int col, boolean temp) {
		if (col<=0 || col >= 11 || row <= 0 || row >= 11) {
			if(!temp) {
				
				points += -100;
				hitCount++;
				end = true;
			}
			return -100;
		}
		else if(foodTiles.get(row).contains(col+"")) {
			if (!temp){
				this.points += 1;
				foodTiles.get(row).remove(col+"");
				setFoodCount();
				
			}
			return 1;
			
		}
		else if(poisonTiles.get(row).contains(col+"")){
			if(!temp) {
				this.points += -4;
				poisonTiles.get(row).remove(col+"");
				setPoisonCount();
			}
			return -4;
		}
		return 0;
	}
	
	public void updateTotalScore() {
		totalScore += points;
	}
	public void reset() {
		points = 0;
		foodCount = 0;
		poisonCount = 0;
		moves = 0;
		moveOrder = "";
		agentOrientation = 0;
		end = false;
		
	}
	
	public int getFoodCount() {
		return foodCount;
	}


	public void setFoodCount() {
		this.foodCount++;
	}


	public int getPoisonCount() {
		return poisonCount;
	}


	public void setPoisonCount() {
		this.poisonCount++;
	}


	public boolean isEnd() {
		return end;
	}


	public void setEnd(boolean end) {
		this.end = end;
	}


	public void setPoints(int points) {
		this.points = points;
	}


	public int getPoints() {
		return points;
	}
	public boolean setPoints(int row, int col) {
		if (col==0 || col == 11 || row == 0 || row == 11) {
			points += -100;
			end = true;
			hitCount++;
			return true;
		}
		else if(foodTiles.get(row).contains(col+"")) {
			this.points += 1;
			foodTiles.get(row).remove(col+"");
			setFoodCount();
			return true;
			
		}
		else if(poisonTiles.get(row).contains(col+"")){
			this.points += -4;
			poisonTiles.get(row).remove(col+"");
			setPoisonCount();
			return true;
		}
		return false;
	}
	
	public int getAgentCol() {
		return agentCol;
	}
	public void setAgentCol(int agentCol) {
		this.agentCol = agentCol;
	}
	public int getAgentRow() {
		return agentRow;
	}
	public void setAgentRow(int agentRow) {
		this.agentRow = agentRow;
	}
	public int getAgentOrientation() {
		return agentOrientation;
	}
	public void setAgentOrientation(int agentOrientation) {
		
		this.agentOrientation += agentOrientation;
		if (this.agentOrientation == 4) {
			this.agentOrientation = 0;
		}
		if (this.agentOrientation == -1) {
			this.agentOrientation = 3;
		}
	}
	public ArrayList<ArrayList<String>> getFoodTiles() {
		return foodTiles;
	}
	public void setFoodTiles(ArrayList<ArrayList<String>> foodTiles) {
		this.foodTiles = foodTiles;
	}
	public ArrayList<ArrayList<String>> getPoisonTiles() {
		return poisonTiles;
	}
	public void setPoisonTiles(ArrayList<ArrayList<String>> poisonTiles) {
		this.poisonTiles = poisonTiles;
	}
	
	public void doNextMove() {
		int move = pickNextMove();
		setAgentOrientation(move);
		switch (agentOrientation) {
		case 0:
			agentRow--;
			moveOrder+="N";
			break;
		case 1:
			agentCol++;
			moveOrder+="E";
			break;
		case 2:
			agentRow++;
			moveOrder+="S";
			break;
		case 3:
			agentCol--;
			moveOrder+="W";
			break;

		default:
			break;
		}
		moves++;
		if(moves >= 50) {
			setEnd(true);
		}
//		fc.UpdatePointsAndTiles(agentRow, agentCol, getAgentOrientation());
		setPoints(agentRow, agentCol);
		
	}
	
	public FlatlandController getFc() {
		return fc;
	}


	public void setFc(FlatlandController fc) {
		this.fc = fc;
	}


	public int getMoves() {
		return moves;
	}


	public void setMoves(int moves) {
		this.moves = moves;
	}


	public void setFoodCount(int foodCount) {
		this.foodCount = foodCount;
	}


	public void setPoisonCount(int poisonCount) {
		this.poisonCount = poisonCount;
	}


	public int pickNextMove() {
		int move = scoutMoves();
		if (move == 1) {
			return -1;
		} else if (move == 2) {
			return 0;
		} else {
			return 1;
		}
		
	}
	
	public int scoutMoves() {
		int move1 = 0;
		int move2 = 0;
		int move3 = 0;
		int moveCol = agentCol;
		int moveRow = agentRow;
		//facing north
		if(agentOrientation == 0) {
			
			//checkWest
			moveCol--;
			move1 = checkWest(moveRow, moveCol);
			
			//check north
			moveCol = agentCol;
			moveRow--;
			move2 = checkNorth(moveRow, moveCol);
			
			//check east
			moveRow = agentRow;
			moveCol++;
			move3 = checkEast(moveRow, moveCol);
		 
		
		
		} else if (agentOrientation == 1) { //facing east
			//check north
			moveCol = agentCol;
			moveRow--;
			move1 = checkNorth(moveRow, moveCol);
			
			//check east
			moveRow = agentRow;
			moveCol++;
			move2 = checkEast(moveRow, moveCol);
			
			//check south
			moveCol = agentCol;
			moveRow++;
			move3 = checkSouth(moveRow, moveCol);
			
			
		} else if (agentOrientation == 2) { //facing south
			//check east
			
			moveCol++;
			move1 = checkEast(moveRow, moveCol);
			
			//check south
			moveCol = agentCol;
			moveRow++;
			move2 = checkSouth(moveRow, moveCol);
			
			//checkWest
			moveRow = agentRow;
			moveCol--;
			move3 = checkWest(moveRow, moveCol);
			
			
		} else { //facing west (4)
			//check south
			moveRow++;
			move1 = checkSouth(moveRow, moveCol);
			
			//checkWest
			moveRow = agentRow;
			moveCol--;
			move2 = checkWest(moveRow, moveCol);
			
			//check north
			moveCol = agentCol;
			moveRow--;
			move3 = checkNorth(moveRow, moveCol);
		}
		
		//sorter moves og gi det h�yeste tallet. Ved flere like, gj�r et "tilfeldig" valg
		int bestMove = move1;
		int bestMoveNumber = 1;
		
		
		if (move1 == move2 && move1 == move3 && move2 == move3) {
			return 2; 
		}
		if (bestMove <= move3) {
			
					bestMove = move3;
					bestMoveNumber = 3;
			
		}
		if (bestMove <= move2) {
				bestMove = move2;
				bestMoveNumber = 2;
		}
		
		
		return bestMoveNumber;
	}
	
	
	
	public int checkEast(int row, int col) {
		if(col == 11) {
			return 0;
		} else {
			return checkTiles(row, col);
		}
	}
	
	public int checkNorth(int row, int col) {
		if(row == 0) {
			return 0;
		} else {
			return checkTiles(row, col);
		}
	}
	
	public int checkWest(int row, int col) {
		if(col == 0) {
			return 0;
		} else {
			return checkTiles(row, col);
		}
	}
	
	public int checkSouth(int row, int col) {
		if(row == 11) {
			return 0;
		} else {
			return checkTiles(row, col);
		}
	}
	
	public int checkTiles(int moveRow, int moveCol) {
		 if (poisonTiles.get(moveRow).contains(moveCol+"")) {
			return 1;
		} else if (foodTiles.get(moveRow).contains(moveCol+"")){
			return 3;
		} else {
			return 2;
		}
	}	
	
	public static void main(String[] args) {
		Random rdm = new Random();
		FlatlandModel flatland = new FlatlandModel();
		for (int round = 0; round < TRANING_ROUNDS; round++) {
			for (int instance = 0; instance < TRAINING_ROUND_SIZE; instance++) {
		ArrayList<ArrayList<String>> foodTiles = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> poisonTiles = new ArrayList<ArrayList<String>>();
		foodTiles.add(new ArrayList<String>());
		poisonTiles.add(new ArrayList<String>());
		for (int i = 1; i < 11; i++) {
			foodTiles.add(new ArrayList<String>());
			poisonTiles.add(new ArrayList<String>());
			for (int j = 1; j < 11; j++) {
				double food = rdm.nextDouble();
				if (food > 0.5) {
					foodTiles.get(i).add(j+"");
				} else {
					double poison = rdm.nextDouble();
					if (poison > 0.5) {
						poisonTiles.get(i).add(j+"");
					}
				}
			}
		}
		foodTiles.add(new ArrayList<String>());
		poisonTiles.add(new ArrayList<String>());
		int col = rdm.nextInt(10);
		int row = rdm.nextInt(10);
		int orientation = rdm.nextInt(4);
		
		flatland.setAgentCol(col+1);
		flatland.setAgentRow(row+1);
		flatland.setAgentOrientation(orientation);
		flatland.setFoodTiles(foodTiles);
		flatland.setPoisonTiles(poisonTiles);
//		System.out.println("row: " + flatland.agentRow + " col: " + flatland.agentCol + " ori: " + flatland.agentOrientation);
		flatland.setPoints(row+1, col+1);
							
							while(!flatland.isEnd()) {
								
								flatland.doNextMove();
//								System.out.println(flatland.moveOrder);
							}
//							System.out.println("Points this instance: " + flatland.getPoints());
							flatland.reset();
//							ArrayList<Node> nodes = new ArrayList<Node>();
//							for (Node child : flatlandGrid.getChildren()) {
//								if (child.getClass().getName().equals("javafx.scene.shape.Circle")) {
//									nodes.add(child);
//								}
//							}
//							flatlandGrid.getChildren().removeAll(nodes);
						}
						System.out.println("avg score in round " + round + " : " + flatland.totalScore/TRAINING_ROUND_SIZE);
						System.out.println("hit wall " + flatland.hitCount + " times");
						flatland.hitCount = 0;
						flatland.totalScore = 0;
	
		}
		
	System.out.println("done!");
	}
}
