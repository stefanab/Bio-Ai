package assign1NN;

import java.util.ArrayList;

public abstract  class AFlatlandModel {

	ArrayList<ArrayList<String>> foodTiles = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> poisonTiles = new ArrayList<ArrayList<String>>();
	int totalScore;
	int agentCol;
	int agentRow;
	int agentOrientation;
	int points;
	int foodCount;
	int poisonCount;
	int moves;
	String moveOrder;
	boolean end = false;
	FlatlandController fc;
	
	public AFlatlandModel(FlatlandController fc) {
		this.fc = fc;
	}
	
	public abstract void doNextMove();
	
	
}
