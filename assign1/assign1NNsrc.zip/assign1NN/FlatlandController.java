package assign1NN;

import java.util.ArrayList;
import java.util.Random;

import com.sun.glass.events.MouseEvent;

import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;

public class FlatlandController {

	static int TRAINING_ROUNDS = 50;
	static int TRAINING_ROUND_SIZE = 100;
	protected Service<Void> backgroundThread;
	ArrayList<Integer> pointsEachRound = new ArrayList<Integer>();
	FlatlandModelNNReinforced flatland = new FlatlandModelNNReinforced(this);
	@FXML GridPane flatlandGrid;
	@FXML Pane agent;
	@FXML Text pointsShow;
	@FXML Text movesShow;
	@FXML Text poisonCount;
	@FXML Text foodCount;
	@FXML Group walls;
	
	
	
	public void initGame() {
//		Random rdm = new Random();
//		ArrayList<ArrayList<String>> foodTiles = new ArrayList<ArrayList<String>>();
//		ArrayList<ArrayList<String>> poisonTiles = new ArrayList<ArrayList<String>>();
//		foodTiles.add(new ArrayList<String>());
//		poisonTiles.add(new ArrayList<String>());
//		for (int i = 1; i < 11; i++) {
//			foodTiles.add(new ArrayList<String>());
//			poisonTiles.add(new ArrayList<String>());
//			for (int j = 1; j < 11; j++) {
//				double food = rdm.nextDouble();
//				if (food > 0.5) {
//					Circle nextNode = new Circle(21);
//					flatlandGrid.add(nextNode, j, i);
//					nextNode.translateXProperty().set(3.5);
//					nextNode.setFill(Paint.valueOf("green"));
//					nextNode.setStroke(Paint.valueOf("green"));
//					foodTiles.get(i).add(j+"");
//				} else {
//					double poison = rdm.nextDouble();
//					if (poison > 0.5) {
//						Circle nextNode = new Circle(21);
//						flatlandGrid.add(nextNode, j, i);
//						nextNode.setFill(Paint.valueOf("red"));
//						nextNode.setStroke(Paint.valueOf("red"));
//						nextNode.translateXProperty().set(3.5);
//						poisonTiles.get(i).add(j+"");
//					}
//				}
//			}
//		}
//		foodTiles.add(new ArrayList<String>());
//		poisonTiles.add(new ArrayList<String>());
//		int col = rdm.nextInt(10);
//		int row = rdm.nextInt(10);
//		flatlandGrid.getChildren().remove(agent);
//		int orientation = rdm.nextInt(4);
//		
//		flatlandGrid.add(agent, col+1, row+1);
//		flatland.setAgentCol(col+1);
//		flatland.setAgentRow(row+1);
//		flatland.setAgentOrientation(orientation);
//		flatland.setFoodTiles(foodTiles);
//		flatland.setPoisonTiles(poisonTiles);
//		System.out.println("row: " + flatland.agentRow + " col: " + flatland.agentCol + " ori: " + flatland.agentOrientation);
//		UpdatePointsAndTiles(row+1,col+1,orientation);
	}
	
	public void UpdatePointsAndTiles(int row, int col, int ori) {
		MoveAgent(row, col, ori);
//		if(flatland.setPoints(row, col)) {
//			Node theChild = null;
//			for (Node child : flatlandGrid.getChildren()) {
//				if (child.getClass().getName().equals("javafx.scene.shape.Circle")){
//					if((GridPane.getColumnIndex(child) == col)&& (GridPane.getRowIndex(child) == row)) {
//						child.setVisible(false);
//						theChild = child;
//						break;
//					}
//				}
//			}
////			flatlandGrid.getChildren().remove(theChild);
//		}
		foodCount.setText(flatland.getFoodCount()+"");
		poisonCount.setText(flatland.getPoisonCount()+"");
		pointsShow.setText(Integer.toString(flatland.getPoints()));
		
	}
	
	public void MoveAgent(int row, int col, int ori) {
		flatlandGrid.getChildren().remove(agent);
		agent.setRotate((ori)*90);
		flatlandGrid.add(agent, col, row);
//		movesShow.setText(flatland.getMoves()+"");
	}
	
	
	@FXML 
	public void roter(Event event) {
		Random rdm = new Random();
		// TODO Auto-generated method stub
		FlatlandModelNNReinforced3Step flatland = new FlatlandModelNNReinforced3Step();
		for (int round = 0; round < TRAINING_ROUNDS; round++) {
			int movesthisInstance = 0;
			for (int instance = 0; instance < TRAINING_ROUND_SIZE; instance++) {
		ArrayList<ArrayList<String>> foodTiles = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> poisonTiles = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> startfoodTiles = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> startpoisonTiles = new ArrayList<ArrayList<String>>();
		foodTiles.add(new ArrayList<String>());
		poisonTiles.add(new ArrayList<String>());
		startfoodTiles.add(new ArrayList<String>());
		startpoisonTiles.add(new ArrayList<String>());
		for (int i = 1; i < 11; i++) {
			foodTiles.add(new ArrayList<String>());
			poisonTiles.add(new ArrayList<String>());
			startfoodTiles.add(new ArrayList<String>());
			startpoisonTiles.add(new ArrayList<String>());
			for (int j = 1; j < 11; j++) {
				double food = rdm.nextDouble();
				if (food > 0.5) {
					foodTiles.get(i).add(j+"");
					startfoodTiles.get(i).add(j+"");
				} else {
					double poison = rdm.nextDouble();
					if (poison > 0.5) {
						poisonTiles.get(i).add(j+"");
						startpoisonTiles.get(i).add(j+"");
					}
				}
			}
		}
		foodTiles.add(new ArrayList<String>());
		poisonTiles.add(new ArrayList<String>());
		startfoodTiles.add(new ArrayList<String>());
		startpoisonTiles.add(new ArrayList<String>());
		int col = rdm.nextInt(10);
		int row = rdm.nextInt(10);
		int startCol = col;
		int orientation = rdm.nextInt(4);
		
		flatland.setAgentCol(col+1);
		flatland.setAgentRow(row+1);
		flatland.setAgentOrientation(orientation);
		flatland.setFoodTiles(foodTiles);
		flatland.setPoisonTiles(poisonTiles);
//		System.out.println("row: " + flatland.agentRow + " col: " + flatland.agentCol + " ori: " + flatland.agentOrientation);
		//flatland.setPoints(row+1, col+1,false);
							
							while(!flatland.isEnd()) {
								
								flatland.doNextMove();
							}
							flatland.updateTotalScore();
//							System.out.println("Points this instance: " + flatland.getPoints());
							movesthisInstance = flatland.getMoves();
							if(!(round == TRAINING_ROUNDS-1) || !(instance == TRAINING_ROUND_SIZE-1) ){
								
								flatland.reset();
							} else {
								System.out.println(flatland.getFoodTiles());
								System.out.println(startfoodTiles);
								System.out.println(flatland.getPoisonTiles());
								System.out.println(startpoisonTiles);
								System.out.println(col);
								System.out.println(flatland.getAgentCol());
								System.out.println(row);
								System.out.println(flatland.getAgentRow());
								System.out.println(orientation);
								System.out.println(flatland.getAgentOrientation());
								renderView(startfoodTiles, startpoisonTiles, row+1, col+1,flatland.getAgentOrientation(), flatland.moveOrder, 
										flatland.getPoints(),flatland.getFoodCount(),flatland.getPoisonCount());
								
							}
//							ArrayList<Node> nodes = new ArrayList<Node>();
//							for (Node child : flatlandGrid.getChildren()) {
//								if (child.getClass().getName().equals("javafx.scene.shape.Circle")) {
//									nodes.add(child);
//								}
//							}
//							flatlandGrid.getChildren().removeAll(nodes);
						}
				
//						System.out.println("avg score in round " + round + " : " + flatland.totalScore/TRAINING_ROUND_SIZE);
//						System.out.println("hit wall " + flatland.hitCount + " times");
						pointsEachRound.add(flatland.totalScore/TRAINING_ROUND_SIZE);
						flatland.hitCount = 0;
						flatland.totalScore = 0;
	
		}
		for (int i = 0; i < 3; i++) {
			
//		System.out.println(i + " away from neuron for left: " + flatland.moveLeft.subList(i*12, 12+i*12));
//		System.out.println(i + " away from neuron for forward: " +flatland.moveForward.subList(i*12, 12+i*12));
//		System.out.println(i + " away from neuron for right: " +flatland.moveRight.subList(i*12, 12+i*12));
		}
//		System.out.println("Length: " + flatland.moveLeft.size());
		ArrayList<Integer> pointsEachRound1 = new ArrayList<>();
		System.out.println(pointsEachRound);
		int total = 0;
		for (int i = 0; i < pointsEachRound.size(); i++) {
			total += pointsEachRound.get(i);
		}
		System.out.println("avg score: " + total/pointsEachRound.size());
								System.out.println(flatland.moveOrder);
	System.out.println("done!");
	}

	private void renderView(ArrayList<ArrayList<String>> startfoodTiles, ArrayList<ArrayList<String>> startpoisonTiles,
			int row, int col, int endorientation, String moveOrder, int points, int foods, int poisons) {
		ArrayList<ArrayList<Circle>> foodCircles = new ArrayList<ArrayList<Circle>>();
		ArrayList<ArrayList<Circle>> poisonCircles = new ArrayList<ArrayList<Circle>>();
		foodCircles.add(new ArrayList<Circle>());
		poisonCircles.add(new ArrayList<Circle>());
		for (int j = 1; j < 11; j++) {
			foodCircles.add(new ArrayList<Circle>());
			poisonCircles.add(new ArrayList<Circle>());
			for (int k = 0; k < startfoodTiles.get(j).size(); k++) {
				
				Circle nextNode = new Circle(21);
				flatlandGrid.add(nextNode, Integer.parseInt(startfoodTiles.get(j).get(k)), j);
				nextNode.translateXProperty().set(3.5);
				nextNode.setFill(Paint.valueOf("green"));
				nextNode.setStroke(Paint.valueOf("green"));
				
			}
			for (int k = 0; k < startpoisonTiles.get(j).size(); k++) {
				
				Circle nextNode = new Circle(21);
				flatlandGrid.add(nextNode, Integer.parseInt(startpoisonTiles.get(j).get(k)), j);
				nextNode.setFill(Paint.valueOf("red"));
				nextNode.setStroke(Paint.valueOf("red"));
				nextNode.translateXProperty().set(3.5);
			
			}
		}
		foodCircles.add(new ArrayList<Circle>());
		poisonCircles.add(new ArrayList<Circle>());
		MoveAgent(row, col, endorientation);
		int k = 1;
		for (int i = 0; i < moveOrder.length(); i++) {
			if(i == 10*k) {
				k++;
			}
			Node circle = getNodeFromGridPane(flatlandGrid, col, row);
			if (circle != null && circle != agent) {
				circle.setOpacity(0.5);
			}
			char move = moveOrder.charAt(i);
			Line line = new Line(0, 0, 52, 0);
			line.setStrokeWidth(2*k);
			flatlandGrid.add(line, col, row);
			switch (move) {
			case 'N':
				line.setRotate(90);
				line.setTranslateY(-26);
				row--;
				break;
			case 'E':
				line.setTranslateX(26);
				col++;
				break;
			case 'S':
				line.setRotate(90);
				line.setTranslateY(26);
				row++;	
				break;
			case 'W':
				line.setTranslateX(-26);
				col--;
				break;
			default:
				break;
			}
		}
		Node circle = getNodeFromGridPane(flatlandGrid, col, row);
		if (circle != null && circle != agent) {
			circle.setOpacity(0.5);
		}
		MoveAgent(row, col, endorientation);
		movesShow.setText(moveOrder.length()+"");
		pointsShow.setText(points+"");
		foodCount.setText(foods+"");
		poisonCount.setText(poisons+"");
	}
	private Node getNodeFromGridPane(GridPane gridPane, int col, int row) {
	    for (Node node : gridPane.getChildren()) {
	    	if (node.getClass().getName().equals("javafx.scene.shape.Circle"))
		        if (GridPane.getColumnIndex(node) == col && GridPane.getRowIndex(node) == row) {
		            return node;
		        }
	    }
	    return null;
	}

}
